<?php

namespace Pterodactyl\Listeners;

use Pterodactyl\Facades\Activity;
use Illuminate\Auth\Events\Failed;
use Illuminate\Auth\Events\Logout;
use Illuminate\Auth\Events\Lockout;
use Pterodactyl\Events\Auth\DirectLogin;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Contracts\Events\Dispatcher;
use Pterodactyl\Extensions\Illuminate\Events\Contracts\SubscribesToEvents;

class AuthenticationListener implements SubscribesToEvents
{
    /**
     * Handles an authentication event by logging the user and information about
     * the request.
     */
    public function login(Failed|DirectLogin $event): void
    {
        $activity = Activity::withRequestMetadata();
        if ($event->user) {
            $activity = $activity->subject($event->user);
        }

        if ($event instanceof Failed) {
            foreach ($event->credentials as $key => $value) {
                $activity = $activity->property($key, $value);
            }
        }

        $activity->event($event instanceof Failed ? 'auth:fail' : 'auth:success')->log();
    }

    public function reset(PasswordReset $event): void
    {
        Activity::event('event:password-reset')->withRequestMetadata()->subject($event->user)->log();
    }

    public function logout(Logout $event): void
    {
        // This session no longer counts as a place the user is logged in.
        app(\Pterodactyl\Services\Sessions\SessionService::class)->forget(request());

        if ($event->user instanceof \Illuminate\Database\Eloquent\Model) {
            Activity::event('auth:logout')->withRequestMetadata()->subject($event->user)->actor($event->user)->log();
        }
    }

    public function lockout(Lockout $event): void
    {
        Activity::event('auth:lockout')->withRequestMetadata()->property('user', mb_substr((string) $event->request->input('user'), 0, 191))->log();
    }

    public function subscribe(Dispatcher $events): void
    {
        $events->listen(Logout::class, [self::class, 'logout']);
        $events->listen(Lockout::class, [self::class, 'lockout']);
        $events->listen(Failed::class, [self::class, 'login']);
        $events->listen(DirectLogin::class, [self::class, 'login']);
        $events->listen(PasswordReset::class, [self::class, 'reset']);
    }
}
