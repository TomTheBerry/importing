<?php

namespace Pterodactyl\Console\Commands\User;

use Illuminate\Console\Command;
use Pterodactyl\Services\Privacy\PrivacyService;

class ProcessPrivacyRequestsCommand extends Command
{
    protected $signature = 'p:user:process-privacy';

    protected $description = 'Deletes accounts whose deletion grace period has ended, and removes expired data export files.';

    public function handle(PrivacyService $service): int
    {
        $deleted = $service->processDueDeletions();
        $pruned = $service->pruneExports();

        $this->info("Deleted $deleted account(s) and removed $pruned expired data export file(s).");

        return self::SUCCESS;
    }
}
