<?php

namespace Pterodactyl\Console\Commands\User;

use Illuminate\Console\Command;
use Pterodactyl\Services\Sessions\SessionService;
use Pterodactyl\Services\Sessions\LoginAlertService;

/**
 * Forgets logins that have expired and devices that haven't been seen for a long time.
 */
class PruneSessionsCommand extends Command
{
    protected $signature = 'p:user:prune-sessions';

    protected $description = 'Removes expired login sessions and devices not seen for '
        . LoginAlertService::FORGET_AFTER_DAYS . ' days.';

    public function handle(SessionService $sessions, LoginAlertService $alerts): int
    {
        $ended = $sessions->prune();
        $forgotten = $alerts->prune();

        $this->info("Removed $ended expired sessions and forgot $forgotten old devices.");

        return self::SUCCESS;
    }
}
