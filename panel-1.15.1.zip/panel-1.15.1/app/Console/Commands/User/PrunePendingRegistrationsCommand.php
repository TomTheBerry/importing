<?php

namespace Pterodactyl\Console\Commands\User;

use Illuminate\Console\Command;
use Pterodactyl\Services\Users\RegistrationService;

class PrunePendingRegistrationsCommand extends Command
{
    protected $signature = 'p:user:prune-pending {--hours= : Remove registrations older than this many hours}';

    protected $description = 'Deletes unfinished registrations, and long-unverified accounts that have nothing on them.';

    public function handle(RegistrationService $service): int
    {
        $hours = (int) ($this->option('hours') ?: config('pterodactyl.registration.pending_lifetime', 48));
        $count = $service->prunePending(max(1, $hours));
        $this->info("Removed $count unfinished registration(s) older than $hours hours.");

        $days = max(1, (int) config('pterodactyl.registration.unverified_lifetime_days', 30));
        $unverified = $service->pruneUnverified($days);
        $this->info("Removed $unverified account(s) still unverified $days days after their deadline, with no servers or services.");

        return self::SUCCESS;
    }
}
