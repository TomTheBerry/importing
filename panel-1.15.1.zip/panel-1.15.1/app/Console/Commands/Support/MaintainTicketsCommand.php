<?php

namespace Pterodactyl\Console\Commands\Support;

use Illuminate\Console\Command;
use Pterodactyl\Services\Support\TicketService;
use Pterodactyl\Models\Support\DiscordOutboxItem;

/**
 * Hourly tidy-up for support tickets.
 */
class MaintainTicketsCommand extends Command
{
    protected $signature = 'p:tickets:maintain';

    protected $description = 'Closes tickets that have been waiting on the customer too long, deletes old closed tickets and clears finished Discord jobs.';

    public function handle(TicketService $tickets): int
    {
        $closed = $tickets->autoClose();
        $deleted = $tickets->prune();

        // Finished Discord jobs are only kept for a week (to show recent failures).
        $cleared = DiscordOutboxItem::query()->whereNotNull('delivered_at')->where('delivered_at', '<', now()->subDays(7))->delete();
        // Jobs the bot never collected (it was offline for days) are dropped after 3 days.
        $cleared += DiscordOutboxItem::query()->whereNull('delivered_at')->where('created_at', '<', now()->subDays(3))->delete();

        $this->info("Closed $closed inactive tickets, deleted $deleted old tickets and cleared $cleared Discord jobs.");

        return self::SUCCESS;
    }
}
