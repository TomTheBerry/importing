<?php

namespace Pterodactyl\Console\Commands\Support;

use Illuminate\Console\Command;
use Pterodactyl\Services\Support\DiscordRoleService;

/**
 * Re-checks the Discord roles of everyone who has linked Discord. Runs daily to catch
 * anything missed (e.g. someone who linked before joining the Discord server).
 */
class SyncDiscordRolesCommand extends Command
{
    protected $signature = 'p:discord:sync-roles';

    protected $description = 'Asks the Discord bot to bring every linked member\'s plan roles up to date.';

    public function handle(): int
    {
        if (!DiscordRoleService::enabled()) {
            $this->warn('Nothing to do: set DISCORD_BOT_SECRET and DISCORD_LINKED_ROLE_ID or a plan\'s Discord role first.');

            return self::SUCCESS;
        }

        $count = DiscordRoleService::queueAll();
        $this->info("Queued a role check for $count linked Discord accounts.");

        return self::SUCCESS;
    }
}
