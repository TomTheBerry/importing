<?php

namespace Pterodactyl\Console\Commands\Billing;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Pterodactyl\Services\Billing\LifecycleService;

class RunBillingCommand extends Command
{
    protected $signature = 'p:billing:run';

    protected $description = 'Creates renewal invoices, charges saved cards, sends reminders and suspends or deletes unpaid services.';

    public function handle(LifecycleService $service): int
    {
        if (!config('billing.enabled')) {
            $this->info('Billing is disabled.');

            return self::SUCCESS;
        }

        $results = $service->run();
        Cache::forever('billing:last_run', now()->toAtomString());

        foreach ($results as $step => $count) {
            $this->line(sprintf('%-12s %d', $step, $count));
        }

        return self::SUCCESS;
    }
}
