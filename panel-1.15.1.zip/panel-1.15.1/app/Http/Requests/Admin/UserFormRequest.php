<?php

namespace Pterodactyl\Http\Requests\Admin;

use Pterodactyl\Models\User;
use Illuminate\Support\Collection;

class UserFormRequest extends AdminFormRequest
{
    /**
     * Rules to apply to requests for updating or creating a user
     * in the Admin CP.
     */
    public function rules(): array
    {
        $rules = Collection::make(
            User::getRulesForUpdate($this->route()->parameter('user'))
        );

        // Staff members that can only assign roles may only submit the role field.
        if ($this->user() && !$this->user()->hasAdminPermission('users.update')) {
            return $rules->only(['admin_role_id'])->toArray();
        }

        return $rules->only([
            'email',
            'username',
            'name_first',
            'name_last',
            'password',
            'language',
            'root_admin',
            'admin_role_id',
        ])->toArray();
    }
}
