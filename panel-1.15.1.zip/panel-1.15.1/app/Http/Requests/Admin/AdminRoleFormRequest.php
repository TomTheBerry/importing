<?php

namespace Pterodactyl\Http\Requests\Admin;

use Illuminate\Validation\Rule;
use Pterodactyl\Models\AdminRole;
use Pterodactyl\Services\Acl\AdminPermissions;

class AdminRoleFormRequest extends AdminFormRequest
{
    public function rules(): array
    {
        /** @var AdminRole|null $role */
        $role = $this->route()->parameter('role');

        return [
            'name' => [
                'required',
                'string',
                'between:1,191',
                Rule::unique('admin_roles', 'name')->ignore($role?->id),
            ],
            'description' => 'nullable|string|max:1000',
            'color' => ['nullable', 'string', 'regex:/^#[0-9a-fA-F]{6}$/'],
            'require_totp' => 'sometimes|boolean',
            'permissions' => 'sometimes|array',
            'permissions.*' => ['string', Rule::in(AdminPermissions::all())],
        ];
    }

    public function attributes(): array
    {
        return [
            'permissions.*' => 'permission',
        ];
    }

    /**
     * Returns the validated data in a format that can be saved to the role.
     */
    public function roleData(): array
    {
        $data = $this->validated();

        return [
            'name' => trim($data['name']),
            'description' => $data['description'] ?? null,
            'color' => !empty($data['color']) ? strtolower($data['color']) : null,
            'permissions' => AdminPermissions::sanitize($data['permissions'] ?? []),
            'require_totp' => (bool) ($data['require_totp'] ?? false),
        ];
    }
}
