<?php

namespace Pterodactyl\Http\Requests\Api\Client\Account;

use Pterodactyl\Services\Users\AvatarService;
use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;

class UploadAvatarRequest extends ClientApiRequest
{
    public function rules(): array
    {
        return [
            // "mimes" checks the real file contents, not just the extension. The image is
            // then fully decoded and re-encoded by the AvatarService.
            'avatar' => [
                'required',
                'file',
                'max:' . AvatarService::MAX_KILOBYTES,
                'mimes:' . implode(',', AvatarService::ALLOWED_EXTENSIONS),
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'avatar.mimes' => 'Profile pictures must be a JPG, PNG, GIF or WebP image.',
            'avatar.max' => 'Profile pictures must be smaller than ' . (AvatarService::MAX_KILOBYTES / 1024) . 'MB.',
        ];
    }
}
