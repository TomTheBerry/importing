<?php

namespace Pterodactyl\Http\Requests\Auth;

use Pterodactyl\Models\User;
use Illuminate\Foundation\Http\FormRequest;

class RegisterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $rules = User::getRules();

        return [
            // No "unique" rule on email on purpose: an existing email gets the same
            // response as a new one so registered addresses can't be discovered.
            'email' => ['required', 'string', 'email:strict', 'between:1,191'],
            'username' => $rules['username'],
            'name_first' => ['required', 'string', 'between:1,191', 'not_regex:/[<>]/'],
            'name_last' => ['required', 'string', 'between:1,191', 'not_regex:/[<>]/'],
            'password' => ['required', 'string', 'min:8', 'max:255', 'confirmed'],
            'accept_terms' => ['accepted'],
        ];
    }

    public function attributes(): array
    {
        return [
            'name_first' => 'first name',
            'name_last' => 'last name',
        ];
    }

    public function messages(): array
    {
        return [
            'username.unique' => 'That username is already taken.',
            'name_first.not_regex' => 'Names cannot contain < or > characters.',
            'name_last.not_regex' => 'Names cannot contain < or > characters.',
            'password.min' => 'Your password must be at least 8 characters long.',
            'password.confirmed' => 'The two passwords don\'t match.',
            'accept_terms.accepted' => 'Please tick the box to agree to the Terms of Service, Privacy Policy and Acceptable Use Policy.',
        ];
    }

    /**
     * A password that is just the username or email is refused.
     */
    public function withValidator(\Illuminate\Validation\Validator $validator): void
    {
        $validator->after(function (\Illuminate\Validation\Validator $validator) {
            $password = mb_strtolower((string) $this->input('password'));
            if ($password === '' || $validator->errors()->has('password')) {
                return;
            }
            foreach (['username', 'email'] as $field) {
                if ($password === mb_strtolower((string) $this->input($field))) {
                    $validator->errors()->add('password', 'Your password can\'t be the same as your ' . $field . '.');
                }
            }
        });
    }

    protected function prepareForValidation(): void
    {
        $this->merge([
            'email' => is_string($this->input('email')) ? trim($this->input('email')) : $this->input('email'),
            'username' => is_string($this->input('username')) ? trim($this->input('username')) : $this->input('username'),
            'name_first' => is_string($this->input('name_first')) ? trim($this->input('name_first')) : $this->input('name_first'),
            'name_last' => is_string($this->input('name_last')) ? trim($this->input('name_last')) : $this->input('name_last'),
        ]);
    }
}
