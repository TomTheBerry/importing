<?php

namespace Pterodactyl\Http\Controllers\Auth;

use Carbon\Carbon;
use Carbon\CarbonImmutable;
use Carbon\CarbonInterface;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use PragmaRX\Google2FA\Google2FA;
use Pterodactyl\Facades\Activity;
use Illuminate\Support\Facades\Event;
use Illuminate\Contracts\Encryption\Encrypter;
use Pterodactyl\Services\Users\TwoFactorPolicy;
use Pterodactyl\Services\Users\EmailCodeService;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Pterodactyl\Events\Auth\ProvidedAuthenticationToken;
use Pterodactyl\Http\Requests\Auth\LoginCheckpointRequest;
use Illuminate\Contracts\Validation\Factory as ValidationFactory;

class LoginCheckpointController extends AbstractLoginController
{
    private const TOKEN_EXPIRED_MESSAGE = 'The authentication token provided has expired, please refresh the page and try again.';

    /**
     * LoginCheckpointController constructor.
     */
    public function __construct(
        private Encrypter $encrypter,
        private Google2FA $google2FA,
        private ValidationFactory $validation,
        private EmailCodeService $emailCodes,
    ) {
        parent::__construct();
    }

    /**
     * Handle a login where the user is required to provide a TOTP authentication
     * token. Once a user has reached this stage it is assumed that they have already
     * provided a valid username and password.
     *
     * @throws \PragmaRX\Google2FA\Exceptions\IncompatibleWithGoogleAuthenticatorException
     * @throws \PragmaRX\Google2FA\Exceptions\InvalidCharactersException
     * @throws \PragmaRX\Google2FA\Exceptions\SecretKeyTooShortException
     * @throws \Exception
     * @throws \Illuminate\Validation\ValidationException
     */
    public function __invoke(LoginCheckpointRequest $request): JsonResponse
    {
        if ($this->hasTooManyLoginAttempts($request)) {
            $this->sendLockoutResponse($request);
        }

        [$user, $details] = $this->resolveUser($request);
        $methods = $this->allowedMethods($user, $details);

        // Default to the authenticator app when it's available, as the old login form did.
        $method = $request->input('method') ?? ($methods[0] ?? null);
        if (!in_array($method, $methods, true)) {
            $this->sendFailedLoginResponse($request, $user, 'That verification method is not available for this account.');
        }

        if ($method === TwoFactorPolicy::EMAIL) {
            if ($this->emailCodes->verify($user, LoginController::emailPurpose($details['token_value']), $request->input('authentication_code'))) {
                Activity::event('auth:email-code')->withRequestMetadata()->subject($user)->log();

                return $this->sendLoginResponse($user, $request);
            }

            $this->sendFailedLoginResponse($request, $user, 'That code is not right or has expired. Check the latest email from us, or send a new code.');
        }

        // Recovery tokens go through a slightly different pathway for usage.
        if (!is_null($recoveryToken = $request->input('recovery_token'))) {
            if ($this->isValidRecoveryToken($user, $recoveryToken)) {
                Event::dispatch(new ProvidedAuthenticationToken($user, true));

                return $this->sendLoginResponse($user, $request);
            }
        } else {
            $decrypted = $this->encrypter->decrypt($user->totp_secret);
            $oldTimestamp = $user->totp_authenticated_at
                ? (int) floor($user->totp_authenticated_at->unix() / $this->google2FA->getKeyRegeneration())
                : null;

            $verified = $this->google2FA->verifyKeyNewer(
                $decrypted,
                (string) ($request->input('authentication_code') ?? ''),
                $oldTimestamp,
                config('pterodactyl.auth.2fa.window') ?? 1,
            );

            if ($verified !== false) {
                $user->update(['totp_authenticated_at' => Carbon::now()]);

                Event::dispatch(new ProvidedAuthenticationToken($user));

                return $this->sendLoginResponse($user, $request);
            }
        }

        $this->sendFailedLoginResponse($request, $user, !empty($recoveryToken) ? 'The recovery token provided is not valid.' : null);
    }

    /**
     * Emails (or re-sends) a login code for the login attempt in progress.
     *
     * @throws \Pterodactyl\Exceptions\DisplayException
     */
    public function email(Request $request): JsonResponse
    {
        if ($this->hasTooManyLoginAttempts($request)) {
            $this->sendLockoutResponse($request);
        }

        $request->validate(['confirmation_token' => 'required|string']);
        [$user, $details] = $this->resolveUser($request);

        if (!in_array(TwoFactorPolicy::EMAIL, $this->allowedMethods($user, $details), true)) {
            $this->sendFailedLoginResponse($request, $user, 'Email codes are not available for this account.');
        }

        $purpose = LoginController::emailPurpose($details['token_value']);
        $sent = $this->emailCodes->send($user, $purpose, 'finish logging in');

        return new JsonResponse([
            'data' => [
                'sent' => $sent,
                'email' => TwoFactorPolicy::maskEmail($user->email),
                'retry_after' => $this->emailCodes->cooldown($user, $purpose),
            ],
        ]);
    }

    /**
     * The methods this login may use: the user's current methods, narrowed to the ones
     * allowed when the checkpoint started (a login with a connected account can rule out
     * emailed codes).
     *
     * @return string[]
     */
    private function allowedMethods(User $user, array $details): array
    {
        $methods = TwoFactorPolicy::loginMethods($user);
        if (isset($details['methods']) && is_array($details['methods'])) {
            $methods = array_values(array_intersect($methods, $details['methods']));
        }

        return $methods;
    }

    /**
     * Finds the person part-way through logging in from their session.
     *
     * @return array{0: User, 1: array}
     */
    private function resolveUser(Request $request): array
    {
        $details = $request->session()->get('auth_confirmation_token');
        if (!$this->hasValidSessionData($details)) {
            $this->sendFailedLoginResponse($request, null, self::TOKEN_EXPIRED_MESSAGE);
        }

        if (!hash_equals($details['token_value'], (string) ($request->input('confirmation_token') ?? ''))) {
            $this->sendFailedLoginResponse($request);
        }

        try {
            /** @var User $user */
            $user = User::query()->findOrFail($details['user_id']);
        } catch (ModelNotFoundException) {
            $this->sendFailedLoginResponse($request, null, self::TOKEN_EXPIRED_MESSAGE);
        }

        return [$user, $details];
    }

    /**
     * Determines if a given recovery token is valid for the user account. If we find a matching token
     * it will be deleted from the database.
     *
     * @throws \Exception
     */
    protected function isValidRecoveryToken(User $user, string $value): bool
    {
        foreach ($user->recoveryTokens as $token) {
            if (password_verify($value, $token->token)) {
                $token->delete();

                return true;
            }
        }

        return false;
    }

    /**
     * Determines if the data provided from the session is valid or not. This
     * will return false if the data is invalid, or if more time has passed than
     * was configured when the session was written.
     */
    protected function hasValidSessionData(?array $data): bool
    {
        $validator = $this->validation->make($data ?? [], [
            'user_id' => 'required|integer|min:1',
            'token_value' => 'required|string',
            'expires_at' => 'required',
        ]);

        if ($validator->fails()) {
            return false;
        }

        if (!$data['expires_at'] instanceof CarbonInterface) {
            return false;
        }

        if ($data['expires_at']->isBefore(CarbonImmutable::now())) {
            return false;
        }

        return true;
    }
}
