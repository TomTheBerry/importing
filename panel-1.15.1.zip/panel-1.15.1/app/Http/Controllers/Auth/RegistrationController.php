<?php

namespace Pterodactyl\Http\Controllers\Auth;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Facades\Activity;
use Illuminate\Support\Facades\RateLimiter;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Validation\ValidationException;
use Pterodactyl\Http\Requests\Auth\RegisterRequest;
use Pterodactyl\Services\Users\RegistrationService;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\TooManyRequestsHttpException;

class RegistrationController extends Controller
{
    public const SESSION_KEY = 'registration.access_granted_at';

    /** Wrong access code guesses allowed per IP address before a lock out. */
    public const CODE_ATTEMPTS = 5;
    public const CODE_DECAY = 900;

    /** Registrations allowed per IP address per hour. */
    public const REGISTER_ATTEMPTS = 5;

    public function __construct(private RegistrationService $service)
    {
    }

    /**
     * Tells the registration page what to show. Never includes the access code.
     */
    public function status(Request $request): JsonResponse
    {
        return new JsonResponse([
            'enabled' => RegistrationService::enabled(),
            'requires_code' => RegistrationService::requiresAccessCode(),
            'code_accepted' => $this->hasAccess($request),
        ]);
    }

    /**
     * Checks the early access code and remembers a correct one in the session.
     */
    public function access(Request $request): JsonResponse
    {
        $this->ensureEnabled();

        $request->validate(['code' => ['required', 'string', 'max:191']]);

        if (!RegistrationService::requiresAccessCode()) {
            return new JsonResponse(['success' => true]);
        }

        $key = 'register:code:' . $request->ip();
        if (RateLimiter::tooManyAttempts($key, self::CODE_ATTEMPTS)) {
            $minutes = (int) ceil(RateLimiter::availableIn($key) / 60);

            throw new TooManyRequestsHttpException(RateLimiter::availableIn($key), "Too many incorrect access codes. Please try again in $minutes minute(s).");
        }

        if (!RegistrationService::accessCodeMatches($request->input('code'))) {
            RateLimiter::hit($key, self::CODE_DECAY);
            Activity::event('auth:register.code-failed')->withRequestMetadata()->log();

            throw ValidationException::withMessages(['code' => 'That access code is not valid.']);
        }

        RateLimiter::clear($key);
        $request->session()->regenerate();
        $request->session()->put(self::SESSION_KEY, now()->getTimestamp());

        return new JsonResponse(['success' => true]);
    }

    /**
     * Creates the account and emails a link to verify the address and set a password.
     */
    public function store(RegisterRequest $request): JsonResponse
    {
        $this->ensureEnabled();

        if (!$this->hasAccess($request)) {
            throw new AccessDeniedHttpException('Please enter a valid access code first.');
        }

        $key = 'register:create:' . $request->ip();
        if (RateLimiter::tooManyAttempts($key, self::REGISTER_ATTEMPTS)) {
            throw new TooManyRequestsHttpException(RateLimiter::availableIn($key), 'Too many accounts have been registered from your network. Please try again later.');
        }
        RateLimiter::hit($key, 3600);

        $this->service->handle($request->validated(), $request);

        return new JsonResponse(['success' => true, 'email' => $request->validated('email')], 202);
    }

    /**
     * Sends a new verification email to an account that has not finished registering.
     * Always gives the same response so it can't be used to discover accounts.
     */
    public function resend(Request $request): JsonResponse
    {
        $this->ensureEnabled();

        $request->validate(['email' => ['required', 'string', 'email', 'max:191']]);

        $key = 'register:resend:' . $request->ip();
        if (RateLimiter::tooManyAttempts($key, 5)) {
            throw new TooManyRequestsHttpException(RateLimiter::availableIn($key), 'Too many requests. Please wait a few minutes and try again.');
        }
        RateLimiter::hit($key, 900);

        /** @var User|null $user */
        $user = User::query()->where('email', $request->input('email'))->where('registration_pending', true)->first();
        if ($user && RateLimiter::attempt('register:resend:user:' . $user->id, 1, fn () => true, 120)) {
            $this->service->sendVerification($user);
        }

        return new JsonResponse(['success' => true]);
    }

    protected function ensureEnabled(): void
    {
        if (!RegistrationService::enabled()) {
            throw new NotFoundHttpException('Registration is currently disabled.');
        }
    }

    /**
     * Whether this browser session has entered the access code recently (or none is needed).
     */
    protected function hasAccess(Request $request): bool
    {
        if (!RegistrationService::requiresAccessCode()) {
            return true;
        }

        $grantedAt = (int) $request->session()->get(self::SESSION_KEY, 0);
        $lifetime = max(1, (int) config('pterodactyl.registration.access_code_lifetime', 30)) * 60;

        return $grantedAt > 0 && (now()->getTimestamp() - $grantedAt) <= $lifetime;
    }
}
