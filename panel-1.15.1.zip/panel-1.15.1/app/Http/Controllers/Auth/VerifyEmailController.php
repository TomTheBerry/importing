<?php

namespace Pterodactyl\Http\Controllers\Auth;

use Pterodactyl\Models\User;
use Pterodactyl\Facades\Activity;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class VerifyEmailController extends Controller
{
    /**
     * Handles the link from a "verify your email" email. The URL is signed and expires,
     * and the hash must match the account's CURRENT email, so old links stop working
     * if the email changes again.
     */
    public function __invoke(string $uuid, string $hash): RedirectResponse
    {
        /** @var User|null $user */
        $user = User::query()->where('uuid', $uuid)->first();

        if (!$user || !hash_equals(sha1(mb_strtolower($user->email)), $hash)) {
            throw new AccessDeniedHttpException('This verification link is not valid.');
        }

        if (!$user->hasVerifiedEmail()) {
            $user->forceFill(['email_verified_at' => now()])->saveOrFail();

            Activity::event('user:account.email-verified')->subject($user)->log();
        }

        return redirect()->to(auth()->check() ? '/account?email_verified=1' : '/auth/login?email_verified=1');
    }
}
