<?php

namespace Pterodactyl\Http\Controllers\Auth;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Facades\Activity;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Models\UserConnection;
use Illuminate\Database\QueryException;
use Pterodactyl\Services\Users\TwoFactorPolicy;
use Pterodactyl\Services\Auth\OAuth\OAuthService;
use Pterodactyl\Services\Auth\OAuth\OAuthIdentity;
use Pterodactyl\Services\Auth\OAuth\OAuthException;
use Pterodactyl\Services\Auth\OAuth\OAuthProviders;
use Pterodactyl\Notifications\AccountConnectionChanged;

/**
 * Logging in with, and connecting, Google / GitHub / Discord accounts.
 *
 * A provider account can only log someone in once they have connected it from their
 * account while logged in. It is never used to create accounts, and accounts are never
 * matched by email address. Logging in this way replaces only the password: two-step
 * verification is still required exactly as for a password login.
 */
class OAuthController extends AbstractLoginController
{
    private const CHECKPOINT_KEY = 'oauth_checkpoint';

    public function __construct(private OAuthService $oauth)
    {
        parent::__construct();
    }

    /**
     * Sends someone to the provider to log in.
     */
    public function redirect(Request $request, string $provider): RedirectResponse
    {
        try {
            return redirect()->away($this->oauth->start($request, $provider, OAuthService::INTENT_LOGIN));
        } catch (OAuthException $exception) {
            return $this->loginError($exception->reason);
        }
    }

    /**
     * Where the provider sends people back, for both logging in and connecting.
     */
    public function callback(Request $request, string $provider): RedirectResponse
    {
        $intent = $this->oauth->pendingIntent($request);

        try {
            $result = $this->oauth->finish($request, $provider);
        } catch (OAuthException $exception) {
            $intent = $exception->intent ?? $intent;

            return $intent === OAuthService::INTENT_LINK
                ? $this->connectionsResult(null, $exception->reason)
                : $this->loginError($exception->reason);
        }

        return $result['intent'] === OAuthService::INTENT_LINK
            ? $this->linkIdentity($request, $result['user_id'], $result['identity'])
            : $this->loginWithIdentity($request, $result['identity']);
    }

    /**
     * Gives the login page what it needs to show the two-step verification step after a
     * provider login. Can only be read once.
     */
    public function checkpoint(Request $request): JsonResponse
    {
        $data = $request->session()->pull(self::CHECKPOINT_KEY);
        $session = $request->session()->get('auth_confirmation_token');

        if (!is_array($data) || !is_array($session) || !hash_equals((string) ($session['token_value'] ?? ''), (string) ($data['confirmation_token'] ?? ''))) {
            return new JsonResponse(['data' => null]);
        }

        return new JsonResponse(['data' => $data]);
    }

    private function loginWithIdentity(Request $request, OAuthIdentity $identity): RedirectResponse
    {
        if ($this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);

            return $this->loginError('locked');
        }

        /** @var UserConnection|null $connection */
        $connection = UserConnection::query()
            ->where('provider', $identity->provider)
            ->where('provider_user_id', $identity->id)
            ->first();

        /** @var User|null $user */
        $user = $connection?->user;
        if (!$connection || !$user || $user->registration_pending) {
            // Never sign people up or match by email: the account has to be connected first.
            $this->incrementLoginAttempts($request);
            Activity::event('auth:oauth-unknown')->withRequestMetadata()->property('provider', OAuthProviders::label($identity->provider))->log();

            return $this->loginError('not_connected');
        }

        $connection->forceFill([
            'last_used_at' => Carbon::now(),
            'username' => $identity->username ?? $connection->username,
            'email' => $identity->email ?? $connection->email,
        ])->save();

        Activity::event('auth:oauth')->withRequestMetadata()->subject($user)->property('provider', OAuthProviders::label($identity->provider))->log();

        // The connected account stands in for the password only. Two-step verification still applies.
        $methods = TwoFactorPolicy::loginMethods($user);
        if (!empty($methods)) {
            // If the Google account IS their email inbox, an emailed code would come from the
            // same account they just used, so it doesn't count as a second step.
            $exclude = $this->sharesInbox($user, $identity) ? [TwoFactorPolicy::EMAIL] : [];
            if (empty(array_diff($methods, $exclude))) {
                Activity::event('auth:oauth-blocked')->withRequestMetadata()->subject($user)->property('provider', OAuthProviders::label($identity->provider))->log();

                return $this->loginError('use_password');
            }

            $payload = $this->startCheckpoint($user, $request, ['via' => $identity->provider], $exclude);
            $request->session()->put(self::CHECKPOINT_KEY, $payload);

            return redirect()->to('/auth/login?oauth=checkpoint');
        }

        if ($this->completeLogin($user, $request)) {
            return redirect()->to('/account/privacy?restored=1');
        }

        return redirect()->intended('/');
    }

    private function linkIdentity(Request $request, ?int $userId, OAuthIdentity $identity): RedirectResponse
    {
        /** @var User|null $user */
        $user = $request->user();

        // The flow must finish in the same logged in session that started it.
        if (!$user || !$userId || $user->id !== $userId) {
            return $this->connectionsResult(null, 'expired');
        }

        $label = OAuthProviders::label($identity->provider);

        $taken = UserConnection::query()
            ->where('provider', $identity->provider)
            ->where('provider_user_id', $identity->id)
            ->first();
        if ($taken) {
            // Don't reveal anything about another person's account.
            return $this->connectionsResult(null, $taken->user_id === $user->id ? 'already_connected' : 'in_use');
        }

        if ($user->connections()->where('provider', $identity->provider)->exists()) {
            return $this->connectionsResult(null, 'provider_connected');
        }

        try {
            $user->connections()->create([
                'provider' => $identity->provider,
                'provider_user_id' => $identity->id,
                'username' => $identity->username,
                'email' => $identity->email,
            ]);
        } catch (QueryException) {
            // Lost a race with another request; the unique indexes stopped a duplicate.
            return $this->connectionsResult(null, 'in_use');
        }

        Activity::event('user:connection.create')
            ->withRequestMetadata()
            ->subject($user)
            ->property(['provider' => $label, 'account' => $identity->username])
            ->log();

        $user->notify(new AccountConnectionChanged($label, $identity->username, true));

        return $this->connectionsResult($identity->provider, null);
    }

    /**
     * True when the provider account may be able to read the panel account's email, in
     * which case an emailed code isn't a separate second step. Errs on the side of yes.
     */
    private function sharesInbox(User $user, OAuthIdentity $identity): bool
    {
        if ($identity->provider !== 'google') {
            return false;
        }

        $panel = OAuthProviders::canonicalEmail($user->email);
        foreach ([$identity->inboxEmail, $identity->email] as $email) {
            if ($email !== null && OAuthProviders::canonicalEmail($email) === $panel) {
                return true;
            }
        }

        // A Google Workspace account on the same domain as the panel email (aliases, groups
        // and shared inboxes there are often readable by it).
        $domain = mb_strtolower((string) substr(strrchr($user->email, '@') ?: '', 1));

        return $identity->hostedDomain !== null && $domain !== '' && mb_strtolower($identity->hostedDomain) === $domain;
    }

    private function loginError(string $reason): RedirectResponse
    {
        return redirect()->to('/auth/login?oauth_error=' . rawurlencode($reason));
    }

    private function connectionsResult(?string $connected, ?string $error): RedirectResponse
    {
        return redirect()->to('/account/connections?' . http_build_query(array_filter([
            'connected' => $connected,
            'error' => $error,
        ])));
    }
}
