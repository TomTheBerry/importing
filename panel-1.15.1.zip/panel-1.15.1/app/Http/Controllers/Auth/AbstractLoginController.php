<?php

namespace Pterodactyl\Http\Controllers\Auth;

use Carbon\CarbonImmutable;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Auth\AuthManager;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Facades\Activity;
use Illuminate\Auth\Events\Failed;
use Illuminate\Container\Container;
use Illuminate\Support\Facades\Event;
use Pterodactyl\Events\Auth\DirectLogin;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Contracts\Auth\Authenticatable;
use Pterodactyl\Services\Users\TwoFactorPolicy;
use Pterodactyl\Services\Privacy\PrivacyService;
use Pterodactyl\Services\Users\EmailCodeService;
use Pterodactyl\Services\Sessions\SessionService;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Pterodactyl\Services\Sessions\LoginAlertService;

abstract class AbstractLoginController extends Controller
{
    use AuthenticatesUsers;

    protected AuthManager $auth;

    /**
     * Lockout time for failed login requests.
     */
    protected int $lockoutTime;

    /**
     * After how many attempts should logins be throttled and locked.
     */
    protected int $maxLoginAttempts;

    /**
     * Where to redirect users after login / registration.
     */
    protected string $redirectTo = '/';

    /**
     * LoginController constructor.
     */
    public function __construct()
    {
        $this->lockoutTime = config('auth.lockout.time');
        $this->maxLoginAttempts = config('auth.lockout.attempts');
        $this->auth = Container::getInstance()->make(AuthManager::class);
    }

    /**
     * Get the failed login response instance.
     *
     * @return never-return
     *
     * @throws DisplayException
     */
    protected function sendFailedLoginResponse(Request $request, ?Authenticatable $user = null, ?string $message = null)
    {
        $this->incrementLoginAttempts($request);
        $this->fireFailedLoginEvent($user, [
            $this->getField($request->input('user')) => $request->input('user'),
        ]);

        if ($request->route()->named('auth.login-checkpoint', 'auth.login-checkpoint.email')) {
            throw new DisplayException($message ?? trans('auth.two_factor.checkpoint_failed'));
        }

        throw new DisplayException(trans('auth.failed'));
    }

    /**
     * Send the response after the user was authenticated.
     */
    protected function sendLoginResponse(User $user, Request $request): JsonResponse
    {
        $restored = $this->completeLogin($user, $request);

        return new JsonResponse([
            'data' => [
                'complete' => true,
                'intended' => $restored ? '/account/privacy?restored=1' : $this->redirectPath(),
                'user' => $user->toVueObject(),
            ],
        ]);
    }

    /**
     * Logs the user in once every check has passed. Returns true when logging in
     * cancelled a scheduled account deletion.
     */
    protected function completeLogin(User $user, Request $request): bool
    {
        $request->session()->forget(['auth_confirmation_token', 'oauth_flow', 'oauth_checkpoint']);
        $request->session()->regenerate();

        $this->clearLoginAttempts($request);

        $this->auth->guard()->login($user, true);

        Event::dispatch(new DirectLogin($user, true));

        // Show this session in the account's list, and email them if it's a new device.
        app(SessionService::class)->track($request, $user);
        app(LoginAlertService::class)->check($user, $request);

        // Logging back in within 14 days keeps the account.
        return app(PrivacyService::class)->cancelDeletion($user);
    }

    /**
     * Starts the two-step verification checkpoint for someone who has proved who they are
     * (with their password, or a connected account) and returns what the login page needs
     * to show it. When an emailed code is the only way in, it is sent straight away.
     */
    protected function startCheckpoint(User $user, Request $request, array $properties = [], array $exclude = []): array
    {
        $methods = array_values(array_diff(TwoFactorPolicy::loginMethods($user), $exclude));

        Activity::event('auth:checkpoint')->withRequestMetadata()->subject($user)->property(array_merge(['methods' => $methods], $properties))->log();

        $token = Str::random(64);
        $request->session()->put('auth_confirmation_token', [
            'user_id' => $user->id,
            'token_value' => $token,
            'methods' => $methods,
            // Emails can take a minute to arrive, so allow a little longer for them.
            'expires_at' => CarbonImmutable::now()->addMinutes(in_array(TwoFactorPolicy::EMAIL, $methods) ? EmailCodeService::LIFETIME_MINUTES : 5),
        ]);

        $emailSent = false;
        if ($methods === [TwoFactorPolicy::EMAIL]) {
            $emailSent = app(EmailCodeService::class)->send($user, LoginController::emailPurpose($token), 'finish logging in');
        }

        return [
            'complete' => false,
            'confirmation_token' => $token,
            'methods' => $methods,
            'email' => in_array(TwoFactorPolicy::EMAIL, $methods) ? TwoFactorPolicy::maskEmail($user->email) : null,
            'email_sent' => $emailSent,
            'app_name' => $user->use_totp ? $user->totp_app_name : null,
            // True when two-step verification is required but not set up yet: they will be
            // asked to set it up as soon as they are in.
            'setup_required' => !TwoFactorPolicy::satisfied($user),
        ];
    }

    /**
     * Determine if the user is logging in using an email or username.
     */
    protected function getField(?string $input = null): string
    {
        return ($input && str_contains($input, '@')) ? 'email' : 'username';
    }

    /**
     * Fire a failed login event.
     */
    protected function fireFailedLoginEvent(?Authenticatable $user = null, array $credentials = [])
    {
        Event::dispatch(new Failed('auth', $user, $credentials));
    }
}
