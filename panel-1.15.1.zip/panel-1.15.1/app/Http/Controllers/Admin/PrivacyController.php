<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\PrivacyRequest;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Privacy\PrivacyService;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Admin -> Privacy: data requests to answer and accounts waiting to be deleted.
 */
class PrivacyController extends Controller
{
    public function __construct(private AlertsMessageBag $alert, private PrivacyService $privacy)
    {
    }

    public function index(Request $request): View
    {
        $tab = $request->query('tab') === 'deletions' ? 'deletions' : 'requests';
        $show = $request->query('show') === 'all' ? 'all' : 'open';
        $type = $tab === 'deletions' ? PrivacyRequest::TYPE_DELETION : PrivacyRequest::TYPE_EXPORT;

        $query = PrivacyRequest::query()->where('type', $type)->with(['user', 'handler']);
        if ($show === 'open') {
            $query->open();
        }

        $requests = $query
            ->orderByRaw("CASE WHEN status IN ('pending','scheduled','failed') THEN 0 ELSE 1 END")
            ->orderBy('due_at')
            ->orderByDesc('id')
            ->paginate(25)
            ->withQueryString();

        return view('admin.privacy.index', [
            'tab' => $tab,
            'show' => $show,
            'requests' => $requests,
            'stats' => [
                'pending' => PrivacyRequest::query()->where('type', PrivacyRequest::TYPE_EXPORT)->where('status', PrivacyRequest::STATUS_PENDING)->count(),
                'overdue' => PrivacyRequest::query()->where('type', PrivacyRequest::TYPE_EXPORT)->where('status', PrivacyRequest::STATUS_PENDING)->where('due_at', '<', now())->count(),
                'scheduled' => PrivacyRequest::query()->where('type', PrivacyRequest::TYPE_DELETION)->whereIn('status', [PrivacyRequest::STATUS_SCHEDULED, PrivacyRequest::STATUS_FAILED])->count(),
                'deleted' => PrivacyRequest::query()->where('type', PrivacyRequest::TYPE_DELETION)->where('status', PrivacyRequest::STATUS_DELETED)->where('handled_at', '>=', now()->subDays(30))->count(),
            ],
        ]);
    }

    public function send(Request $request, PrivacyRequest $privacyRequest): RedirectResponse
    {
        $this->privacy->sendExport($privacyRequest, $request->user());
        $this->alert->success("A copy of {$privacyRequest->label}'s data was created and they have been emailed a download link.")->flash();

        return redirect()->route('admin.privacy');
    }

    public function decline(Request $request, PrivacyRequest $privacyRequest): RedirectResponse
    {
        $data = $request->validate(['reason' => 'required|string|min:10|max:2000']);
        $this->privacy->declineExport($privacyRequest, $request->user(), $data['reason']);
        $this->alert->info("The request from {$privacyRequest->label} was declined and they have been told why.")->flash();

        return redirect()->route('admin.privacy');
    }

    public function extend(Request $request, PrivacyRequest $privacyRequest): RedirectResponse
    {
        $data = $request->validate(['reason' => 'required|string|min:10|max:2000']);
        $this->privacy->extendExport($privacyRequest, $request->user(), $data['reason']);
        $this->alert->info("The deadline for {$privacyRequest->label}'s request was extended and they have been told.")->flash();

        return redirect()->route('admin.privacy');
    }

    public function cancelDeletion(Request $request, PrivacyRequest $privacyRequest): RedirectResponse
    {
        $data = $request->validate(['reason' => 'required|string|min:5|max:2000']);

        /** @var User|null $user */
        $user = $privacyRequest->user;
        if ($privacyRequest->type !== PrivacyRequest::TYPE_DELETION || !$user || !in_array($privacyRequest->status, [PrivacyRequest::STATUS_SCHEDULED, PrivacyRequest::STATUS_FAILED], true)) {
            throw new NotFoundHttpException();
        }
        if (!$request->user()->canManageUser($user)) {
            throw new \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException('You cannot manage this user.');
        }

        $this->privacy->cancelDeletion($user, $request->user(), $data['reason']);
        $this->alert->success("{$user->username}'s account will no longer be deleted. They have been emailed.")->flash();

        return redirect()->route('admin.privacy', ['tab' => 'deletions']);
    }
}
