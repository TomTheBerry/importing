<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Pterodactyl\Facades\Activity;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\Support\Ticket;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Support\TicketCategory;

/**
 * Admin -> Tickets -> Topics: the reasons people choose from when opening a ticket, on
 * the Panel and in Discord's dropdown.
 */
class TicketCategoryController extends Controller
{
    // Discord dropdowns can show at most 25 options.
    public const MAX_ACTIVE = 25;

    public function __construct(private AlertsMessageBag $alert)
    {
    }

    public function index(): View
    {
        $categories = TicketCategory::query()->orderBy('sort')->orderBy('id')->get();
        $counts = Ticket::query()->selectRaw('category_id, COUNT(*) as total')->groupBy('category_id')->pluck('total', 'category_id');

        return view('admin.tickets.categories', ['categories' => $categories, 'counts' => $counts]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validated($request);
        if ($data['is_active'] && TicketCategory::query()->where('is_active', true)->count() >= self::MAX_ACTIVE) {
            $this->alert->danger('You can have up to ' . self::MAX_ACTIVE . ' topics turned on (Discord\'s limit). Turn one off first.')->flash();

            return redirect()->route('admin.tickets.categories')->withInput();
        }

        $category = TicketCategory::query()->create($data);
        Activity::event('admin:ticket-category.create')->subject($category)->property(['name' => $category->name])->log();
        $this->alert->success('Topic added.')->flash();

        return redirect()->route('admin.tickets.categories');
    }

    public function update(Request $request, TicketCategory $category): RedirectResponse
    {
        $data = $this->validated($request);
        if ($data['is_active'] && !$category->is_active && TicketCategory::query()->where('is_active', true)->count() >= self::MAX_ACTIVE) {
            $this->alert->danger('You can have up to ' . self::MAX_ACTIVE . ' topics turned on (Discord\'s limit). Turn one off first.')->flash();

            return redirect()->route('admin.tickets.categories');
        }

        $category->update($data);
        Activity::event('admin:ticket-category.update')->subject($category)->property(['name' => $category->name])->log();
        $this->alert->success('Topic saved.')->flash();

        return redirect()->route('admin.tickets.categories');
    }

    public function delete(TicketCategory $category): RedirectResponse
    {
        // Tickets keep working; they just show no topic.
        $name = $category->name;
        $category->delete();
        Activity::event('admin:ticket-category.delete')->property(['name' => $name])->log();
        $this->alert->info('Topic deleted.')->flash();

        return redirect()->route('admin.tickets.categories');
    }

    private function validated(Request $request): array
    {
        $data = $request->validate([
            'name' => 'required|string|max:64',
            'description' => 'nullable|string|max:100',
            // Only real emoji (no text), as that's all Discord accepts in dropdowns.
            'emoji' => ['nullable', 'string', 'max:16', 'regex:/^[^\x00-\x7F]+$/u'],
            'sort' => 'nullable|integer|min:0|max:999',
            'is_active' => 'sometimes|boolean',
        ], ['emoji.regex' => 'The emoji must be a single emoji, like 💳.']);

        return [
            'name' => trim($data['name']),
            'description' => isset($data['description']) ? trim($data['description']) : null,
            'emoji' => isset($data['emoji']) ? trim($data['emoji']) : null,
            'sort' => (int) ($data['sort'] ?? 0),
            'is_active' => (bool) ($data['is_active'] ?? false),
        ];
    }
}
