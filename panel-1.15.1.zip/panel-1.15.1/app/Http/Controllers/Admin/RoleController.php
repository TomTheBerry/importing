<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Models\AdminRole;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Acl\AdminPermissions;
use Pterodactyl\Services\Roles\RevokeStaffAccessService;
use Pterodactyl\Http\Requests\Admin\AdminRoleFormRequest;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class RoleController extends Controller
{
    public function __construct(
        protected AlertsMessageBag $alert,
        protected RevokeStaffAccessService $revokeService,
    ) {
    }

    /**
     * Lists every role on the Panel.
     */
    public function index(Request $request): View
    {
        $roles = AdminRole::query()->withCount('users')->orderBy('name')->get();

        return view('admin.roles.index', [
            'roles' => $roles,
            'rootAdmins' => User::query()->where('root_admin', true)->count(),
            'panelCount' => count(AdminPermissions::panelKeys()),
            'serverCount' => count(AdminPermissions::serverKeys()),
        ]);
    }

    /**
     * Shows the form for creating a new role.
     */
    public function create(Request $request): View
    {
        return view('admin.roles.edit', $this->formData($request->user(), null));
    }

    /**
     * Shows a role and its members.
     */
    public function view(Request $request, AdminRole $role): View
    {
        return view('admin.roles.edit', $this->formData($request->user(), $role));
    }

    /**
     * Creates a new role.
     */
    public function store(AdminRoleFormRequest $request): RedirectResponse
    {
        $data = $request->roleData();
        $this->assertCanGrant($request->user(), $data['permissions']);

        $role = AdminRole::query()->create($data);

        $this->alert->success("The \"$role->name\" role was created.")->flash();

        return redirect()->route('admin.roles.view', $role->id);
    }

    /**
     * Creates a copy of an existing role.
     */
    public function duplicate(Request $request, AdminRole $role): RedirectResponse
    {
        $this->assertCanGrant($request->user(), $role->getPermissionList());

        $name = $role->name . ' (Copy)';
        for ($i = 2; AdminRole::query()->where('name', $name)->exists(); ++$i) {
            $name = $role->name . " (Copy $i)";
        }

        $copy = AdminRole::query()->create([
            'name' => mb_substr($name, 0, 191),
            'description' => $role->description,
            'color' => $role->color,
            'permissions' => $role->getPermissionList(),
            'require_totp' => $role->require_totp,
        ]);

        $this->alert->success("The \"$role->name\" role was duplicated.")->flash();

        return redirect()->route('admin.roles.view', $copy->id);
    }

    /**
     * Updates a role.
     */
    public function update(AdminRoleFormRequest $request, AdminRole $role): RedirectResponse
    {
        $user = $request->user();
        $this->assertCanModify($user, $role);

        $data = $request->roleData();
        $this->assertCanGrant($user, $data['permissions']);

        $before = $role->getPermissionList();
        $role->forceFill($data)->saveOrFail();

        // If permissions changed, disconnect members from SFTP/websockets on every node
        // so they reconnect with their new set of permissions.
        if ($before != $role->getPermissionList()) {
            $this->revokeService->handle($role->users()->get());
        }

        $this->alert->success("The \"$role->name\" role was updated.")->flash();

        return redirect()->route('admin.roles.view', $role->id);
    }

    /**
     * Deletes a role. Users with this role simply lose their staff access.
     */
    public function delete(Request $request, AdminRole $role): RedirectResponse
    {
        $this->assertCanModify($request->user(), $role);

        $members = $role->users()->get();
        $name = $role->name;

        $role->delete();
        $this->revokeService->handle($members);

        $this->alert->success("The \"$name\" role was deleted and removed from {$members->count()} user(s).")->flash();

        return redirect()->route('admin.roles');
    }

    /**
     * Staff can only grant permissions they hold themselves.
     */
    protected function assertCanGrant(User $user, array $permissions): void
    {
        if (!$user->holdsAllAdminPermissions($permissions)) {
            throw new AccessDeniedHttpException('You cannot grant permissions that your own role does not have.');
        }
    }

    /**
     * Staff cannot edit their own role, or a role with permissions they do not have.
     */
    protected function assertCanModify(User $user, AdminRole $role): void
    {
        if ($user->root_admin) {
            return;
        }

        if ($user->admin_role_id === $role->id) {
            throw new AccessDeniedHttpException('You cannot modify your own role. Ask another administrator to do this.');
        }

        if (!$user->holdsAllAdminPermissions($role->getPermissionList())) {
            throw new AccessDeniedHttpException('You cannot modify a role that has permissions your own role does not have.');
        }
    }

    /**
     * Builds the data needed to render the role editor.
     */
    protected function formData(User $user, ?AdminRole $role): array
    {
        $editable = true;
        $reason = null;
        if ($role && !$user->root_admin) {
            if ($user->admin_role_id === $role->id) {
                [$editable, $reason] = [false, 'This is your own role. Another administrator must make changes to it.'];
            } elseif (!$user->holdsAllAdminPermissions($role->getPermissionList())) {
                [$editable, $reason] = [false, 'This role has permissions that your role does not have, so you cannot change it.'];
            }
        }

        if ($role && !$user->hasAdminPermission('roles.update')) {
            [$editable, $reason] = [false, $reason ?? 'Your role does not allow you to edit roles.'];
        }

        return [
            'role' => $role,
            'selected' => $role ? $role->getPermissionList() : [],
            'members' => $role ? $role->users()->orderBy('username')->get() : collect(),
            'panelGroups' => AdminPermissions::panelGroups(),
            'serverGroups' => AdminPermissions::serverGroups(),
            'dangerous' => AdminPermissions::dangerous(),
            'viewAllKey' => AdminPermissions::VIEW_ALL_SERVERS,
            // Permissions the current user is not allowed to grant are shown but disabled.
            'grantable' => $user->root_admin ? AdminPermissions::all() : $user->getAdminPermissions(),
            'editable' => $editable,
            'readonlyReason' => $reason,
        ];
    }
}
