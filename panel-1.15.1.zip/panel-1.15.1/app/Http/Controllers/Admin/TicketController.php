<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Facades\Activity;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\Support\Ticket;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Support\TicketCategory;
use Pterodactyl\Services\Support\DiscordBridge;
use Pterodactyl\Services\Support\TicketService;
use Pterodactyl\Services\Support\TicketStatsService;
use Pterodactyl\Http\Controllers\Api\Discord\BotController;

/**
 * Admin -> Tickets: support tickets from the Panel and Discord.
 */
class TicketController extends Controller
{
    public function __construct(private AlertsMessageBag $alert, private TicketService $service)
    {
    }

    public function index(Request $request): View
    {
        /** @var User $me */
        $me = $request->user();
        $status = (string) $request->query('status', 'active');
        $search = trim((string) $request->query('search', ''));

        $query = Ticket::query()->with(['user', 'category', 'assignee']);

        match ($status) {
            'open' => $query->where('status', Ticket::STATUS_OPEN),
            'answered' => $query->where('status', Ticket::STATUS_ANSWERED),
            'closed' => $query->where('status', Ticket::STATUS_CLOSED),
            'mine' => $query->where('assigned_to', $me->id)->where('status', '!=', Ticket::STATUS_CLOSED),
            'unassigned' => $query->whereNull('assigned_to')->where('status', '!=', Ticket::STATUS_CLOSED),
            'all' => null,
            default => $query->where('status', '!=', Ticket::STATUS_CLOSED),
        };

        if ($category = (int) $request->query('category')) {
            $query->where('category_id', $category);
        }
        if (array_key_exists($priority = (string) $request->query('priority'), Ticket::PRIORITIES)) {
            $query->where('priority', $priority);
        }
        if ($search !== '') {
            $number = (int) ltrim($search, '#0');
            $query->where(function ($q) use ($search, $number) {
                $q->where('subject', 'like', '%' . addcslashes($search, '%_\\') . '%')
                    ->orWhere('guest_name', 'like', '%' . addcslashes($search, '%_\\') . '%')
                    ->orWhereHas('user', fn ($u) => $u->where('username', 'like', '%' . addcslashes($search, '%_\\') . '%')->orWhere('email', 'like', '%' . addcslashes($search, '%_\\') . '%'));
                if ($number > 0) {
                    $q->orWhere('id', $number);
                }
            });
        }

        // Waiting for staff first, then most urgent, then oldest waiting.
        $tickets = $query
            ->orderByRaw("CASE status WHEN 'open' THEN 0 WHEN 'answered' THEN 1 ELSE 2 END")
            ->orderByRaw("CASE priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END")
            ->orderBy('last_message_at', $status === 'closed' ? 'desc' : 'asc')
            ->paginate(30)
            ->withQueryString();

        $counts = [
            'open' => Ticket::query()->where('status', Ticket::STATUS_OPEN)->count(),
            'answered' => Ticket::query()->where('status', Ticket::STATUS_ANSWERED)->count(),
            'mine' => Ticket::query()->where('assigned_to', $me->id)->where('status', '!=', Ticket::STATUS_CLOSED)->count(),
            'unassigned' => Ticket::query()->whereNull('assigned_to')->where('status', '!=', Ticket::STATUS_CLOSED)->count(),
        ];

        return view('admin.tickets.index', [
            'tickets' => $tickets,
            'status' => $status,
            'search' => $search,
            'counts' => $counts,
            'categories' => TicketCategory::query()->orderBy('sort')->orderBy('id')->get(),
            'bot' => DiscordBridge::enabled() ? BotController::status() : null,
        ]);
    }

    public function stats(Request $request, TicketStatsService $stats): View
    {
        $days = (int) $request->query('days', 30);
        if (!array_key_exists($days, TicketStatsService::RANGES)) {
            $days = 30;
        }

        return view('admin.tickets.stats', [
            'now' => $stats->now(),
            'period' => $stats->period($days),
            'days' => $days,
        ]);
    }

    public function view(Request $request, Ticket $ticket): View
    {
        $ticket->load(['user.adminRole', 'category', 'assignee', 'server', 'closer']);
        $messages = $ticket->messages()->with(['user.adminRole', 'attachments'])->get();

        $customer = $ticket->user;
        $other = $customer
            ? Ticket::query()->where('user_id', $customer->id)->where('id', '!=', $ticket->id)->orderByDesc('id')->limit(8)->get()
            : Ticket::query()->whereNull('user_id')->where('guest_discord_id', $ticket->guest_discord_id)->where('id', '!=', $ticket->id)->orderByDesc('id')->limit(8)->get();

        $staff = User::query()->where(fn ($q) => $q->where('root_admin', true)->orWhereNotNull('admin_role_id'))
            ->with('adminRole')->orderBy('username')->get()
            ->filter(fn (User $u) => DiscordBridge::isStaff($u))->values();

        return view('admin.tickets.view', [
            'ticket' => $ticket,
            'messages' => $messages,
            'customer' => $customer,
            'customerDiscord' => $customer ? DiscordBridge::discordIdFor($customer) : $ticket->guest_discord_id,
            'servers' => $customer ? $customer->servers()->count() : 0,
            'services' => $customer ? $customer->subscriptions()->count() : 0,
            'otherTickets' => $other,
            'staff' => $staff,
            'categories' => TicketCategory::query()->orderBy('sort')->orderBy('id')->get(),
            'me' => $request->user(),
        ]);
    }

    public function reply(Request $request, Ticket $ticket): RedirectResponse
    {
        $data = $request->validate([
            'message' => 'required_without:files|nullable|string|max:10000',
            'internal' => 'sometimes|boolean',
            'close' => 'sometimes|boolean',
            'files' => 'nullable|array',
            'files.*' => 'file',
        ]);
        $internal = (bool) ($data['internal'] ?? false);

        try {
            $this->service->replyFromPanel($ticket, $request->user(), true, trim((string) ($data['message'] ?? '')), $request->file('files', []), $internal);

            // "Reply and close" in one go.
            if (!$internal && ($data['close'] ?? false)) {
                $this->service->close($ticket, $request->user());
            }
        } catch (DisplayException $exception) {
            $this->alert->danger($exception->getMessage())->flash();

            return redirect()->route('admin.tickets.view', $ticket->id)->withInput();
        }

        $this->alert->success($internal ? 'Internal note added. Only staff can see it.' : 'Reply sent.')->flash();

        return redirect()->to(route('admin.tickets.view', $ticket->id) . '#latest');
    }

    public function claim(Request $request, Ticket $ticket): RedirectResponse
    {
        /** @var User $me */
        $me = $request->user();
        if ($ticket->assigned_to && $ticket->assigned_to !== $me->id && !$me->hasAdminPermission('tickets.manage')) {
            $this->alert->danger('Someone else is already handling this ticket.')->flash();

            return redirect()->route('admin.tickets.view', $ticket->id);
        }
        $this->service->assign($ticket, $ticket->assigned_to === $me->id ? null : $me, $me);

        return redirect()->route('admin.tickets.view', $ticket->id);
    }

    public function assign(Request $request, Ticket $ticket): RedirectResponse
    {
        $data = $request->validate(['assigned_to' => 'nullable|integer']);
        $staff = !empty($data['assigned_to']) ? User::query()->find((int) $data['assigned_to']) : null;

        try {
            $this->service->assign($ticket, $staff, $request->user());
        } catch (DisplayException $exception) {
            $this->alert->danger($exception->getMessage())->flash();
        }

        return redirect()->route('admin.tickets.view', $ticket->id);
    }

    public function update(Request $request, Ticket $ticket): RedirectResponse
    {
        $data = $request->validate([
            'priority' => 'sometimes|string|in:' . implode(',', array_keys(Ticket::PRIORITIES)),
            'category_id' => 'sometimes|nullable|integer',
            'subject' => 'sometimes|string|min:3|max:120',
        ]);

        try {
            $this->service->update($ticket, $data);
            $this->alert->success('Ticket updated.')->flash();
        } catch (DisplayException $exception) {
            $this->alert->danger($exception->getMessage())->flash();
        }

        return redirect()->route('admin.tickets.view', $ticket->id);
    }

    public function close(Request $request, Ticket $ticket): RedirectResponse
    {
        $data = $request->validate(['reason' => 'nullable|string|max:191']);
        $this->service->close($ticket, $request->user(), $data['reason'] ?? null);
        $this->alert->success('Ticket closed. Its Discord channel will be removed; the conversation stays here.')->flash();

        return redirect()->route('admin.tickets.view', $ticket->id);
    }

    public function reopen(Request $request, Ticket $ticket): RedirectResponse
    {
        $this->service->reopen($ticket, $request->user(), true);
        $this->alert->success('Ticket reopened.')->flash();

        return redirect()->route('admin.tickets.view', $ticket->id);
    }

    public function link(Request $request, Ticket $ticket): RedirectResponse
    {
        $data = $request->validate(['user' => 'required|string|max:191']);
        $value = trim($data['user']);

        /** @var User|null $user */
        $user = User::query()->where('email', $value)->orWhere('username', $value)->first();
        if (!$user) {
            $this->alert->danger('No account found with that username or email.')->flash();

            return redirect()->route('admin.tickets.view', $ticket->id);
        }

        try {
            $this->service->linkGuest($ticket, $user);
            $this->alert->success("Ticket linked to {$user->username}.")->flash();
        } catch (DisplayException $exception) {
            $this->alert->danger($exception->getMessage())->flash();
        }

        return redirect()->route('admin.tickets.view', $ticket->id);
    }

    public function delete(Ticket $ticket): RedirectResponse
    {
        $number = $ticket->number();
        if (!$ticket->isClosed()) {
            $this->alert->danger('Close the ticket before deleting it.')->flash();

            return redirect()->route('admin.tickets.view', $ticket->id);
        }

        $this->service->delete($ticket);
        Activity::event('admin:ticket.delete')->property(['ticket' => $number])->log();
        $this->alert->info("Ticket $number and its files were deleted.")->flash();

        return redirect()->route('admin.tickets');
    }
}
