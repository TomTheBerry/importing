<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Model;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Models\AdminRole;
use Illuminate\Support\Collection;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Spatie\QueryBuilder\QueryBuilder;
use Pterodactyl\Models\UserConnection;
use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Users\AvatarService;
use Pterodactyl\Services\Users\TwoFactorPolicy;
use Illuminate\Contracts\Translation\Translator;
use Pterodactyl\Notifications\VerifyEmailAddress;
use Pterodactyl\Services\Users\UserUpdateService;
use Pterodactyl\Traits\Helpers\AvailableLanguages;
use Pterodactyl\Services\Auth\OAuth\OAuthProviders;
use Pterodactyl\Services\Users\RegistrationService;
use Pterodactyl\Services\Users\UserCreationService;
use Pterodactyl\Services\Users\UserDeletionService;
use Pterodactyl\Http\Requests\Admin\UserFormRequest;
use Pterodactyl\Http\Requests\Admin\NewUserFormRequest;
use Pterodactyl\Notifications\AccountConnectionChanged;
use Pterodactyl\Services\Roles\RevokeStaffAccessService;
use Pterodactyl\Contracts\Repository\UserRepositoryInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class UserController extends Controller
{
    use AvailableLanguages;

    /**
     * UserController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected UserCreationService $creationService,
        protected UserDeletionService $deletionService,
        protected Translator $translator,
        protected UserUpdateService $updateService,
        protected UserRepositoryInterface $repository,
        protected ViewFactory $view,
        protected RevokeStaffAccessService $revokeService,
    ) {
    }

    /**
     * Display user index page.
     */
    public function index(Request $request): View
    {
        $users = QueryBuilder::for(
            User::query()->with('adminRole')->select('users.*')
                ->selectRaw('COUNT(DISTINCT(subusers.id)) as subuser_of_count')
                ->selectRaw('COUNT(DISTINCT(servers.id)) as servers_count')
                ->leftJoin('subusers', 'subusers.user_id', '=', 'users.id')
                ->leftJoin('servers', 'servers.owner_id', '=', 'users.id')
                ->groupBy('users.id')
        )
            ->allowedFilters(['username', 'email', 'uuid'])
            ->defaultSort('-root_admin')
            ->allowedSorts(['id', 'uuid'])
            ->paginate(50);

        return view('admin.users.index', ['users' => $users]);
    }

    /**
     * Display new user page.
     */
    public function create(Request $request): View
    {
        return view('admin.users.new', [
            'languages' => $this->getAvailableLanguages(true),
            'roles' => $this->assignableRoles($request->user()),
        ]);
    }

    /**
     * Display user view page.
     */
    public function view(Request $request, User $user): View
    {
        $actor = $request->user();

        return view('admin.users.view', [
            'user' => $user,
            'languages' => $this->getAvailableLanguages(true),
            'roles' => $this->assignableRoles($actor),
            'canManage' => $actor->canManageUser($user),
            'canEditDetails' => $actor->canManageUser($user) && $actor->hasAdminPermission('users.update'),
            'canAssignRole' => $this->canAssignRole($actor, $user),
        ]);
    }

    /**
     * Delete a user from the system.
     *
     * @throws \Exception
     * @throws DisplayException
     */
    public function delete(Request $request, User $user): RedirectResponse
    {
        if ($request->user()->is($user)) {
            throw new DisplayException(__('admin/user.exceptions.delete_self'));
        }

        if (!$request->user()->canManageUser($user)) {
            throw new AccessDeniedHttpException('You cannot delete this user because they are a root administrator or have permissions your role does not have.');
        }

        $this->deletionService->handle($user);

        return redirect()->route('admin.users');
    }

    /**
     * Create a user.
     *
     * @throws \Exception
     * @throws \Throwable
     */
    public function store(NewUserFormRequest $request): RedirectResponse
    {
        $actor = $request->user();
        $data = $request->normalize();

        // Only root admins can create other root admins.
        if (!$actor->root_admin) {
            unset($data['root_admin']);
        }

        $roleId = $this->resolveRoleAssignment($actor, null, $data);
        unset($data['admin_role_id']);

        $user = $this->creationService->handle($data);
        if (!is_null($roleId)) {
            $user->forceFill(['admin_role_id' => $roleId])->saveOrFail();
        }

        $this->alert->success($this->translator->get('admin/user.notices.account_created'))->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Update a user on the system.
     *
     * @throws \Pterodactyl\Exceptions\Model\DataValidationException
     * @throws \Pterodactyl\Exceptions\Repository\RecordNotFoundException
     */
    public function update(UserFormRequest $request, User $user): RedirectResponse
    {
        $actor = $request->user();
        if (!$actor->canManageUser($user)) {
            throw new AccessDeniedHttpException('You cannot edit this user because they are a root administrator or have permissions your role does not have.');
        }

        $data = $request->normalize();
        $roleChanging = array_key_exists('admin_role_id', $data);
        $roleId = $this->resolveRoleAssignment($actor, $user, $data);
        unset($data['admin_role_id']);

        // Only root admins can grant or remove root admin status, and root admins
        // cannot remove it from themselves (preventing an accidental lockout).
        if (!$actor->root_admin || ($actor->is($user) && array_key_exists('root_admin', $data) && !$data['root_admin'])) {
            unset($data['root_admin']);
        }

        // Staff who can only assign roles cannot change any other account details.
        if (!$actor->hasAdminPermission('users.update')) {
            $data = [];
        }

        $wasStaff = $user->hasGlobalServerAccess() || $user->root_admin;
        if ($roleChanging && $roleId !== $user->admin_role_id) {
            $data['admin_role_id'] = $roleId;
        }

        $this->updateService
            ->setUserLevel(User::USER_LEVEL_ADMIN)
            ->handle($user, $data);

        // Make sure SFTP and websocket connections pick up the user's new permissions.
        if (array_key_exists('admin_role_id', $data) || ($wasStaff && array_key_exists('root_admin', $data) && !$user->root_admin)) {
            $this->revokeService->handle([$user]);
        }

        $this->alert->success(trans('admin/user.notices.account_updated'))->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Marks a user's email address as verified.
     */
    public function markVerified(Request $request, User $user): RedirectResponse
    {
        if (!$request->user()->canManageUser($user)) {
            throw new AccessDeniedHttpException('You cannot edit this user because they are a root administrator or have permissions your role does not have.');
        }

        $user->forceFill(['email_verified_at' => $user->email_verified_at ?? now()])->saveOrFail();
        $this->alert->success('The email address was marked as verified.')->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Emails the user a new verification link. Users who never finished registering
     * get a link to verify AND set their password.
     */
    public function sendVerification(Request $request, User $user, RegistrationService $registration): RedirectResponse
    {
        if (!$request->user()->canManageUser($user)) {
            throw new AccessDeniedHttpException('You cannot edit this user because they are a root administrator or have permissions your role does not have.');
        }

        if ($user->registration_pending) {
            $registration->sendVerification($user);
        } elseif (!$user->hasVerifiedEmail()) {
            $user->notify(new VerifyEmailAddress($user));
        }

        $this->alert->success('A verification email has been sent to ' . $user->email . '.')->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Turns off a user's authenticator app and email codes, e.g. when they have lost their
     * phone and their recovery codes. Staff are asked to set it up again straight away.
     */
    public function resetTwoFactor(Request $request, User $user): RedirectResponse
    {
        if (!$request->user()->canManageUser($user)) {
            throw new AccessDeniedHttpException('You cannot edit this user because they are a root administrator or have permissions your role does not have.');
        }

        $user->getConnection()->transaction(function () use ($user) {
            $user->recoveryTokens()->delete();
            $user->forceFill([
                'use_totp' => false,
                'totp_secret' => null,
                'totp_app_name' => null,
                'totp_authenticated_at' => now(),
                'email_2fa' => false,
            ])->save();
        });

        $this->alert->success('Two-step verification was reset for ' . $user->username . '.' . (TwoFactorPolicy::required($user) ? ' They will be asked to set it up again when they next log in.' : ''))->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Removes a connected Google / GitHub / Discord account from a user, e.g. if it was
     * added by someone who got into their account.
     */
    public function deleteConnection(Request $request, User $user, UserConnection $connection): RedirectResponse
    {
        if (!$request->user()->canManageUser($user)) {
            throw new AccessDeniedHttpException('You cannot edit this user because they are a root administrator or have permissions your role does not have.');
        }

        if ($connection->user_id !== $user->id) {
            throw new NotFoundHttpException();
        }

        $connection->delete();
        $label = OAuthProviders::label($connection->provider);

        Activity::event('user:connection.delete')
            ->subject($user)
            ->property(['provider' => $label, 'account' => $connection->username, 'by_staff' => true])
            ->log();

        $user->notify(new AccountConnectionChanged($label, $connection->username, false, true));
        $this->alert->success("The $label account was removed from {$user->username}.")->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Removes a user's profile picture, for example if it is inappropriate.
     */
    public function deleteAvatar(Request $request, User $user, AvatarService $avatars): RedirectResponse
    {
        if (!$request->user()->canManageUser($user)) {
            throw new AccessDeniedHttpException('You cannot edit this user because they are a root administrator or have permissions your role does not have.');
        }

        $avatars->delete($user);
        $this->alert->success('The profile picture was removed.')->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /**
     * Returns the roles the given user is allowed to assign to other users.
     *
     * @return \Illuminate\Support\Collection<int, \Pterodactyl\Models\AdminRole>
     */
    protected function assignableRoles(User $actor): Collection
    {
        if (!$actor->hasAdminPermission('users.roles')) {
            return collect();
        }

        return AdminRole::query()->orderBy('name')->get()
            ->filter(fn (AdminRole $role) => $actor->holdsAllAdminPermissions($role->getPermissionList()))
            ->values();
    }

    /**
     * Determines if the actor can change the role of the given user.
     */
    protected function canAssignRole(User $actor, User $user): bool
    {
        if ($actor->root_admin) {
            return true;
        }

        return $actor->hasAdminPermission('users.roles') && !$actor->is($user) && $actor->canManageUser($user);
    }

    /**
     * Works out which role (if any) should be assigned to the user based on the
     * request data, ensuring the actor is allowed to make that assignment.
     *
     * Returns the role ID that should be set, or the user's existing role when no
     * change was requested.
     */
    protected function resolveRoleAssignment(User $actor, ?User $user, array $data): ?int
    {
        if (!array_key_exists('admin_role_id', $data)) {
            return $user?->admin_role_id;
        }

        $roleId = empty($data['admin_role_id']) ? null : (int) $data['admin_role_id'];
        if ($roleId === $user?->admin_role_id) {
            return $roleId;
        }

        if ($user ? !$this->canAssignRole($actor, $user) : !$actor->hasAdminPermission('users.roles')) {
            throw new AccessDeniedHttpException('You are not allowed to change this user\'s role.');
        }

        if (!is_null($roleId)) {
            $role = AdminRole::query()->findOrFail($roleId);
            if (!$actor->holdsAllAdminPermissions($role->getPermissionList())) {
                throw new AccessDeniedHttpException('You cannot assign a role that has permissions your own role does not have.');
            }
        }

        return $roleId;
    }

    /**
     * Get a JSON response of users on the system.
     */
    public function json(Request $request): Model|Collection
    {
        $users = QueryBuilder::for(User::query())->allowedFilters(['email'])->paginate(25);

        // Handle single user requests.
        if ($request->query('user_id')) {
            $user = User::query()->findOrFail($request->input('user_id'));
            // @phpstan-ignore-next-line property.notFound
            $user->md5 = md5(strtolower($user->email));
            // @phpstan-ignore-next-line property.notFound
            $user->avatar_url = $user->avatarUrl();

            return $user;
        }

        return $users->map(function ($item) {
            // @phpstan-ignore-next-line property.notFound
            $item->md5 = md5(strtolower($item->email));
            // @phpstan-ignore-next-line property.notFound
            $item->avatar_url = $item->avatarUrl();

            return $item;
        });
    }
}
