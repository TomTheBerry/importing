<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Models\UserNote;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Private notes staff keep on a customer's account. Anyone with "notes.write" can add,
 * edit, pin or remove any note; who wrote and last edited each one is always shown.
 */
class UserNoteController extends Controller
{
    public function __construct(private AlertsMessageBag $alert)
    {
    }

    public function store(Request $request, User $user): RedirectResponse
    {
        $data = $request->validate([
            'body' => 'required|string|min:2|max:5000',
            'pinned' => 'sometimes|boolean',
        ]);

        UserNote::query()->create([
            'user_id' => $user->id,
            'author_id' => $request->user()->id,
            'body' => trim($data['body']),
            'pinned' => (bool) ($data['pinned'] ?? false),
        ]);

        $this->alert->success('Note added.')->flash();

        return $this->back($user);
    }

    public function update(Request $request, User $user, UserNote $note): RedirectResponse
    {
        $this->ensureBelongs($user, $note);

        $data = $request->validate([
            'body' => 'sometimes|required|string|min:2|max:5000',
            'pinned' => 'sometimes|boolean',
        ]);

        if (array_key_exists('body', $data) && trim($data['body']) !== $note->body) {
            $note->body = trim($data['body']);
            $note->updated_by = $request->user()->id;
        }
        if (array_key_exists('pinned', $data)) {
            // Pinning doesn't change what the note says, so it isn't shown as an edit.
            $note->pinned = (bool) $data['pinned'];
        }
        $note->save();

        $this->alert->success(array_key_exists('body', $data) ? 'Note updated.' : ($note->pinned ? 'Note pinned.' : 'Note unpinned.'))->flash();

        return $this->back($user);
    }

    public function delete(User $user, UserNote $note): RedirectResponse
    {
        $this->ensureBelongs($user, $note);
        $note->delete();

        $this->alert->info('Note deleted.')->flash();

        return $this->back($user);
    }

    private function ensureBelongs(User $user, UserNote $note): void
    {
        if ($note->user_id !== $user->id) {
            throw new NotFoundHttpException();
        }
    }

    private function back(User $user): RedirectResponse
    {
        return redirect()->to(route('admin.users.view', $user->id) . '#staff-notes');
    }
}
