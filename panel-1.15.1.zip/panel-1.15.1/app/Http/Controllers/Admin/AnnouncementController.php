<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Pterodactyl\Models\Announcement;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

/**
 * Admin -> Announcements: short banners across the top of the Panel.
 */
class AnnouncementController extends Controller
{
    public function __construct(private AlertsMessageBag $alert)
    {
    }

    public function index(): View
    {
        $announcements = Announcement::query()->with('creator')
            ->orderByDesc('is_active')
            ->orderByDesc('id')
            ->paginate(25);

        return view('admin.announcements.index', [
            'announcements' => $announcements,
            'live' => Announcement::query()->live()->count(),
        ]);
    }

    public function create(): View
    {
        return view('admin.announcements.form', ['announcement' => new Announcement([
            'style' => 'info',
            'audience' => 'everyone',
            'dismissible' => true,
            'is_active' => true,
        ])]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validated($request);
        $data['created_by'] = $request->user()->id;

        Announcement::query()->create($data);
        $this->alert->success('Announcement saved.')->flash();

        return redirect()->route('admin.announcements');
    }

    public function edit(Announcement $announcement): View
    {
        return view('admin.announcements.form', ['announcement' => $announcement]);
    }

    public function update(Request $request, Announcement $announcement): RedirectResponse
    {
        $announcement->update($this->validated($request));
        $this->alert->success('Announcement updated.')->flash();

        return redirect()->route('admin.announcements');
    }

    public function toggle(Announcement $announcement): RedirectResponse
    {
        $announcement->update(['is_active' => !$announcement->is_active]);
        $this->alert->success($announcement->is_active ? 'Announcement turned on.' : 'Announcement turned off.')->flash();

        return redirect()->route('admin.announcements');
    }

    public function delete(Announcement $announcement): RedirectResponse
    {
        $announcement->delete();
        $this->alert->info('Announcement deleted.')->flash();

        return redirect()->route('admin.announcements');
    }

    /**
     * @return array<string, mixed>
     */
    private function validated(Request $request): array
    {
        $data = $request->validate([
            'message' => 'required|string|min:3|max:500',
            'link_url' => 'nullable|url:https,http|max:255|required_with:link_text',
            'link_text' => 'nullable|string|max:64',
            'style' => 'required|string|in:' . implode(',', array_keys(Announcement::STYLES)),
            'audience' => 'required|string|in:' . implode(',', array_keys(Announcement::AUDIENCES)),
            'dismissible' => 'sometimes|boolean',
            'is_active' => 'sometimes|boolean',
            'starts_at' => 'nullable|date',
            'ends_at' => $request->filled('starts_at') ? 'nullable|date|after:starts_at' : 'nullable|date',
        ]);

        // The message is plain text: it is always escaped when shown.
        $data['message'] = trim(preg_replace('/\s+/u', ' ', $data['message']) ?? '');
        $data['dismissible'] = $request->boolean('dismissible');
        $data['is_active'] = $request->boolean('is_active');
        $data['link_url'] = !empty($data['link_url']) ? $data['link_url'] : null;
        $data['link_text'] = $data['link_url'] ? (trim((string) ($data['link_text'] ?? '')) ?: 'Learn more') : null;
        // Times are entered in the Panel's timezone.
        foreach (['starts_at', 'ends_at'] as $field) {
            $data[$field] = !empty($data[$field]) ? CarbonImmutable::parse($data[$field], config('app.timezone')) : null;
        }

        return $data;
    }
}
