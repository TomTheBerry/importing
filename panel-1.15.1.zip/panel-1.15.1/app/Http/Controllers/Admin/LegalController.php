<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Models\LegalVersion;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\LegalAcceptance;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Legal\LegalService;

/**
 * Admin -> Legal: which version of the Terms, Privacy Policy and Acceptable Use Policy
 * is current, who has accepted it, and publishing a new version.
 */
class LegalController extends Controller
{
    public function __construct(private AlertsMessageBag $alert, private LegalService $legal)
    {
    }

    public function index(): View
    {
        $current = $this->legal->current();
        $total = User::query()->where('registration_pending', false)->count();
        $accepted = $current ? User::query()->where('registration_pending', false)->where('legal_version', $current->version)->count() : 0;

        $versions = LegalVersion::query()->with('publisher')->orderByDesc('published_at')->orderByDesc('id')->get();
        $counts = LegalAcceptance::query()->selectRaw('version, count(*) as total')->groupBy('version')->pluck('total', 'version');

        return view('admin.legal.index', [
            'current' => $current,
            'versions' => $versions,
            'counts' => $counts,
            'total' => $total,
            'accepted' => $accepted,
            'recent' => LegalAcceptance::query()->with('user')->orderByDesc('id')->limit(15)->get(),
            'links' => LegalService::LINKS,
        ]);
    }

    public function publish(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'version' => ['required', 'string', 'max:32', 'regex:/^[0-9A-Za-z][0-9A-Za-z.\-]*$/'],
            'summary' => 'required|string|min:10|max:2000',
            'confirm' => 'accepted',
        ], [
            'version.regex' => 'Use a simple version number such as 1.1 or 2026-11.',
            'confirm.accepted' => 'Tick the box to confirm everyone should be asked to accept the new version.',
        ]);

        $version = $this->legal->publish($data['version'], trim($data['summary']), $request->user());
        $this->alert->success("Version {$version->version} published. Everyone will be asked to accept it the next time they use the Panel.")->flash();

        return redirect()->route('admin.legal');
    }
}
