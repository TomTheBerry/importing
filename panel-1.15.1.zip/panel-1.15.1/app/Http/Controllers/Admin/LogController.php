<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Support\Collection;
use Pterodactyl\Models\ActivityLog;
use Illuminate\Support\Facades\Cache;
use Pterodactyl\Observers\AuditObserver;
use Illuminate\Database\Eloquent\Builder;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Activity\LogPresenter;
use Illuminate\Database\Eloquent\Relations\Relation;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Admin -> Logs. Everything recorded on the Panel, with filters and sorting.
 */
class LogController extends Controller
{
    /** @var array<int, \Pterodactyl\Models\Server> servers seen while loading the current page */
    protected array $servers = [];

    public const PER_PAGE = [25, 50, 100, 250];
    public const SORTS = ['newest' => 'Newest first', 'oldest' => 'Oldest first', 'event' => 'Event (A–Z)', 'actor' => 'Who did it'];
    public const ACCESS_TYPES = [
        'override' => 'Staff on servers that aren\'t theirs',
        'subuser' => 'Subusers',
        'owner' => 'Server owners',
    ];
    public const ACTOR_TYPES = ['staff' => 'Staff', 'customer' => 'Customers', 'system' => 'System (no user)', 'api' => 'Using an API key'];

    public function index(Request $request): View
    {
        $filters = $this->filters($request);
        $canSeeIps = $request->user()->hasAdminPermission('logs.ips');

        $logs = $this->query($filters, $canSeeIps)
            ->with('actor')
            ->paginate($filters['per_page'])
            ->withQueryString();

        // Ranks are shown next to each person, so load them all at once.
        (new \Illuminate\Database\Eloquent\Collection($logs->getCollection()->pluck('actor')->filter(fn ($a) => $a instanceof User)->unique('id')->values()->all()))
            ->loadMissing('adminRole');

        return view('admin.logs.index', [
            'logs' => $logs,
            'filters' => $filters,
            'canSeeIps' => $canSeeIps,
            'canExport' => $request->user()->hasAdminPermission('logs.export'),
            'subjects' => $this->loadSubjects($logs->getCollection()),
            'access' => $this->accessInfo($logs->getCollection()),
            'events' => $this->eventList(),
            'actor' => $filters['actor'] ? User::query()->find($filters['actor']) : null,
            'subjectTypes' => $this->subjectTypes(),
        ]);
    }

    /**
     * Downloads the filtered logs as CSV (up to 50,000 rows).
     */
    public function export(Request $request): StreamedResponse
    {
        $filters = $this->filters($request);
        $canSeeIps = $request->user()->hasAdminPermission('logs.ips');
        $query = $this->query($filters, $canSeeIps)->with('actor')->limit(50000);

        return response()->streamDownload(function () use ($query, $canSeeIps) {
            $out = fopen('php://output', 'w');
            fputcsv($out, array_filter(['Time', 'Event', 'Description', 'Actor', 'Actor ID', 'Server access', 'Records', $canSeeIps ? 'IP' : null, 'Details']));
            foreach ($query->lazy(500) as $log) {
                $subjects = $this->loadSubjects(collect([$log]))[$log->id] ?? [];
                $access = $this->accessInfo(collect([$log]))[$log->id] ?? null;
                fputcsv($out, array_map([$this, 'csvSafe'], array_values(array_filter([
                    'time' => $log->timestamp->toAtomString(),
                    'event' => $log->event,
                    'description' => LogPresenter::describe($log),
                    'actor' => LogPresenter::actorName($log->actor),
                    'actor_id' => (string) ($log->actor_id ?? ''),
                    'access' => $access ? LogPresenter::accessLabel($access['access']) . ' (server ' . $access['server'] . ', owner ' . $access['owner'] . ')' : '',
                    'records' => collect($subjects)->map(fn ($s) => $s['type'] . ': ' . $s['label'])->implode('; '),
                    'ip' => $canSeeIps ? $log->ip : false,
                    'details' => json_encode($this->properties($log, $canSeeIps), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                ], fn ($v) => $v !== false))));
            }
            fclose($out);
        }, 'panel-logs-' . now()->format('Y-m-d-His') . '.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    /**
     * Stops spreadsheet apps from running a cell as a formula.
     */
    public function csvSafe(?string $value): string
    {
        $value = (string) $value;

        return $value !== '' && in_array($value[0], ['=', '+', '-', '@', "\t", "\r"], true) ? "'" . $value : $value;
    }

    /**
     * The details shown for an entry. IP addresses and browser details are removed for
     * staff without the logs.ips permission.
     */
    public static function properties(ActivityLog $log, bool $canSeeIps): array
    {
        $properties = $log->properties?->toArray() ?? [];
        if (!$canSeeIps) {
            unset($properties['ip'], $properties['useragent']);
        }

        // Server access details are shown in their own section.
        foreach (array_keys($properties) as $key) {
            if (str_starts_with((string) $key, '_')) {
                unset($properties[$key]);
            }
        }

        return $properties;
    }

    protected function filters(Request $request): array
    {
        $data = $request->validate([
            'q' => 'nullable|string|max:191',
            'category' => 'nullable|string|in:' . implode(',', array_keys(LogPresenter::CATEGORIES)),
            'event' => 'nullable|string|max:191',
            'actor' => 'nullable|integer',
            'actor_type' => 'nullable|string|in:' . implode(',', array_keys(self::ACTOR_TYPES)),
            'access' => 'nullable|string|in:' . implode(',', array_keys(self::ACCESS_TYPES)),
            'subject_type' => 'nullable|string|max:64',
            'subject_id' => 'nullable|integer',
            'ip' => 'nullable|string|max:64',
            'from' => 'nullable|date',
            'to' => 'nullable|date',
            'batch' => 'nullable|uuid',
            'sort' => 'nullable|string|in:' . implode(',', array_keys(self::SORTS)),
            'per_page' => 'nullable|integer|in:' . implode(',', self::PER_PAGE),
        ]);

        return [
            'q' => trim((string) ($data['q'] ?? '')),
            'category' => $data['category'] ?? null,
            'event' => $data['event'] ?? null,
            'actor' => isset($data['actor']) ? (int) $data['actor'] : null,
            'actor_type' => $data['actor_type'] ?? null,
            'access' => $data['access'] ?? null,
            'subject_type' => $data['subject_type'] ?? null,
            'subject_id' => isset($data['subject_id']) ? (int) $data['subject_id'] : null,
            'ip' => trim((string) ($data['ip'] ?? '')),
            'from' => $data['from'] ?? null,
            'to' => $data['to'] ?? null,
            'batch' => $data['batch'] ?? null,
            'sort' => $data['sort'] ?? 'newest',
            'per_page' => (int) ($data['per_page'] ?? 50),
        ];
    }

    /**
     * @return Builder<ActivityLog>
     */
    protected function query(array $f, bool $canSeeIps): Builder
    {
        $userType = (new User())->getMorphClass();
        $like = fn (string $value) => '%' . addcslashes($value, '%_\\') . '%';

        $query = ActivityLog::query()->select('activity_logs.*')->whereNotIn('activity_logs.event', ActivityLog::DISABLED_EVENTS);

        if ($f['category']) {
            $query->where(function (Builder $q) use ($f) {
                foreach (LogPresenter::CATEGORIES[$f['category']][2] as $prefix) {
                    $q->orWhere('activity_logs.event', 'like', addcslashes($prefix, '%_\\') . '%');
                }
            });
        }

        if ($f['event']) {
            $query->where('activity_logs.event', $f['event']);
        }

        if ($f['actor']) {
            $query->where('activity_logs.actor_type', $userType)->where('activity_logs.actor_id', $f['actor']);
        }

        $staff = fn ($q) => $q->select('id')->from('users')->where(fn ($q) => $q->where('root_admin', true)->orWhereNotNull('admin_role_id'));
        match ($f['actor_type']) {
            'staff' => $query->where('activity_logs.actor_type', $userType)->whereIn('activity_logs.actor_id', $staff),
            'customer' => $query->where('activity_logs.actor_type', $userType)->whereNotIn('activity_logs.actor_id', $staff),
            'system' => $query->whereNull('activity_logs.actor_id'),
            'api' => $query->whereNotNull('activity_logs.api_key_id'),
            default => null,
        };

        match ($f['access']) {
            'override' => $query->whereIn('activity_logs.properties->_access', ['staff', 'admin']),
            'subuser' => $query->where('activity_logs.properties->_access', 'subuser'),
            'owner' => $query->where('activity_logs.properties->_access', 'owner'),
            default => null,
        };

        if ($f['subject_type'] && ($class = $this->subjectTypes()[$f['subject_type']]['class'] ?? null)) {
            $morph = (new $class())->getMorphClass();
            $query->whereExists(function ($q) use ($morph, $f) {
                $q->selectRaw('1')->from('activity_log_subjects')
                    ->whereColumn('activity_log_subjects.activity_log_id', 'activity_logs.id')
                    ->where('activity_log_subjects.subject_type', $morph)
                    ->when($f['subject_id'], fn ($q) => $q->where('activity_log_subjects.subject_id', $f['subject_id']));
            });
        }

        if ($f['ip'] !== '' && $canSeeIps) {
            $query->where('activity_logs.ip', 'like', addcslashes($f['ip'], '%_\\') . '%');
        }

        if ($f['from']) {
            $query->where('activity_logs.timestamp', '>=', CarbonImmutable::parse($f['from'])->startOfDay());
        }
        if ($f['to']) {
            $query->where('activity_logs.timestamp', '<=', CarbonImmutable::parse($f['to'])->endOfDay());
        }

        if ($f['batch']) {
            $query->where('activity_logs.batch', $f['batch']);
        }

        if ($f['q'] !== '') {
            $search = $like($f['q']);
            $users = User::query()->select('id')->where('username', 'like', $search)->orWhere('email', 'like', $search)
                ->orWhere('name_first', 'like', $search)->orWhere('name_last', 'like', $search);

            $query->where(function (Builder $q) use ($search, $users, $userType, $canSeeIps) {
                $q->where('activity_logs.event', 'like', $search)
                    ->orWhere('activity_logs.description', 'like', $search)
                    ->orWhereRaw('CAST(activity_logs.properties AS CHAR) LIKE ?', [$search])
                    ->orWhere(fn ($q) => $q->where('activity_logs.actor_type', $userType)->whereIn('activity_logs.actor_id', $users));
                if ($canSeeIps) {
                    $q->orWhere('activity_logs.ip', 'like', $search);
                }
            });
        }

        match ($f['sort']) {
            'oldest' => $query->orderBy('activity_logs.timestamp')->orderBy('activity_logs.id'),
            'event' => $query->orderBy('activity_logs.event')->orderByDesc('activity_logs.id'),
            'actor' => $query->orderBy('activity_logs.actor_id')->orderByDesc('activity_logs.id'),
            default => $query->orderByDesc('activity_logs.timestamp')->orderByDesc('activity_logs.id'),
        };

        return $query;
    }

    /**
     * Loads every record attached to the shown entries in a few queries.
     *
     * @return array<int, array<int, array{label: string, type: string, url: string|null}>>
     */
    protected function loadSubjects(Collection $logs): array
    {
        $byType = [];
        foreach ($logs as $log) {
            foreach ($log->subjects as $subject) {
                $byType[$subject->subject_type][$subject->subject_id] = true;
            }
        }

        $models = [];
        foreach ($byType as $type => $ids) {
            $class = Relation::getMorphedModel($type) ?? $type;
            if (class_exists($class)) {
                $models[$type] = $class::query()
                    ->when($class === \Pterodactyl\Models\Server::class, fn ($q) => $q->with(['user', 'subusers']))
                    ->whereIn((new $class())->getKeyName(), array_keys($ids))->get()->keyBy(fn ($m) => $m->getKey());
            }
        }

        $this->servers = ($models[(new \Pterodactyl\Models\Server())->getMorphClass()] ?? collect())->all() + $this->servers;

        $out = [];
        foreach ($logs as $log) {
            foreach ($log->subjects as $subject) {
                $out[$log->id][] = LogPresenter::subject($subject->subject_type, (int) $subject->subject_id, $models[$subject->subject_type][$subject->subject_id] ?? null);
            }
        }

        return $out;
    }

    /**
     * How the person got into the server for each entry about a server: as its owner,
     * as a subuser, or only because they are staff. Uses what was recorded at the time,
     * or works it out from the server as it is now for older entries.
     *
     * @return array<int, array{access: string, server: ?string, owner: ?string, owner_id: ?int, estimated: bool}>
     */
    protected function accessInfo(Collection $logs): array
    {
        $serverType = (new \Pterodactyl\Models\Server())->getMorphClass();
        $out = [];
        foreach ($logs as $log) {
            $p = $log->properties;
            if ($p && $p->has('_access')) {
                $out[$log->id] = [
                    'access' => (string) $p->get('_access'),
                    'server' => $p->get('_server'),
                    'owner' => $p->get('_owner'),
                    'owner_id' => $p->get('_owner_id'),
                    'estimated' => false,
                ];
                continue;
            }

            if (!$log->actor instanceof User) {
                continue;
            }
            $subject = $log->subjects->first(fn ($s) => $s->subject_type === $serverType);
            $server = $subject ? ($this->servers[$subject->subject_id] ?? null) : null;
            if ($server instanceof \Pterodactyl\Models\Server) {
                $out[$log->id] = [
                    'access' => \Pterodactyl\Services\Activity\ServerAccess::of($log->actor, $server),
                    'server' => $server->name,
                    'owner' => $server->user->username,
                    'owner_id' => $server->owner_id,
                    'estimated' => true,
                ];
            }
        }

        return $out;
    }

    /**
     * Every event that has been recorded, with how often, for the event filter.
     *
     * @return array<string, array<string, int>> grouped by category label
     */
    protected function eventList(): array
    {
        $rows = Cache::remember('admin:logs:events', 300, fn () => ActivityLog::query()
            ->selectRaw('event, COUNT(*) as total')->groupBy('event')->orderBy('event')->pluck('total', 'event')->all());

        $grouped = [];
        foreach ($rows as $event => $total) {
            $category = LogPresenter::CATEGORIES[LogPresenter::category($event)][0] ?? 'Other';
            $grouped[$category][$event] = (int) $total;
        }
        ksort($grouped);

        return $grouped;
    }

    /**
     * Record types that entries can be filtered by.
     *
     * @return array<string, array{class: class-string, label: string}>
     */
    protected function subjectTypes(): array
    {
        $types = [];
        foreach (AuditObserver::MODELS as $class => $short) {
            $types[$short] = ['class' => $class, 'label' => ucfirst(LogPresenter::MODEL_LABELS[$short])];
        }

        return $types;
    }
}
