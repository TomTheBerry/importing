<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Sessions\ImpersonationService;

/**
 * Lets a root administrator open the Panel as a customer sees it, to help them.
 */
class ImpersonationController extends Controller
{
    public function __construct(private ImpersonationService $impersonation)
    {
    }

    public function start(Request $request, User $user): RedirectResponse
    {
        $request->validate(['reason' => 'required|string|min:5|max:255']);

        $this->impersonation->start($request, $request->user(), $user, (string) $request->input('reason'));

        return redirect()->route('index');
    }
}
