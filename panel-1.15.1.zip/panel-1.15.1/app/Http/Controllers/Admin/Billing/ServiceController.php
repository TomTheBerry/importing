<?php

namespace Pterodactyl\Http\Controllers\Admin\Billing;

use Ramsey\Uuid\Uuid;
use Illuminate\View\View;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Pterodactyl\Models\Server;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\Billing\Product;
use Pterodactyl\Services\Billing\Money;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Billing\Subscription;
use Pterodactyl\Jobs\Billing\ProvisionServer;
use Illuminate\Validation\ValidationException;
use Pterodactyl\Services\Billing\FulfilmentService;
use Pterodactyl\Services\Billing\OwnerCleanupService;
use Pterodactyl\Services\Billing\SubscriptionService;
use Pterodactyl\Http\Controllers\Admin\Billing\Concerns\GuardsBillingTargets;

class ServiceController extends Controller
{
    use GuardsBillingTargets;

    public function __construct(private AlertsMessageBag $alert, private SubscriptionService $subscriptions, private FulfilmentService $fulfilment)
    {
    }

    public function index(Request $request): View
    {
        $status = $request->query('status');
        $search = trim((string) $request->query('search', ''));

        $services = Subscription::query()->with(['user', 'product', 'server'])
            ->when(in_array($status, ['pending', 'provisioning', 'active', 'suspended', 'failed', 'cancelled', 'terminated'], true), fn ($q) => $q->where('status', $status))
            ->when(!$status, fn ($q) => $q->whereIn('status', Subscription::LIVE_STATUSES))
            ->when($search !== '', function ($q) use ($search) {
                $like = '%' . addcslashes($search, '%_\\') . '%';
                $q->where(fn ($q) => $q->where('name', 'like', $like)->orWhere('uuid', $search)
                    ->orWhereHas('user', fn ($q) => $q->where('email', 'like', $like)->orWhere('username', 'like', $like)));
            })
            ->orderByRaw('next_due_at IS NULL, next_due_at ASC')
            ->paginate(50)->withQueryString();

        return view('admin.billing.services.index', ['services' => $services, 'status' => $status, 'search' => $search]);
    }

    public function view(int $id): View
    {
        /** @var Subscription $service */
        $service = Subscription::query()->with(['user', 'product', 'scheduledProduct', 'server', 'coupon'])->findOrFail($id);

        return view('admin.billing.services.view', [
            'service' => $service,
            'invoices' => $service->invoices()->orderByDesc('id')->get(),
            'products' => Product::query()->orderBy('category')->orderBy('price')->get(),
        ]);
    }

    /**
     * Puts an existing server (for example one made by hand) on a paid plan.
     */
    public function attach(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'server_id' => 'required|integer',
            'product_id' => 'required|integer',
            'price' => 'required|string|max:16',
            'next_due_at' => 'required|date|after:now|before:+2 years',
        ]);

        /** @var Server $server */
        $server = Server::query()->findOrFail($data['server_id']);

        // Billing a server can end with it being deleted, so this needs the same rights.
        $this->requirePermission($request, 'servers.delete');
        $this->guardTarget($request, $server->user);
        $product = Product::query()->findOrFail($data['product_id']);
        $price = Money::parse($data['price']) ?? throw ValidationException::withMessages(['price' => 'Enter the monthly price, like 4.99.']);

        if (Subscription::query()->where('server_id', $server->id)->whereIn('status', Subscription::LIVE_STATUSES)->exists()) {
            $this->alert->danger('That server is already on a paid plan.')->flash();

            return redirect()->back();
        }

        $service = new Subscription();
        $service->forceFill([
            'uuid' => Uuid::uuid4()->toString(),
            'user_id' => $server->owner_id,
            'product_id' => $product->id,
            'server_id' => $server->id,
            'location_id' => $server->node->location_id,
            'name' => $server->name,
            'status' => $server->isSuspended() ? Subscription::STATUS_SUSPENDED : Subscription::STATUS_ACTIVE,
            'price' => $price,
            'next_due_at' => CarbonImmutable::parse($data['next_due_at']),
        ])->saveOrFail();

        $this->alert->success('The server is now billed. The first renewal invoice will be sent before the due date.')->flash();

        return redirect()->route('admin.billing.services.view', $service->id);
    }

    public function update(Request $request, int $id): RedirectResponse
    {
        $service = $this->find($id);
        $this->guardTarget($request, $service->user);
        $data = $request->validate([
            'name' => ['required', 'string', 'between:1,191', 'not_regex:/[<>]/'],
            'price' => 'required|string|max:16',
            'next_due_at' => 'nullable|date|before:+2 years',
        ]);

        $price = Money::parse($data['price']) ?? throw ValidationException::withMessages(['price' => 'Enter the monthly price, like 4.99.']);

        $service->forceFill([
            'name' => $data['name'],
            'price' => $price,
            'next_due_at' => empty($data['next_due_at']) ? $service->next_due_at : CarbonImmutable::parse($data['next_due_at']),
        ])->saveOrFail();

        $this->alert->success('Service updated. Changes apply from the next invoice.')->flash();

        return redirect()->route('admin.billing.services.view', $service->id);
    }

    public function action(Request $request, int $id, string $action): RedirectResponse
    {
        $service = $this->find($id);
        $this->guardTarget($request, $service->user);

        // Actions that change the server itself also need the matching server permission.
        $needs = ['suspend' => 'servers.suspend', 'unsuspend' => 'servers.suspend', 'terminate' => 'servers.delete', 'apply-plan' => 'servers.build'];
        if (isset($needs[$action])) {
            $this->requirePermission($request, $needs[$action]);
        }

        switch ($action) {
            case 'suspend':
                $this->subscriptions->suspend($service);
                $message = 'Service suspended.';
                break;
            case 'unsuspend':
                $this->subscriptions->unsuspend($service);
                $message = $service->openInvoice()
                    ? 'Service unsuspended. It still has an unpaid invoice, so it will be suspended again at the next billing run unless you move the due date.'
                    : 'Service unsuspended.';
                break;
            case 'cancel':
                $this->subscriptions->cancel($service);
                $message = 'Service will be cancelled at the end of the paid period.';
                break;
            case 'resume':
                $this->subscriptions->resume($service);
                $message = 'Cancellation removed.';
                break;
            case 'retry':
                $stuck = $service->status === Subscription::STATUS_PROVISIONING && $service->updated_at->lt(now()->subMinutes(10));
                if (($service->status !== Subscription::STATUS_FAILED && !$stuck) || $service->server_id) {
                    $this->alert->danger('Only services whose server was not created can be retried.')->flash();

                    return redirect()->back();
                }
                ProvisionServer::dispatch($service->id);
                $message = 'Server setup has been queued again.';
                break;
            case 'terminate':
                $this->subscriptions->terminate($service);
                $message = 'Service ended and its server was deleted.';
                break;
            case 'apply-plan':
                if ($service->product) {
                    $this->fulfilment->applyLimits($service, $service->product);
                }
                $message = 'The plan\'s limits were applied to the server.';
                break;
            default:
                abort(404);
        }

        $this->alert->success($message)->flash();

        return redirect()->route('admin.billing.services.view', $service->id);
    }

    protected function find(int $id): Subscription
    {
        /** @var Subscription $service */
        $service = Subscription::query()->with(['user', 'product', 'server'])->findOrFail($id);

        return $service;
    }

    /**
     * Permanently deletes a service (panel owner only, for clearing out tests).
     */
    public function delete(Request $request, int $id, OwnerCleanupService $cleanup): RedirectResponse
    {
        /** @var Subscription $service */
        $service = Subscription::query()->findOrFail($id);
        $name = $service->name;
        $cleanup->deleteService($service, $request->user(), $request->boolean('delete_server'), $request->boolean('delete_invoices'));

        $this->alert->success("Service \"$name\" was permanently deleted.")->flash();

        return redirect()->route('admin.billing.services');
    }
}
