<?php

namespace Pterodactyl\Http\Controllers\Admin\Billing;

use Ramsey\Uuid\Uuid;
use Illuminate\View\View;
use Pterodactyl\Models\Egg;
use Illuminate\Http\Request;
use Pterodactyl\Models\Nest;
use Pterodactyl\Models\Location;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\Billing\Product;
use Pterodactyl\Services\Billing\Money;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Billing\Subscription;
use Illuminate\Validation\ValidationException;
use Pterodactyl\Services\Support\DiscordRoleService;

class ProductController extends Controller
{
    use Concerns\ParsesEggEnvironment;

    public function __construct(private AlertsMessageBag $alert)
    {
    }

    public function index(): View
    {
        // RAM sizes of slider tiers are managed from their tier.
        $products = Product::query()->with('egg')->whereNull('tier_id')
            ->withCount(['subscriptions as live_count' => fn ($q) => $q->whereIn('status', Subscription::LIVE_STATUSES)])
            ->orderBy('category')->orderBy('sort')->orderBy('price')->get();

        return view('admin.billing.products.index', ['products' => $products->groupBy('category')]);
    }

    public function create(): View
    {
        return view('admin.billing.products.edit', $this->formData(null));
    }

    public function view(int $id): View|RedirectResponse
    {
        $product = Product::query()->findOrFail($id);
        if ($product->tier_id) {
            return redirect()->route('admin.billing.tiers.view', $product->tier_id);
        }

        return view('admin.billing.products.edit', $this->formData($product));
    }

    public function store(Request $request): RedirectResponse
    {
        $product = new Product();
        $product->forceFill(array_merge($this->validated($request), ['uuid' => Uuid::uuid4()->toString()]))->saveOrFail();

        $this->alert->success("Plan \"$product->name\" was created.")->flash();

        return redirect()->route('admin.billing.products.view', $product->id);
    }

    public function update(Request $request, int $id): RedirectResponse
    {
        /** @var Product $product */
        $product = Product::query()->whereNull('tier_id')->findOrFail($id);
        $role = $product->discord_role_id;
        $product->forceFill($this->validated($request))->saveOrFail();
        if ($role !== $product->discord_role_id) {
            DiscordRoleService::queueAll();
        }

        $this->alert->success('Plan updated. Existing services keep their current price until you change it on the service.')->flash();

        return redirect()->route('admin.billing.products.view', $product->id);
    }

    public function delete(int $id): RedirectResponse
    {
        /** @var Product $product */
        $product = Product::query()->whereNull('tier_id')->findOrFail($id);
        $inUse = $product->subscriptions()->whereIn('status', array_merge(Subscription::LIVE_STATUSES, [Subscription::STATUS_PENDING]))->exists()
            // ...or a service is due to move to it at its next renewal.
            || Subscription::query()->where('scheduled_product_id', $product->id)->whereIn('status', Subscription::LIVE_STATUSES)->exists()
            || \Pterodactyl\Models\Billing\Invoice::query()->where('upgrade_product_id', $product->id)->where('status', \Pterodactyl\Models\Billing\Invoice::STATUS_UNPAID)->exists();
        if ($inUse) {
            $this->alert->danger('This plan still has services using it. Hide it from the store instead (untick "Available in store").' . (\Pterodactyl\Services\Billing\OwnerCleanupService::allowed(request()->user())
                ? ' To remove test services, delete them from Billing → Services first (owner only), then delete this.'
                : ''))->flash();

            return redirect()->route('admin.billing.products.view', $product->id);
        }

        $product->delete();
        $this->alert->success('Plan deleted.')->flash();

        return redirect()->route('admin.billing.products');
    }

    protected function formData(?Product $product): array
    {
        return [
            'product' => $product,
            'nests' => Nest::query()->with('eggs')->orderBy('name')->get(),
            'locations' => Location::query()->orderBy('short')->get(),
            'categories' => Product::query()->distinct()->orderBy('category')->pluck('category'),
            'environment' => collect($product->environment ?? [])->map(fn ($v, $k) => "$k=$v")->implode("\n"),
        ];
    }

    /**
     * @throws ValidationException
     */
    protected function validated(Request $request): array
    {
        $data = $request->validate([
            'name' => 'required|string|between:1,191',
            'category' => 'required|string|between:1,191',
            'description' => 'nullable|string|max:5000',
            'egg_id' => 'required|integer|exists:eggs,id',
            'memory' => 'required|integer|min:128|max:1048576',
            'swap' => 'required|integer|min:-1|max:1048576',
            'disk' => 'required|integer|min:256|max:104857600',
            'io' => 'required|integer|between:10,1000',
            'cpu' => 'required|integer|min:0|max:100000',
            'threads' => ['nullable', 'string', 'max:191', 'regex:/^[0-9-,]+$/'],
            'database_limit' => 'required|integer|min:0|max:1000',
            'allocation_limit' => 'required|integer|min:0|max:1000',
            'backup_limit' => 'required|integer|min:0|max:1000',
            'location_ids' => 'required|array|min:1',
            'location_ids.*' => 'integer|exists:locations,id',
            'environment' => 'nullable|string|max:10000',
            'docker_image' => 'nullable|string|max:191',
            'startup' => 'nullable|string|max:5000',
            'price' => 'required|string|max:16',
            'setup_fee' => 'nullable|string|max:16',
            'discord_role_id' => ['nullable', 'regex:/^\d{17,20}$/'],
            'stock' => 'nullable|integer|min:0|max:100000',
            'sort' => 'nullable|integer|min:0|max:100000',
        ], ['discord_role_id.regex' => 'The Discord role ID is a long number: in Discord, right-click the role and choose Copy Role ID.']);

        $price = Money::parse($data['price']);
        $setup = Money::parse($data['setup_fee'] ?? '0');
        if (is_null($price)) {
            throw ValidationException::withMessages(['price' => 'Enter the monthly price as a number, like 4.99.']);
        }
        if (is_null($setup)) {
            throw ValidationException::withMessages(['setup_fee' => 'Enter the setup fee as a number, like 2.00, or leave it empty.']);
        }

        /** @var Egg $egg */
        $egg = Egg::query()->findOrFail($data['egg_id']);
        $environment = $this->parseEnvironment($egg, $data['environment'] ?? '');

        if (!empty($data['docker_image']) && !in_array($data['docker_image'], array_values($egg->docker_images), true)) {
            throw ValidationException::withMessages(['docker_image' => 'Pick one of the Docker images offered by this egg, or leave it empty to use the default.']);
        }

        return [
            'name' => $data['name'],
            'category' => trim($data['category']),
            'description' => $data['description'] ?? null,
            'egg_id' => $egg->id,
            'memory' => (int) $data['memory'],
            'swap' => (int) $data['swap'],
            'disk' => (int) $data['disk'],
            'io' => (int) $data['io'],
            'cpu' => (int) $data['cpu'],
            'threads' => $data['threads'] ?? null,
            'database_limit' => (int) $data['database_limit'],
            'allocation_limit' => (int) $data['allocation_limit'],
            'backup_limit' => (int) $data['backup_limit'],
            'location_ids' => array_values(array_unique(array_map('intval', $data['location_ids']))),
            'environment' => $environment ?: null,
            'docker_image' => $data['docker_image'] ?? null,
            'startup' => $data['startup'] ?? null,
            'price' => $price,
            'setup_fee' => $setup,
            'stock' => isset($data['stock']) ? (int) $data['stock'] : null,
            'discord_role_id' => $data['discord_role_id'] ?? null,
            'is_active' => $request->boolean('is_active'),
            'sort' => (int) ($data['sort'] ?? 0),
        ];
    }
}
