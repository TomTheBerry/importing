<?php

namespace Pterodactyl\Http\Controllers\Admin\Billing;

use Ramsey\Uuid\Uuid;
use Illuminate\View\View;
use Pterodactyl\Models\Egg;
use Illuminate\Http\Request;
use Pterodactyl\Models\Nest;
use Pterodactyl\Models\Location;
use Pterodactyl\Models\Billing\Tier;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\Billing\Product;
use Pterodactyl\Services\Billing\Money;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Billing\Subscription;
use Pterodactyl\Services\Billing\TierService;
use Illuminate\Validation\ValidationException;
use Pterodactyl\Services\Support\DiscordRoleService;

/**
 * Admin -> Billing -> Plan tiers: plans with a RAM slider, where CPU, disk and price
 * grow with the RAM the customer picks.
 */
class TierController extends Controller
{
    use Concerns\ParsesEggEnvironment;

    public function __construct(private AlertsMessageBag $alert, private TierService $tiers)
    {
    }

    public function index(): View
    {
        $tiers = Tier::query()->with('egg')->withCount(['variants as sizes_count' => fn ($q) => $q->where('is_active', true)])
            ->orderBy('category')->orderBy('sort')->orderBy('id')->get();

        $live = Subscription::query()->join('billing_products', 'billing_products.id', '=', 'billing_subscriptions.product_id')
            ->whereNotNull('billing_products.tier_id')
            ->whereIn('billing_subscriptions.status', Subscription::LIVE_STATUSES)
            ->selectRaw('billing_products.tier_id as tier_id, count(*) as total')
            ->groupBy('billing_products.tier_id')
            ->pluck('total', 'tier_id');

        return view('admin.billing.tiers.index', ['tiers' => $tiers->groupBy('category'), 'live' => $live]);
    }

    public function create(): View
    {
        return view('admin.billing.tiers.edit', $this->formData(null));
    }

    public function view(int $id): View
    {
        return view('admin.billing.tiers.edit', $this->formData(Tier::query()->with('variants')->findOrFail($id)));
    }

    public function store(Request $request): RedirectResponse
    {
        $tier = new Tier();
        $tier->forceFill(array_merge($this->validated($request), ['uuid' => Uuid::uuid4()->toString()]))->saveOrFail();
        if ($tier->discord_role_id) {
            DiscordRoleService::queueAll();
        }
        $result = $this->tiers->sync($tier);

        $this->alert->success("Tier \"$tier->name\" was created with {$result['created']} RAM sizes.")->flash();

        return redirect()->route('admin.billing.tiers.view', $tier->id);
    }

    public function update(Request $request, int $id): RedirectResponse
    {
        /** @var Tier $tier */
        $tier = Tier::query()->findOrFail($id);
        $role = $tier->discord_role_id;
        $tier->forceFill($this->validated($request))->saveOrFail();
        if ($role !== $tier->discord_role_id) {
            DiscordRoleService::queueAll();
        }
        $result = $this->tiers->sync($tier);

        $message = 'Tier updated.';
        if ($result['created'] || $result['hidden']) {
            $message .= " {$result['created']} sizes added, {$result['hidden']} hidden.";
        }
        $this->alert->success($message . ' Existing services keep their current price until they change size.')->flash();

        return redirect()->route('admin.billing.tiers.view', $tier->id);
    }

    public function delete(int $id): RedirectResponse
    {
        /** @var Tier $tier */
        $tier = Tier::query()->findOrFail($id);
        $variantIds = Product::query()->where('tier_id', $tier->id)->pluck('id');

        $inUse = Subscription::query()->whereIn('product_id', $variantIds)
            ->whereIn('status', array_merge(Subscription::LIVE_STATUSES, [Subscription::STATUS_PENDING]))->exists()
            || Subscription::query()->whereIn('scheduled_product_id', $variantIds)->whereIn('status', Subscription::LIVE_STATUSES)->exists()
            || \Pterodactyl\Models\Billing\Invoice::query()->whereIn('upgrade_product_id', $variantIds)
                ->where('status', \Pterodactyl\Models\Billing\Invoice::STATUS_UNPAID)->exists();
        if ($inUse) {
            $this->alert->danger('Services are still using this tier. Hide it from the store instead (untick "Available in store").' . (\Pterodactyl\Services\Billing\OwnerCleanupService::allowed(request()->user())
                ? ' To remove test services, delete them from Billing → Services first (owner only), then delete this.'
                : ''))->flash();

            return redirect()->route('admin.billing.tiers.view', $tier->id);
        }

        // Sizes that were used in the past are kept (hidden) for old invoices.
        foreach (Product::query()->where('tier_id', $tier->id)->get() as $product) {
            $product->subscriptions()->exists() ? $product->forceFill(['is_active' => false])->saveOrFail() : $product->delete();
        }
        $tier->delete();

        $this->alert->success('Tier deleted.')->flash();

        return redirect()->route('admin.billing.tiers');
    }

    protected function formData(?Tier $tier): array
    {
        return [
            'tier' => $tier,
            'nests' => Nest::query()->with('eggs')->orderBy('name')->get(),
            'locations' => Location::query()->orderBy('short')->get(),
            'categories' => Product::query()->distinct()->orderBy('category')->pluck('category')
                ->merge(Tier::query()->distinct()->pluck('category'))->unique()->sort()->values(),
            'environment' => collect($tier->environment ?? [])->map(fn ($v, $k) => "$k=$v")->implode("\n"),
        ];
    }

    /**
     * @throws ValidationException
     */
    protected function validated(Request $request): array
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'between:1,64', 'not_regex:/[<>]/'],
            'category' => 'required|string|between:1,191',
            'tagline' => 'nullable|string|max:191',
            'description' => 'nullable|string|max:5000',
            'features' => 'nullable|string|max:3000',
            'egg_id' => 'required|integer|exists:eggs,id',
            'location_ids' => 'required|array|min:1',
            'location_ids.*' => 'integer|exists:locations,id',
            'environment' => 'nullable|string|max:10000',
            'docker_image' => 'nullable|string|max:191',
            'startup' => 'nullable|string|max:5000',
            'min_gb' => 'required|integer|between:1,1024',
            'max_gb' => 'required|integer|between:1,1024|gte:min_gb',
            'step_gb' => 'required|integer|between:1,64',
            'base_price' => 'nullable|string|max:16',
            'price_per_gb' => 'required|string|max:16',
            'discount_from_gb' => 'nullable|integer|between:1,1024',
            'discount_percent' => 'nullable|integer|between:0,90',
            'setup_fee' => 'nullable|string|max:16',
            'cpu_per_gb' => 'required|integer|between:0,10000',
            'cpu_min' => 'nullable|integer|between:0,100000',
            'cpu_max' => 'nullable|integer|between:0,100000',
            'disk_per_gb' => 'required|numeric|between:0,10240',
            'disk_min' => 'nullable|numeric|between:0,102400',
            'disk_max' => 'nullable|numeric|between:0,102400',
            'swap' => 'required|integer|min:-1|max:1048576',
            'io' => 'required|integer|between:10,1000',
            'database_limit' => 'required|integer|min:0|max:1000',
            'allocation_limit' => 'required|integer|min:0|max:1000',
            'backup_limit' => 'required|integer|min:0|max:1000',
            'discord_role_id' => ['nullable', 'regex:/^\d{17,20}$/'],
            'stock' => 'nullable|integer|min:0|max:100000',
            'sort' => 'nullable|integer|min:0|max:100000',
        ], [
            'max_gb.gte' => 'The largest size must be at least the smallest size.',
            'discord_role_id.regex' => 'The Discord role ID is a long number: in Discord, right-click the role and choose Copy Role ID.',
        ]);

        $money = [];
        foreach (['base_price' => 'base fee', 'price_per_gb' => 'price per GB', 'setup_fee' => 'setup fee'] as $field => $label) {
            $money[$field] = Money::parse((string) ($data[$field] ?? '0') ?: '0');
            if (is_null($money[$field])) {
                throw ValidationException::withMessages([$field => "Enter the $label as a number, like 2.25."]);
            }
        }

        if (count(range($data['min_gb'], $data['max_gb'], $data['step_gb'])) > Tier::MAX_SIZES) {
            throw ValidationException::withMessages(['max_gb' => 'That is too many sizes. Use a bigger step or a smaller range (at most ' . Tier::MAX_SIZES . ' sizes).']);
        }
        if (!empty($data['cpu_max']) && ($data['cpu_min'] ?? 0) > $data['cpu_max']) {
            throw ValidationException::withMessages(['cpu_max' => 'The CPU maximum must be at least the minimum.']);
        }
        if (!empty($data['disk_max']) && ($data['disk_min'] ?? 0) > $data['disk_max']) {
            throw ValidationException::withMessages(['disk_max' => 'The disk maximum must be at least the minimum.']);
        }

        /** @var Egg $egg */
        $egg = Egg::query()->findOrFail($data['egg_id']);
        $environment = $this->parseEnvironment($egg, $data['environment'] ?? '');
        if (!empty($data['docker_image']) && !in_array($data['docker_image'], array_values($egg->docker_images), true)) {
            throw ValidationException::withMessages(['docker_image' => 'Pick one of the Docker images offered by this egg, or leave it empty to use the default.']);
        }

        $features = collect(preg_split('/\r\n|\r|\n/', (string) ($data['features'] ?? '')))
            ->map(fn ($line) => trim(mb_substr(trim((string) $line), 0, 120)))
            ->filter()->take(12)->values()->all();

        $gbToMb = fn ($value) => isset($value) && $value !== '' ? (int) round((float) $value * 1024) : null;
        $discountPercent = (int) ($data['discount_percent'] ?? 0);

        return [
            'name' => trim($data['name']),
            'category' => trim($data['category']),
            'tagline' => $data['tagline'] ?? null,
            'description' => $data['description'] ?? null,
            'features' => $features ?: null,
            'highlight' => $request->boolean('highlight'),
            'egg_id' => $egg->id,
            'location_ids' => array_values(array_unique(array_map('intval', $data['location_ids']))),
            'environment' => $environment ?: null,
            'docker_image' => $data['docker_image'] ?? null,
            'startup' => $data['startup'] ?? null,
            'min_gb' => (int) $data['min_gb'],
            'max_gb' => (int) $data['max_gb'],
            'step_gb' => (int) $data['step_gb'],
            'base_price' => $money['base_price'],
            'price_per_gb' => $money['price_per_gb'],
            'discount_from_gb' => $discountPercent > 0 && !empty($data['discount_from_gb']) ? (int) $data['discount_from_gb'] : null,
            'discount_percent' => !empty($data['discount_from_gb']) ? $discountPercent : 0,
            'setup_fee' => $money['setup_fee'],
            'cpu_per_gb' => (int) $data['cpu_per_gb'],
            'cpu_min' => (int) ($data['cpu_min'] ?? 0),
            'cpu_max' => !empty($data['cpu_max']) ? (int) $data['cpu_max'] : null,
            'disk_per_gb' => $gbToMb($data['disk_per_gb']) ?? 0,
            'disk_min' => $gbToMb($data['disk_min'] ?? null) ?? 0,
            'disk_max' => !empty($data['disk_max']) ? $gbToMb($data['disk_max']) : null,
            'swap' => (int) $data['swap'],
            'io' => (int) $data['io'],
            'database_limit' => (int) $data['database_limit'],
            'allocation_limit' => (int) $data['allocation_limit'],
            'backup_limit' => (int) $data['backup_limit'],
            'stock' => isset($data['stock']) ? (int) $data['stock'] : null,
            'discord_role_id' => $data['discord_role_id'] ?? null,
            'is_active' => $request->boolean('is_active'),
            'sort' => (int) ($data['sort'] ?? 0),
        ];
    }
}
