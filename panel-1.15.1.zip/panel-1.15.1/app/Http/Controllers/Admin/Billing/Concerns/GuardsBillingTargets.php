<?php

namespace Pterodactyl\Http\Controllers\Admin\Billing\Concerns;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * Stops staff using billing permissions on their own account (free credit, marking
 * their own invoices paid, refunding themselves) or on accounts they are not allowed
 * to manage, such as root administrators. Root administrators are not restricted.
 */
trait GuardsBillingTargets
{
    protected function guardTarget(Request $request, ?User $target): void
    {
        /** @var User $actor */
        $actor = $request->user();
        if ($actor->root_admin || is_null($target)) {
            return;
        }

        if ($actor->id === $target->id) {
            throw new AccessDeniedHttpException('You cannot make billing changes to your own account. Ask another staff member.');
        }

        if (!$actor->canManageUser($target)) {
            throw new AccessDeniedHttpException('You are not allowed to make billing changes for this account.');
        }
    }

    /**
     * Requires an extra admin permission, for billing actions that also change a server.
     */
    protected function requirePermission(Request $request, string $permission): void
    {
        if (!$request->user()->hasAdminPermission($permission)) {
            throw new AccessDeniedHttpException("This also needs the \"$permission\" permission.");
        }
    }
}
