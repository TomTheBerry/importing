<?php

namespace Pterodactyl\Http\Controllers\Admin\Billing\Concerns;

use Pterodactyl\Models\Egg;
use Pterodactyl\Models\EggVariable;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

trait ParsesEggEnvironment
{
    /**
     * Reads KEY=value lines and checks every value against the egg's own rules, so a
     * plan can never fail to deploy because of a bad variable.
     *
     * @throws ValidationException
     */
    protected function parseEnvironment(Egg $egg, string $text): array
    {
        $variables = EggVariable::query()->where('egg_id', $egg->id)->get()->keyBy('env_variable');
        $environment = [];

        foreach (preg_split('/\r\n|\r|\n/', $text) as $number => $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            [$key, $value] = array_pad(explode('=', $line, 2), 2, '');
            $key = trim($key);
            if (!$variables->has($key)) {
                throw ValidationException::withMessages(['environment' => 'Line ' . ($number + 1) . ": \"$key\" is not a variable of this egg."]);
            }

            $environment[$key] = $value;
        }

        foreach ($environment as $key => $value) {
            $validator = Validator::make(['value' => $value], ['value' => $variables[$key]->rules]);
            if ($validator->fails()) {
                throw ValidationException::withMessages(['environment' => "$key: " . $validator->errors()->first('value')]);
            }
        }

        return $environment;
    }
}
