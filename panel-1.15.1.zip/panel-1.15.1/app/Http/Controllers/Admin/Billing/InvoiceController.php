<?php

namespace Pterodactyl\Http\Controllers\Admin\Billing;

use Illuminate\View\View;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\Billing\Invoice;
use Pterodactyl\Models\Billing\Payment;
use Pterodactyl\Services\Billing\Money;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Validation\ValidationException;
use Pterodactyl\Services\Billing\RefundService;
use Pterodactyl\Services\Billing\InvoiceService;
use Pterodactyl\Notifications\Billing\InvoiceCreated;
use Pterodactyl\Services\Billing\OwnerCleanupService;
use Pterodactyl\Http\Controllers\Admin\Billing\Concerns\GuardsBillingTargets;

class InvoiceController extends Controller
{
    use GuardsBillingTargets;

    public function __construct(private AlertsMessageBag $alert, private InvoiceService $invoices, private RefundService $refunds)
    {
    }

    public function index(Request $request): View
    {
        $status = $request->query('status');
        $search = trim((string) $request->query('search', ''));

        $invoices = Invoice::query()->with(['user', 'subscription'])
            ->when($status === 'overdue', fn ($q) => $q->where('status', Invoice::STATUS_UNPAID)->where('due_at', '<', now()))
            ->when(in_array($status, ['unpaid', 'paid', 'void', 'refunded'], true), fn ($q) => $q->where('status', $status))
            ->when($search !== '', function ($q) use ($search) {
                $like = '%' . addcslashes($search, '%_\\') . '%';
                $q->where(fn ($q) => $q->where('number', 'like', $like)
                    ->orWhereHas('user', fn ($q) => $q->where('email', 'like', $like)->orWhere('username', 'like', $like)));
            })
            ->orderByDesc('id')
            ->paginate(50)->withQueryString();

        return view('admin.billing.invoices.index', ['invoices' => $invoices, 'status' => $status, 'search' => $search]);
    }

    public function view(int $id): View
    {
        /** @var Invoice $invoice */
        $invoice = Invoice::query()->with(['user', 'subscription', 'items', 'payments', 'coupon'])->findOrFail($id);

        return view('admin.billing.invoices.view', ['invoice' => $invoice]);
    }

    public function create(Request $request): View
    {
        $user = $request->query('user') ? User::query()->find((int) $request->query('user')) : null;

        return view('admin.billing.invoices.new', ['user' => $user]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'user_id' => 'required|integer|exists:users,id',
            'due_at' => 'required|date',
            'notes' => 'nullable|string|max:2000',
            'items' => 'required|array|min:1|max:20',
            'items.*.description' => 'nullable|string|max:191',
            'items.*.amount' => 'nullable|string|max:16',
        ]);

        $items = [];
        foreach ($data['items'] as $n => $item) {
            if (empty($item['description']) && empty($item['amount'])) {
                continue;
            }
            $amount = Money::parse($item['amount'] ?? '');
            if (empty($item['description']) || !$amount) {
                throw ValidationException::withMessages(["items.$n.amount" => 'Line ' . ($n + 1) . ' needs a description and an amount like 5.00.']);
            }
            $items[] = ['description' => $item['description'], 'amount' => $amount];
        }
        if (empty($items)) {
            throw ValidationException::withMessages(['items' => 'Add at least one line.']);
        }

        /** @var User $user */
        $user = User::query()->findOrFail($data['user_id']);
        $this->guardTarget($request, $user);
        $invoice = $this->invoices->createManual($user, $items, CarbonImmutable::parse($data['due_at']), $data['notes'] ?? null);

        if ($request->boolean('send_email')) {
            $user->notify(new InvoiceCreated($invoice));
        }

        $this->alert->success("Invoice {$invoice->displayNumber()} created.")->flash();

        return redirect()->route('admin.billing.invoices.view', $invoice->id);
    }

    /**
     * Records a payment received outside the Panel (bank transfer, cash, etc).
     */
    public function markPaid(Request $request, int $id): RedirectResponse
    {
        /** @var Invoice $invoice */
        $invoice = Invoice::query()->findOrFail($id);
        $this->guardTarget($request, $invoice->user);
        $data = $request->validate(['reference' => 'nullable|string|max:120', 'note' => 'nullable|string|max:191']);

        $reference = !empty($data['reference']) ? 'manual:' . $data['reference'] : null;
        if ($reference && Payment::query()->where('gateway', Payment::GATEWAY_MANUAL)->where('reference', $reference)->exists()) {
            throw ValidationException::withMessages(['reference' => 'A payment with that reference has already been recorded.']);
        }

        $note = trim('Marked paid by ' . $request->user()->username . '. ' . ($data['note'] ?? ''));
        if (!$this->invoices->markPaid($invoice, Payment::GATEWAY_MANUAL, $reference, $invoice->total, $request->user(), $note)) {
            $this->alert->danger('This invoice is not unpaid.')->flash();
        } else {
            $this->alert->success('Invoice marked as paid.')->flash();
        }

        return redirect()->route('admin.billing.invoices.view', $invoice->id);
    }

    public function void(Request $request, int $id): RedirectResponse
    {
        /** @var Invoice $invoice */
        $invoice = Invoice::query()->findOrFail($id);
        $this->guardTarget($request, $invoice->user);
        $this->invoices->void($invoice, $request->user());
        if ($invoice->status !== Invoice::STATUS_VOID) {
            $this->alert->danger('This invoice was paid or changed a moment ago, so it was not voided.')->flash();
        } else {
            $this->alert->success('Invoice voided.' . ($invoice->credit_applied > 0 ? ' The credit used on it was returned to the customer.' : ''))->flash();
        }

        return redirect()->route('admin.billing.invoices.view', $invoice->id);
    }

    public function refund(Request $request, int $id): RedirectResponse
    {
        /** @var Payment $payment */
        $payment = Payment::query()->findOrFail($id);
        $this->guardTarget($request, $payment->user);
        $data = $request->validate([
            'amount' => 'required|string|max:16',
            'method' => 'required|in:card,credit',
            'reason' => 'required|string|between:3,191',
        ]);

        $amount = Money::parse($data['amount']) ?? throw ValidationException::withMessages(['amount' => 'Enter an amount like 5.00.']);
        $this->refunds->refund($payment, $amount, $data['method'] === 'credit', $request->user(), $data['reason']);

        $this->alert->success(sprintf('Refunded %s %s.', Money::format($amount), $data['method'] === 'credit' ? 'as account credit' : 'to the card'))->flash();

        return $payment->invoice_id
            ? redirect()->route('admin.billing.invoices.view', $payment->invoice_id)
            : redirect()->route('admin.billing');
    }

    /**
     * Permanently deletes an invoice (panel owner only, for clearing out tests).
     */
    public function delete(Request $request, int $id, OwnerCleanupService $cleanup): RedirectResponse
    {
        /** @var Invoice $invoice */
        $invoice = Invoice::query()->findOrFail($id);
        $label = $invoice->displayNumber();
        $cleanup->deleteInvoice($invoice, $request->user(), $request->boolean('return_credit'));

        $this->alert->success("Invoice $label was permanently deleted.")->flash();

        return redirect()->route('admin.billing.invoices');
    }
}
