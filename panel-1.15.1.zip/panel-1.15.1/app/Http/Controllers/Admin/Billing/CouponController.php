<?php

namespace Pterodactyl\Http\Controllers\Admin\Billing;

use Illuminate\View\View;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\Billing\Coupon;
use Pterodactyl\Models\Billing\Product;
use Pterodactyl\Services\Billing\Money;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Validation\ValidationException;

class CouponController extends Controller
{
    public function __construct(private AlertsMessageBag $alert)
    {
    }

    public function index(): View
    {
        return view('admin.billing.coupons.index', [
            'coupons' => Coupon::query()->orderByDesc('is_active')->orderBy('code')->get(),
            'products' => Product::query()->orderBy('category')->orderBy('price')->get(),
        ]);
    }

    public function view(int $id): View
    {
        return view('admin.billing.coupons.edit', [
            'coupon' => Coupon::query()->findOrFail($id),
            'products' => Product::query()->orderBy('category')->orderBy('price')->get(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $coupon = new Coupon();
        $coupon->forceFill($this->validated($request, null))->saveOrFail();
        $this->alert->success("Coupon $coupon->code created.")->flash();

        return redirect()->route('admin.billing.coupons');
    }

    public function update(Request $request, int $id): RedirectResponse
    {
        /** @var Coupon $coupon */
        $coupon = Coupon::query()->findOrFail($id);
        $coupon->forceFill($this->validated($request, $coupon))->saveOrFail();
        $this->alert->success("Coupon $coupon->code updated.")->flash();

        return redirect()->route('admin.billing.coupons');
    }

    public function delete(int $id): RedirectResponse
    {
        Coupon::query()->findOrFail($id)->delete();
        $this->alert->success('Coupon deleted.')->flash();

        return redirect()->route('admin.billing.coupons');
    }

    protected function validated(Request $request, ?Coupon $coupon): array
    {
        $data = $request->validate([
            'code' => ['required', 'string', 'between:3,64', 'regex:/^[A-Za-z0-9_-]+$/'],
            'type' => 'required|in:percent,fixed',
            'value' => 'required|string|max:16',
            'duration' => 'required|in:once,forever',
            'max_uses' => 'nullable|integer|min:1|max:1000000',
            'product_ids' => 'nullable|array',
            'product_ids.*' => 'integer|exists:billing_products,id',
            'expires_at' => 'nullable|date',
        ]);

        $code = mb_strtoupper(trim($data['code']));
        if (Coupon::query()->where('code', $code)->when($coupon, fn ($q) => $q->whereKeyNot($coupon->id))->exists()) {
            throw ValidationException::withMessages(['code' => 'A coupon with that code already exists.']);
        }

        if ($data['type'] === Coupon::TYPE_PERCENT) {
            $value = filter_var($data['value'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 100]]);
            if ($value === false) {
                throw ValidationException::withMessages(['value' => 'A percentage discount must be a whole number from 1 to 100.']);
            }
        } else {
            $value = Money::parse($data['value']);
            if (!$value) {
                throw ValidationException::withMessages(['value' => 'Enter the discount amount, like 2.50.']);
            }
        }

        return [
            'code' => $code,
            'type' => $data['type'],
            'value' => $value,
            'duration' => $data['duration'],
            'max_uses' => $data['max_uses'] ?? null,
            'product_ids' => empty($data['product_ids']) ? null : array_values(array_map('intval', $data['product_ids'])),
            'expires_at' => empty($data['expires_at']) ? null : CarbonImmutable::parse($data['expires_at'])->endOfDay(),
            'is_active' => $request->boolean('is_active'),
        ];
    }
}
