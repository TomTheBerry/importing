<?php

namespace Pterodactyl\Http\Controllers\Admin\Billing;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Cache;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\Billing\Invoice;
use Pterodactyl\Models\Billing\Payment;
use Pterodactyl\Services\Billing\Money;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Billing\Subscription;
use Pterodactyl\Services\Billing\StripeClient;
use Pterodactyl\Services\Billing\CreditService;
use Pterodactyl\Http\Controllers\Admin\Billing\Concerns\GuardsBillingTargets;

class OverviewController extends Controller
{
    use GuardsBillingTargets;

    public function __construct(private AlertsMessageBag $alert, private CreditService $credit)
    {
    }

    /**
     * Revenue, outstanding invoices and the health of the billing setup.
     */
    public function index(): View
    {
        $cash = fn () => Payment::query()->where('gateway', '!=', Payment::GATEWAY_CREDIT);

        $months = collect(range(5, 0))->map(function (int $ago) use ($cash) {
            $start = now()->startOfMonth()->subMonthsNoOverflow($ago);
            $row = $cash()->toBase()->whereBetween('created_at', [$start, $start->copy()->endOfMonth()])
                ->selectRaw('COALESCE(SUM(amount), 0) as paid, COALESCE(SUM(refunded_amount), 0) as refunded')->first();

            return ['label' => $start->format('M'), 'amount' => (int) $row->paid - (int) $row->refunded];
        });

        $secret = (string) config('billing.stripe.secret');

        return view('admin.billing.index', [
            'mrr' => (int) Subscription::query()->where('status', Subscription::STATUS_ACTIVE)->where('cancel_at_period_end', false)->sum('price'),
            'thisMonth' => $months->last()['amount'],
            'months' => $months,
            'monthsMax' => max(1, $months->max('amount')),
            'unpaidTotal' => (int) Invoice::query()->where('status', Invoice::STATUS_UNPAID)->sum('total'),
            'unpaidCount' => Invoice::query()->where('status', Invoice::STATUS_UNPAID)->count(),
            'overdueCount' => Invoice::query()->where('status', Invoice::STATUS_UNPAID)->where('due_at', '<', now())->count(),
            'counts' => Subscription::query()->select('status', DB::raw('COUNT(*) as total'))->groupBy('status')->pluck('total', 'status'),
            'creditTotal' => (int) User::query()->sum('billing_credit'),
            'payments' => Payment::query()->with(['user', 'invoice'])->orderByDesc('id')->limit(10)->get(),
            'failed' => Subscription::query()->with('user')->where('status', Subscription::STATUS_FAILED)->limit(10)->get(),
            'overdue' => Invoice::query()->with(['user', 'subscription'])->where('status', Invoice::STATUS_UNPAID)->where('due_at', '<', now())->orderBy('due_at')->limit(10)->get(),
            'status' => [
                'enabled' => (bool) config('billing.enabled'),
                'stripe' => StripeClient::configured(),
                'stripe_mode' => str_starts_with($secret, 'sk_live_') || str_starts_with($secret, 'rk_live_') ? 'live' : ($secret ? 'test' : null),
                'webhook' => !empty(config('billing.stripe.webhook_secret')),
                'webhook_url' => route('billing.webhooks.stripe'),
                'last_run' => Cache::get('billing:last_run'),
                'currency' => strtoupper(Money::currency()),
            ],
        ]);
    }

    /**
     * Adds or removes account credit for a user.
     */
    public function credit(Request $request, int $id): RedirectResponse
    {
        /** @var User $user */
        $user = User::query()->findOrFail($id);
        $this->guardTarget($request, $user);
        $data = $request->validate([
            'amount' => 'required|string|max:16',
            'direction' => 'required|in:add,remove',
            'reason' => 'required|string|between:3,191',
        ]);

        $amount = Money::parse($data['amount']);
        if (!$amount) {
            return redirect()->back()->withErrors(['amount' => 'Enter an amount like 5.00.'])->withInput();
        }

        $this->credit->adjust($user, $data['direction'] === 'add' ? $amount : -$amount, $data['reason'], null, $request->user());
        $this->alert->success(sprintf('%s %s %s account credit.', $data['direction'] === 'add' ? 'Added' : 'Removed', Money::format($amount), $data['direction'] === 'add' ? 'to' : 'from'))->flash();

        return redirect()->back();
    }
}
