<?php

namespace Pterodactyl\Http\Controllers\Base;

use Illuminate\Http\Request;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Models\PrivacyRequest;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Privacy\PrivacyService;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Downloads a data export. Only the account it belongs to can download it, while
 * logged in, and only until it expires.
 */
class PrivacyDownloadController extends Controller
{
    public function __invoke(Request $request, string $uuid, PrivacyService $privacy): BinaryFileResponse
    {
        /** @var PrivacyRequest|null $export */
        $export = PrivacyRequest::query()
            ->where('uuid', $uuid)
            ->where('user_id', $request->user()->id)
            ->where('type', PrivacyRequest::TYPE_EXPORT)
            ->first();

        $path = $export ? $privacy->exportFilePath($export) : null;
        if (!$path) {
            throw new NotFoundHttpException('This download has expired or does not exist.');
        }

        $export->forceFill(['downloaded_at' => now()])->save();
        Activity::event('privacy:export.downloaded')->withRequestMetadata()->subject($request->user())->log();

        $name = str_replace(' ', '-', strtolower((string) config('app.name', 'panel'))) . '-data-' . now()->format('Y-m-d') . '.zip';

        return response()->download($path, $name, [
            'Content-Type' => 'application/zip',
            'Cache-Control' => 'no-store, private',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }
}
