<?php

namespace Pterodactyl\Http\Controllers\Base;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Support\TicketAttachment;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Pterodactyl\Services\Support\TicketAttachmentService;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Files attached to support tickets. Only the ticket's customer and staff who can read
 * tickets can open them. Files on internal notes are staff only.
 */
class TicketAttachmentController extends Controller
{
    public function __invoke(Request $request, string $uuid, TicketAttachmentService $service): StreamedResponse
    {
        /** @var User $user */
        $user = $request->user();

        /** @var TicketAttachment|null $attachment */
        $attachment = TicketAttachment::query()->with(['ticket', 'message'])->where('uuid', $uuid)->first();
        if (!$attachment || !$attachment->ticket || !$attachment->message) {
            throw new NotFoundHttpException();
        }

        $isStaff = $user->hasAdminPermission('tickets.read');
        $isCustomer = $attachment->ticket->user_id === $user->id && !$attachment->message->internal;
        if (!$isStaff && !$isCustomer) {
            throw new NotFoundHttpException();
        }

        return $service->download($attachment);
    }
}
