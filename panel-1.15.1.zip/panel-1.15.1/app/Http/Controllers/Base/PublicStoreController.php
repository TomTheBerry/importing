<?php

namespace Pterodactyl\Http\Controllers\Base;

use Illuminate\View\View;
use Pterodactyl\Models\Location;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\Billing\Tier;
use Pterodactyl\Models\Billing\Product;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Billing\BillingPresenter;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * The store, which anyone can browse without logging in. Ordering still needs an
 * account (the checkout uses the logged-in client API).
 */
class PublicStoreController extends Controller
{
    /**
     * The store pages themselves (the same single-page app as the rest of the Panel).
     */
    public function page(): View
    {
        $this->ensureEnabled();

        return view('templates/base.core');
    }

    /**
     * Plans and prices. Only what is shown in the store, nothing about customers.
     */
    public function catalogue(): JsonResponse
    {
        $this->ensureEnabled();

        $products = Product::query()->with('egg')->where('is_active', true)->whereNull('tier_id')
            ->orderBy('category')->orderBy('sort')->orderBy('price')->get();
        $tiers = Tier::query()->with(['egg', 'variants.egg'])->where('is_active', true)
            ->orderBy('category')->orderBy('sort')->orderBy('id')->get()
            ->filter(fn (Tier $t) => $t->variants->contains('is_active', true));
        $locations = Location::query()->get()->keyBy('id')->all();

        return new JsonResponse([
            'data' => $products->map(fn (Product $p) => BillingPresenter::product($p, $locations))->values(),
            'tiers' => $tiers->map(fn (Tier $t) => BillingPresenter::tier($t, $locations))->values(),
        ], 200, ['Cache-Control' => 'public, max-age=60']);
    }

    private function ensureEnabled(): void
    {
        if (!config('billing.enabled')) {
            throw new NotFoundHttpException();
        }
    }
}
