<?php

namespace Pterodactyl\Http\Controllers\Base;

use Illuminate\Http\Response;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Legal\CompanyDetails;

/**
 * The public legal pages (/privacy, /tos, /aup). The text is in resources/legal (made
 * from the same source as the Word versions) and is shown inside the site's own header,
 * theme and footer. Company details in the text come from config/company.php.
 */
class LegalPageController extends Controller
{
    public function privacy(): Response
    {
        return $this->page('privacy', 'privacy-policy.html', 'Privacy Policy', 'How TheBerryHost (Berry Technologies Ltd) collects, uses and protects your personal information.');
    }

    public function terms(): Response
    {
        return $this->page('terms', 'terms-of-service.html', 'Terms of Service', 'The terms for using TheBerryHost (Berry Technologies Ltd) game server hosting, including our Acceptable Use Policy and refund policy.');
    }

    /**
     * The Acceptable Use Policy is section 5 of the Terms of Service.
     */
    public function aup(): RedirectResponse
    {
        return redirect()->to('/tos#acceptable-use');
    }

    private function page(string $page, string $file, string $title, string $description): Response
    {
        $html = @file_get_contents(resource_path('legal/' . $file));
        if (!$html) {
            return response("The $title is not available right now.", 503, ['Content-Type' => 'text/plain; charset=UTF-8']);
        }

        return response()->view('legal.page', [
            'page' => $page,
            'title' => $title,
            'description' => $description,
            'content' => CompanyDetails::fillPlaceholders($html),
        ])->header('Cache-Control', 'private, max-age=300');
    }
}
