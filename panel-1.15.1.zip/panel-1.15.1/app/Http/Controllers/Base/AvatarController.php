<?php

namespace Pterodactyl\Http\Controllers\Base;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\Response;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Users\AvatarService;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class AvatarController extends Controller
{
    /**
     * Colours used for generated default pictures.
     */
    private const COLOURS = ['#0C8F8F', '#587291', '#73B06F', '#C2662D', '#7E57C2', '#3C8DBC', '#D81B60', '#00897B'];

    public function __construct(private AvatarService $service)
    {
    }

    /**
     * Returns a user's profile picture, or a generated default picture made from
     * the first letter of their name.
     */
    public function show(string $uuid): Response|BinaryFileResponse
    {
        /** @var User $user */
        $user = User::query()->where('uuid', $uuid)->firstOrFail();
        $path = $this->service->path($user);

        if (!is_null($path)) {
            return response()->file($path, $this->headers(str_ends_with($path, '.png') ? 'image/png' : 'image/webp'));
        }

        $letter = mb_strtoupper(mb_substr(trim($user->name_first ?: $user->username), 0, 1));

        return $this->svg($letter, self::COLOURS[hexdec(substr(md5($user->uuid), 0, 2)) % count(self::COLOURS)]);
    }

    /**
     * An uploaded profile picture behind a signed link (see DiscordBridge). The "v" part
     * must match the current picture, so old links stop working once it changes.
     */
    public function publicAvatar(Request $request, string $uuid): BinaryFileResponse
    {
        /** @var User|null $user */
        $user = User::query()->where('uuid', $uuid)->first();
        $path = $user ? $this->service->path($user) : null;
        if (!$user || !$path || !hash_equals(substr((string) $user->avatar, 0, 8), (string) $request->query('v'))) {
            throw new NotFoundHttpException();
        }

        return response()->file($path, array_merge(
            $this->headers(str_ends_with($path, '.png') ? 'image/png' : 'image/webp'),
            ['Cache-Control' => 'public, max-age=86400'],
        ));
    }

    /**
     * Generic picture used for staff members whose identity is hidden in activity logs.
     */
    public function staff(): Response
    {
        return $this->svg('★', '#3C8DBC');
    }

    protected function svg(string $letter, string $colour): Response
    {
        // Only allow a single letter/number (or our star), so nothing user controlled
        // can ever be injected into the SVG markup.
        if ($letter !== '★' && preg_match('/^[\p{L}\p{N}]$/u', $letter) !== 1) {
            $letter = '?';
        }

        $letter = htmlspecialchars($letter, ENT_QUOTES | ENT_XML1, 'UTF-8');
        $svg = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64"><rect width="64" height="64" fill="{$colour}"/><text x="50%" y="50%" dy=".35em" text-anchor="middle" font-family="Helvetica,Arial,sans-serif" font-size="30" font-weight="600" fill="#ffffff">{$letter}</text></svg>
SVG;

        return response($svg, 200, $this->headers('image/svg+xml'));
    }

    protected function headers(string $type): array
    {
        return [
            'Content-Type' => $type,
            'Content-Disposition' => 'inline; filename="avatar"',
            'X-Content-Type-Options' => 'nosniff',
            // Even if a browser were tricked into rendering this as a document, nothing in it may run.
            'Content-Security-Policy' => "default-src 'none'; style-src 'unsafe-inline'; sandbox",
            'Cache-Control' => 'private, max-age=86400',
        ];
    }
}
