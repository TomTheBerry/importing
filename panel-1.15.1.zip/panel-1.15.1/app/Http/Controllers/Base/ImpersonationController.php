<?php

namespace Pterodactyl\Http\Controllers\Base;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Sessions\ImpersonationService;

/**
 * "Return to admin": ends a "view as this user" session.
 */
class ImpersonationController extends Controller
{
    public function __construct(private ImpersonationService $impersonation)
    {
    }

    public function __invoke(Request $request): RedirectResponse
    {
        $target = $this->impersonation->stop($request);

        if (!$request->user()) {
            return redirect()->route('auth.login');
        }

        return $target
            ? redirect()->route('admin.users.view', $target->id)
            : redirect()->route('index');
    }
}
