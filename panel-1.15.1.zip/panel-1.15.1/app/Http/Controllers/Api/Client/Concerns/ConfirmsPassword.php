<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Concerns;

use Pterodactyl\Models\User;
use Pterodactyl\Facades\Activity;
use Illuminate\Support\Facades\RateLimiter;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\TooManyRequestsHttpException;

/**
 * Asking for the account password before sensitive changes (two-step settings and
 * connected accounts). Wrong passwords are logged and share one limit per account
 * across every such action, so someone with only a stolen session can't guess it.
 */
trait ConfirmsPassword
{
    protected function confirmPassword(User $user, mixed $password): void
    {
        $key = 'confirm-password:' . $user->id;

        if (RateLimiter::tooManyAttempts($key, 10)) {
            $minutes = (int) ceil(RateLimiter::availableIn($key) / 60);

            throw new TooManyRequestsHttpException(RateLimiter::availableIn($key), "Too many wrong passwords. Please try again in $minutes minute" . ($minutes === 1 ? '' : 's') . '.');
        }

        if (!is_string($password) || !password_verify($password, $user->password)) {
            RateLimiter::hit($key, 15 * 60);
            Activity::event('user:password-confirm.fail')->withRequestMetadata()->subject($user)->log();

            throw new BadRequestHttpException('The password provided was not valid.');
        }

        RateLimiter::clear($key);
    }
}
