<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use PragmaRX\Google2FA\Google2FA;
use Pterodactyl\Facades\Activity;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Contracts\Encryption\Encrypter;
use Pterodactyl\Services\Users\TwoFactorPolicy;
use Pterodactyl\Services\Users\EmailCodeService;
use Pterodactyl\Services\Users\TwoFactorSetupService;
use Pterodactyl\Services\Users\ToggleTwoFactorService;
use Illuminate\Contracts\Validation\Factory as ValidationFactory;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Pterodactyl\Http\Controllers\Api\Client\Concerns\ConfirmsPassword;

/**
 * Two-step verification settings for the logged in account.
 *
 * Every change needs the account password plus a code proving the person has the
 * second factor (their authenticator app, a recovery code, or an emailed code), so a
 * hijacked session alone can't switch it off or move it to an attacker's device.
 * Whether someone is *allowed* to be without it is enforced on every request by
 * RequireTwoFactorAuthentication, which sends them straight back to set it up.
 */
class TwoFactorController extends ClientApiController
{
    use ConfirmsPassword;

    private const EMAIL_PURPOSES = [
        'enable' => ['account:enable-email', 'turn on email codes for two-step verification'],
        'disable' => ['account:disable-email', 'turn off email codes for two-step verification'],
    ];

    public function __construct(
        private ToggleTwoFactorService $toggleTwoFactorService,
        private TwoFactorSetupService $setupService,
        private ValidationFactory $validation,
        private EmailCodeService $emailCodes,
        private Encrypter $encrypter,
        private Google2FA $google2FA,
        private ConnectionInterface $connection,
    ) {
        parent::__construct();
    }

    /**
     * Returns a new secret and QR code data for setting up an authenticator app.
     * If an app is already set up this returns a 400 error.
     *
     * @throws \Pterodactyl\Exceptions\Model\DataValidationException
     * @throws \Pterodactyl\Exceptions\Repository\RecordNotFoundException
     */
    public function index(Request $request): JsonResponse
    {
        if ($request->user()->use_totp) {
            throw new BadRequestHttpException('Two-factor authentication is already enabled on this account.');
        }

        return new JsonResponse([
            'data' => $this->setupService->handle($request->user()),
        ]);
    }

    /**
     * The account's current two-step settings.
     */
    public function status(Request $request): JsonResponse
    {
        return new JsonResponse(['data' => TwoFactorPolicy::status($request->user())]);
    }

    /**
     * Turns on the authenticator app once the person proves it works.
     *
     * @throws \Throwable
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): JsonResponse
    {
        $data = $this->validation->make($request->all(), [
            'code' => ['required', 'string', 'size:6'],
            'password' => ['required', 'string'],
            'app_name' => ['nullable', 'string', 'max:64'],
        ])->validate();

        /** @var User $user */
        $user = $request->user();
        if ($user->use_totp) {
            throw new BadRequestHttpException('An authenticator app is already set up on this account.');
        }

        $this->confirmPassword($user, $data['password']);

        $tokens = $this->toggleTwoFactorService->handle($user, $data['code'], true);
        $user->forceFill(['totp_app_name' => $this->cleanAppName($data['app_name'] ?? null)])->save();

        Activity::event('user:two-factor.create')->property('app', $user->totp_app_name)->log();

        return new JsonResponse([
            'object' => 'recovery_tokens',
            'attributes' => [
                'tokens' => $tokens,
            ],
            'meta' => ['two_factor' => TwoFactorPolicy::status($user->refresh())],
        ]);
    }

    /**
     * Turns off the authenticator app. Needs the password and a current code from the
     * app or a recovery code.
     *
     * @throws \Throwable
     */
    public function delete(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        if (!$user->use_totp) {
            throw new BadRequestHttpException('No authenticator app is set up on this account.');
        }

        $this->confirmPassword($user, $request->input('password'));
        $this->checkAppCode($user, $request->input('code'));

        $this->connection->transaction(function () use ($user) {
            $user->recoveryTokens()->delete();
            $user->forceFill([
                'totp_authenticated_at' => Carbon::now(),
                'use_totp' => false,
                'totp_secret' => null,
                'totp_app_name' => null,
            ])->save();
        });

        Activity::event('user:two-factor.delete')->log();

        return $this->statusResponse($user);
    }

    /**
     * Changes the reminder of which authenticator app is being used.
     */
    public function appName(Request $request): JsonResponse
    {
        $data = $this->validation->make($request->all(), [
            'app_name' => ['nullable', 'string', 'max:64'],
        ])->validate();

        /** @var User $user */
        $user = $request->user();
        if (!$user->use_totp) {
            throw new BadRequestHttpException('No authenticator app is set up on this account.');
        }

        $user->forceFill(['totp_app_name' => $this->cleanAppName($data['app_name'] ?? null)])->save();

        Activity::event('user:two-factor.app-name')->property('app', $user->totp_app_name)->log();

        return $this->statusResponse($user);
    }

    /**
     * Replaces all recovery codes with a fresh set.
     *
     * @throws \Throwable
     */
    public function recoveryTokens(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        if (!$user->use_totp) {
            throw new BadRequestHttpException('No authenticator app is set up on this account.');
        }

        $this->confirmPassword($user, $request->input('password'));
        $code = preg_replace('/\s+/', '', (string) $request->input('code'));
        if (!preg_match('/^\d{6}$/', $code)) {
            throw new BadRequestHttpException('Enter the 6-digit code from your authenticator app.');
        }

        // Verifies the code and regenerates the tokens, leaving the app turned on.
        $tokens = $this->toggleTwoFactorService->handle($user, $code, true);

        Activity::event('user:two-factor.recovery-tokens')->log();

        return new JsonResponse([
            'object' => 'recovery_tokens',
            'attributes' => ['tokens' => $tokens],
            'meta' => ['two_factor' => TwoFactorPolicy::status($user->refresh())],
        ]);
    }

    /**
     * Emails a code to confirm turning email codes on or off.
     *
     * @throws \Pterodactyl\Exceptions\DisplayException
     */
    public function sendEmailCode(Request $request): JsonResponse
    {
        $data = $this->validation->make($request->all(), [
            'action' => ['required', 'string', 'in:enable,disable'],
        ])->validate();

        /** @var User $user */
        $user = $request->user();
        if ($data['action'] === 'enable' && $user->email_2fa) {
            throw new BadRequestHttpException('Email codes are already turned on.');
        }
        if ($data['action'] === 'disable' && !$user->email_2fa) {
            throw new BadRequestHttpException('Email codes are not turned on.');
        }

        [$purpose, $reason] = self::EMAIL_PURPOSES[$data['action']];
        $sent = $this->emailCodes->send($user, $purpose, $reason);

        return new JsonResponse([
            'data' => [
                'sent' => $sent,
                'email' => TwoFactorPolicy::maskEmail($user->email),
                'retry_after' => $this->emailCodes->cooldown($user, $purpose),
            ],
        ]);
    }

    /**
     * Turns on email codes once the person enters the code we emailed them.
     */
    public function enableEmail(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        if ($user->email_2fa) {
            throw new BadRequestHttpException('Email codes are already turned on.');
        }

        $this->confirmPassword($user, $request->input('password'));
        $this->checkEmailCode($user, 'enable', $request->input('code'));

        $user->forceFill(['email_2fa' => true])->save();
        Activity::event('user:two-factor.email-create')->log();

        return $this->statusResponse($user);
    }

    /**
     * Turns off email codes.
     */
    public function disableEmail(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        if (!$user->email_2fa) {
            throw new BadRequestHttpException('Email codes are not turned on.');
        }

        $this->confirmPassword($user, $request->input('password'));
        $this->checkEmailCode($user, 'disable', $request->input('code'));

        $user->forceFill(['email_2fa' => false])->save();
        Activity::event('user:two-factor.email-delete')->log();

        return $this->statusResponse($user);
    }

    private function statusResponse(User $user): JsonResponse
    {
        return new JsonResponse(['data' => TwoFactorPolicy::status($user->refresh())]);
    }

    private function checkEmailCode(User $user, string $action, mixed $code): void
    {
        if (!$this->emailCodes->verify($user, self::EMAIL_PURPOSES[$action][0], is_string($code) ? $code : null)) {
            throw new BadRequestHttpException('That code is not right or has expired. Send a new code and try again.');
        }
    }

    /**
     * Accepts a current code from the authenticator app or one of the recovery codes
     * (which is then used up), for people who no longer have their device.
     */
    private function checkAppCode(User $user, mixed $code): void
    {
        $code = preg_replace('/\s+/', '', is_string($code) ? $code : '');

        if (preg_match('/^\d{6}$/', $code) === 1) {
            $secret = $this->encrypter->decrypt($user->totp_secret);
            if ($this->google2FA->verifyKey($secret, $code, config('pterodactyl.auth.2fa.window') ?? 1)) {
                return;
            }
        } elseif ($code !== '') {
            foreach ($user->recoveryTokens as $token) {
                if (password_verify($code, $token->token)) {
                    $token->delete();

                    return;
                }
            }
        }

        throw new BadRequestHttpException('Enter a current code from your authenticator app, or one of your recovery codes.');
    }

    private function cleanAppName(?string $name): ?string
    {
        $name = trim(preg_replace('/[\x00-\x1F\x7F]+/u', '', (string) $name) ?? '');

        return $name === '' ? null : mb_substr($name, 0, 64);
    }
}
