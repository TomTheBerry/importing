<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Models\Announcement;
use Pterodactyl\Services\Users\TwoFactorPolicy;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Banners shown across the top of the Panel.
 */
class AnnouncementController extends ClientApiController
{
    public function index(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        $dismissed = DB::table('announcement_dismissals')->where('user_id', $user->id)->pluck('announcement_id')->all();

        $list = Announcement::query()->live()
            ->whereIn('audience', TwoFactorPolicy::isStaff($user) ? ['everyone', 'staff'] : ['everyone', 'customers'])
            ->orderByRaw("CASE style WHEN 'issue' THEN 0 WHEN 'maintenance' THEN 1 WHEN 'warning' THEN 2 ELSE 3 END")
            ->orderByDesc('id')
            ->get()
            ->reject(fn (Announcement $a) => $a->dismissible && in_array($a->id, $dismissed))
            ->map(fn (Announcement $a) => [
                'id' => $a->id,
                'message' => $a->message,
                'style' => $a->style,
                'dismissible' => $a->dismissible,
                'link_url' => $a->link_url,
                'link_text' => $a->link_text,
            ])->values();

        return new JsonResponse(['data' => $list]);
    }

    public function dismiss(Request $request, int $announcement): JsonResponse
    {
        /** @var Announcement|null $row */
        $row = Announcement::query()->live()->find($announcement);
        if (!$row || !$row->dismissible) {
            throw new NotFoundHttpException();
        }

        DB::table('announcement_dismissals')->updateOrInsert(
            ['user_id' => $request->user()->id, 'announcement_id' => $row->id],
            ['dismissed_at' => now()],
        );

        return new JsonResponse([], 204);
    }
}
