<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Pterodactyl\Models\PrivacyRequest;
use Pterodactyl\Services\Privacy\PrivacyService;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Pterodactyl\Http\Controllers\Api\Client\Concerns\ConfirmsPassword;

/**
 * Account -> Privacy: ask for a copy of your data, or delete your account.
 */
class PrivacyController extends ClientApiController
{
    use ConfirmsPassword;

    public function __construct(private PrivacyService $privacy)
    {
        parent::__construct();
    }

    public function index(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        $export = $this->privacy->latestExport($user);

        return new JsonResponse(['data' => [
            'export' => $export ? [
                'status' => $export->status,
                'requested_at' => $export->created_at->toAtomString(),
                'due_at' => $export->due_at?->toAtomString(),
                'extended' => $export->extended,
                'reason' => $export->status === PrivacyRequest::STATUS_DECLINED || $export->extended ? $export->reason : null,
                'sent_at' => $export->handled_at?->toAtomString(),
                'download_url' => $export->downloadable() ? route('privacy.export.download', $export->uuid) : null,
                'expires_at' => $export->downloadable() ? $export->file_expires_at?->toAtomString() : null,
            ] : null,
            'deletion_days' => PrivacyService::DELETION_DAYS,
            'cannot_delete_reason' => PrivacyService::cannotDeleteReason($user),
        ]]);
    }

    /**
     * Asks for a copy of all personal data held about the account.
     */
    public function export(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        $this->confirmPassword($user, $request->input('password'));

        $this->privacy->requestExport($user);

        return $this->index($request);
    }

    /**
     * Schedules the account for deletion and logs out of this session. Logging in
     * again within the grace period cancels it.
     */
    public function delete(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        $this->confirmPassword($user, $request->input('password'));

        if ($request->input('confirm') !== 'DELETE') {
            throw new BadRequestHttpException('Type DELETE in capitals to confirm.');
        }

        $deletion = $this->privacy->scheduleDeletion($user);

        if ($request->hasSession()) {
            Auth::guard('web')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
        }

        return new JsonResponse(['data' => ['deletion_at' => $deletion->due_at?->toAtomString()]]);
    }
}
