<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Models\UserConnection;
use Pterodactyl\Services\Auth\OAuth\OAuthService;
use Pterodactyl\Services\Auth\OAuth\OAuthException;
use Pterodactyl\Services\Auth\OAuth\OAuthProviders;
use Pterodactyl\Notifications\AccountConnectionChanged;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Pterodactyl\Http\Controllers\Api\Client\Concerns\ConfirmsPassword;

/**
 * Account -> Connections. Connecting or removing an account needs the account password,
 * because a connected account is a way to log in: someone who only has a stolen
 * session must not be able to add their own.
 */
class ConnectionController extends ClientApiController
{
    use ConfirmsPassword;

    public function __construct(private OAuthService $oauth)
    {
        parent::__construct();
    }

    /**
     * Every provider that is set up, with the account connected to each (if any).
     */
    public function index(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        $connections = $user->connections()->get()->keyBy('provider');

        $providers = [];
        foreach (array_keys(OAuthProviders::DEFINITIONS) as $provider) {
            $connection = $connections->get($provider);
            if (!OAuthProviders::enabled($provider) && !$connection) {
                continue;
            }

            $providers[] = [
                'id' => $provider,
                'label' => OAuthProviders::label($provider),
                'available' => OAuthProviders::enabled($provider),
                'connection' => $connection ? $this->present($connection) : null,
            ];
        }

        return new JsonResponse(['data' => $providers]);
    }

    /**
     * Starts connecting an account. Returns the provider URL to send the browser to.
     */
    public function store(Request $request, string $provider): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        $this->assertProvider($provider);
        $this->confirmPassword($user, $request->input('password'));

        if (!$request->hasSession()) {
            throw new BadRequestHttpException('Connections can only be added from the Panel in your browser.');
        }

        if ($user->connections()->where('provider', $provider)->exists()) {
            throw new BadRequestHttpException('You already have a ' . OAuthProviders::label($provider) . ' account connected. Remove it first to connect a different one.');
        }

        try {
            $url = $this->oauth->start($request, $provider, OAuthService::INTENT_LINK, $user);
        } catch (OAuthException) {
            throw new BadRequestHttpException('This provider is not available right now.');
        }

        return new JsonResponse(['data' => ['url' => $url]]);
    }

    /**
     * Removes a connected account so it can no longer be used to log in.
     */
    public function delete(Request $request, string $provider): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        $this->confirmPassword($user, $request->input('password'));

        /** @var UserConnection|null $connection */
        $connection = $user->connections()->where('provider', $provider)->first();
        if (!$connection) {
            throw new NotFoundHttpException('No account from that provider is connected.');
        }

        $connection->delete();

        Activity::event('user:connection.delete')
            ->subject($user)
            ->withRequestMetadata()
            ->property(['provider' => OAuthProviders::label($provider), 'account' => $connection->username])
            ->log();

        $user->notify(new AccountConnectionChanged(OAuthProviders::label($provider), $connection->username, false));

        return $this->index($request);
    }

    private function present(UserConnection $connection): array
    {
        return [
            'username' => $connection->username,
            'email' => $connection->email,
            'created_at' => $connection->created_at->toAtomString(),
            'last_used_at' => $connection->last_used_at?->toAtomString(),
        ];
    }

    private function assertProvider(string $provider): void
    {
        if (!OAuthProviders::enabled($provider)) {
            throw new NotFoundHttpException('That provider is not available.');
        }
    }
}
