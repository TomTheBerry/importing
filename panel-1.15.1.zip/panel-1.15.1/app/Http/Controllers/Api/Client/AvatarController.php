<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Facades\Activity;
use Illuminate\Support\Facades\RateLimiter;
use Pterodactyl\Services\Users\AvatarService;
use Pterodactyl\Http\Requests\Api\Client\Account\UploadAvatarRequest;
use Symfony\Component\HttpKernel\Exception\TooManyRequestsHttpException;

class AvatarController extends ClientApiController
{
    public function __construct(private AvatarService $service)
    {
        parent::__construct();
    }

    /**
     * Uploads a new profile picture for the logged-in user.
     */
    public function store(UploadAvatarRequest $request): JsonResponse
    {
        $user = $request->user();

        if (RateLimiter::tooManyAttempts($key = "user:avatar:{$user->uuid}", 10)) {
            throw new TooManyRequestsHttpException(message: 'You have changed your profile picture too many times. Please wait a few minutes.');
        }
        RateLimiter::hit($key, 600);

        $this->service->store($user, $request->file('avatar'));

        Activity::event('user:account.avatar-changed')->log();

        return new JsonResponse(['avatar_url' => $user->avatarUrl()]);
    }

    /**
     * Removes the logged-in user's profile picture.
     */
    public function delete(Request $request): JsonResponse
    {
        $user = $request->user();
        $this->service->delete($user);

        Activity::event('user:account.avatar-removed')->log();

        return new JsonResponse(['avatar_url' => $user->avatarUrl()]);
    }
}
