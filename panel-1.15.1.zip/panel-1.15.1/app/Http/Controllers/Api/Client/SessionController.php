<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Models\UserSession;
use Pterodactyl\Services\Sessions\SessionService;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Pterodactyl\Http\Controllers\Api\Client\Concerns\ConfirmsPassword;

/**
 * Account -> Security: where you're logged in.
 */
class SessionController extends ClientApiController
{
    use ConfirmsPassword;

    public function __construct(private SessionService $sessions)
    {
        parent::__construct();
    }

    public function index(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        return new JsonResponse(['data' => $this->sessions->active($user)->map(fn (UserSession $s) => [
            'id' => $s->id,
            'device' => $s->device,
            'ip' => $s->ip,
            'current' => $this->sessions->isCurrent($request, $s),
            'last_active_at' => $s->last_active_at->toAtomString(),
            'created_at' => $s->created_at->toAtomString(),
        ])->values()]);
    }

    public function delete(Request $request, int $session): JsonResponse
    {
        /** @var UserSession|null $row */
        $row = $request->user()->sessions()->find($session);
        if (!$row) {
            throw new NotFoundHttpException('That session no longer exists.');
        }
        if ($this->sessions->isCurrent($request, $row)) {
            throw new BadRequestHttpException('Use "Log out" to end the session you are using now.');
        }

        $this->sessions->end($row);
        Activity::event('user:session.ended')->property('device', $row->device)->log();

        return $this->index($request);
    }

    public function deleteOthers(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        $this->confirmPassword($user, $request->input('password'));

        $count = $this->sessions->endOthers($request, $user, (string) $request->input('password'));
        Activity::event('user:session.ended-others')->property('count', $count)->log();

        return $this->index($request);
    }
}
