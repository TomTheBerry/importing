<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Pterodactyl\Models\Location;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Models\Billing\Tier;
use Pterodactyl\Models\Billing\Coupon;
use Pterodactyl\Models\Billing\Invoice;
use Pterodactyl\Models\Billing\Product;
use Pterodactyl\Services\Billing\Money;
use Pterodactyl\Models\Billing\CreditLog;
use Illuminate\Support\Facades\RateLimiter;
use Pterodactyl\Models\Billing\Subscription;
use Pterodactyl\Services\Billing\StripeClient;
use Pterodactyl\Services\Billing\InvoiceService;
use Pterodactyl\Services\Billing\CheckoutService;
use Pterodactyl\Services\Billing\BillingPresenter;
use Pterodactyl\Exceptions\Billing\BillingException;
use Pterodactyl\Services\Billing\SubscriptionService;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\TooManyRequestsHttpException;

/**
 * The customer side of billing. Every lookup is scoped to the logged in user, and
 * every amount is calculated on the server.
 */
class BillingController extends ClientApiController
{
    public function __construct(
        private InvoiceService $invoices,
        private CheckoutService $checkout,
        private SubscriptionService $subscriptions,
    ) {
        parent::__construct();
    }

    public function index(Request $request): JsonResponse
    {
        $this->ensureEnabled();
        $user = $request->user();

        return new JsonResponse([
            'currency' => Money::currency(),
            'payments_enabled' => StripeClient::configured(),
            'credit' => (int) $user->billing_credit,
            'credit_formatted' => Money::format((int) $user->billing_credit),
            'card' => $user->stripe_payment_method ? [
                'brand' => $user->card_brand,
                'last4' => $user->card_last4,
                'expiry' => $user->card_expiry,
            ] : null,
            'unpaid' => Invoice::query()->where('user_id', $user->id)->where('status', Invoice::STATUS_UNPAID)->count(),
            'unpaid_total_formatted' => Money::format((int) Invoice::query()->where('user_id', $user->id)->where('status', Invoice::STATUS_UNPAID)->sum('total')),
            'active_services' => Subscription::query()->where('user_id', $user->id)->whereIn('status', Subscription::LIVE_STATUSES)->count(),
            'timings' => [
                'suspend_after_days' => (int) config('billing.timings.suspend_after_days'),
                'terminate_after_days' => (int) config('billing.timings.terminate_after_days'),
            ],
        ]);
    }

    public function products(): JsonResponse
    {
        $this->ensureEnabled();
        // Fixed plans; the RAM sizes of slider tiers are listed under their tier.
        $products = Product::query()->with('egg')->where('is_active', true)->whereNull('tier_id')
            ->orderBy('category')->orderBy('sort')->orderBy('price')->get();
        $tiers = Tier::query()->with(['egg', 'variants.egg'])->where('is_active', true)
            ->orderBy('category')->orderBy('sort')->orderBy('id')->get()
            ->filter(fn (Tier $t) => $t->variants->contains('is_active', true));
        $locations = Location::query()->get()->keyBy('id')->all();

        return new JsonResponse([
            'data' => $products->map(fn (Product $p) => BillingPresenter::product($p, $locations))->values(),
            'tiers' => $tiers->map(fn (Tier $t) => BillingPresenter::tier($t, $locations))->values(),
        ]);
    }

    /**
     * Previews what a coupon would do, without using it.
     */
    public function checkCoupon(Request $request): JsonResponse
    {
        $this->ensureEnabled();
        $data = $request->validate(['code' => 'required|string|max:64', 'product' => 'required|string|size:36']);
        $this->throttle($request, 'coupon', 10);

        $product = Product::query()->where('uuid', $data['product'])->where('is_active', true)->firstOrFail();
        $coupon = Coupon::query()->where('code', mb_strtoupper(trim($data['code'])))->first();

        if (!$coupon || ($problem = $coupon->problemFor($product))) {
            throw new BillingException($problem ?? 'That coupon code is not valid.');
        }
        if ($coupon->usedBy($request->user())) {
            throw new BillingException('You have already used that coupon.');
        }

        $discount = $coupon->discountFor($product->price);

        return new JsonResponse([
            'code' => $coupon->code,
            'label' => $coupon->label(),
            'discount_formatted' => Money::format($discount),
            'first_payment_formatted' => Money::format($product->price - $discount + $product->setup_fee),
        ]);
    }

    /**
     * Places an order and returns where to pay for it.
     */
    public function order(Request $request): JsonResponse
    {
        $this->ensureEnabled();
        $data = $request->validate([
            'product' => 'required|string|size:36',
            'name' => ['required', 'string', 'between:1,191', 'not_regex:/[<>]/'],
            'location' => 'required|integer',
            'coupon' => 'nullable|string|max:64',
            'use_credit' => 'boolean',
            // UK consumer law: they ask for the server to start within their 14-day
            // cancellation period, so a refund on cancelling takes off the time used.
            'start_now' => 'accepted',
        ], ['start_now.accepted' => 'Please tick the box to confirm your server can start straight away.']);
        $this->throttle($request, 'order', 5);

        $user = $request->user();
        if (!$user->hasVerifiedEmail()) {
            throw new BillingException('Please verify your email address before buying a server. You can send a new verification email from your account page.');
        }
        if (Subscription::query()->where('user_id', $user->id)->where('status', Subscription::STATUS_PENDING)->count() >= 3) {
            throw new BillingException('You have too many unpaid orders. Please pay or wait for them to expire first.');
        }

        $product = Product::query()->where('uuid', $data['product'])->firstOrFail();
        $coupon = null;
        if (!empty($data['coupon'])) {
            $coupon = Coupon::query()->where('code', mb_strtoupper(trim($data['coupon'])))->first();
            if (!$coupon) {
                throw new BillingException('That coupon code is not valid.');
            }
        }

        $invoice = $this->invoices->createOrder($user, $product, trim($data['name']), (int) $data['location'], $coupon);
        $invoice->subscription?->forceFill(['start_now_consent_at' => now()])->save();

        Activity::event('billing:order.create')->property(['plan' => $product->name, 'invoice' => $invoice->displayNumber()])->log();

        $url = $this->checkout->payInvoice($invoice, (bool) ($data['use_credit'] ?? true));

        return new JsonResponse(['invoice' => $invoice->uuid, 'checkout_url' => $url, 'paid' => is_null($url)]);
    }

    public function services(Request $request): JsonResponse
    {
        $this->ensureEnabled();
        $services = Subscription::query()
            ->with(['product', 'scheduledProduct', 'server'])
            ->where('user_id', $request->user()->id)
            ->whereIn('status', array_merge(Subscription::LIVE_STATUSES, [Subscription::STATUS_PENDING]))
            ->orderByDesc('id')
            ->get();

        return new JsonResponse(['data' => $services->map(fn ($s) => BillingPresenter::subscription($s))->values()]);
    }

    public function service(Request $request, string $service): JsonResponse
    {
        return new JsonResponse(BillingPresenter::subscription($this->findService($request, $service), true));
    }

    public function cancel(Request $request, string $service): JsonResponse
    {
        $this->throttle($request, 'service', 10);
        $subscription = $this->findService($request, $service);
        $this->subscriptions->cancel($subscription);
        Activity::event('billing:service.cancel')->property('service', $subscription->name)->log();

        return new JsonResponse(BillingPresenter::subscription($subscription->refresh(), true));
    }

    public function resume(Request $request, string $service): JsonResponse
    {
        $this->throttle($request, 'service', 10);
        $subscription = $this->findService($request, $service);
        $this->subscriptions->resume($subscription);
        Activity::event('billing:service.resume')->property('service', $subscription->name)->log();

        return new JsonResponse(BillingPresenter::subscription($subscription->refresh(), true));
    }

    public function changePlan(Request $request, string $service): JsonResponse
    {
        $data = $request->validate(['product' => 'required|string|size:36']);
        $this->throttle($request, 'change-plan', 5);

        $subscription = $this->findService($request, $service);
        $target = Product::query()->where('uuid', $data['product'])->firstOrFail();
        $invoice = $this->subscriptions->changePlan($subscription, $target);

        Activity::event('billing:service.change-plan')->property(['service' => $subscription->name, 'plan' => $target->name])->log();

        $url = $invoice && $invoice->isUnpaid() ? $this->checkout->payInvoice($invoice) : null;

        return new JsonResponse([
            'scheduled' => is_null($invoice),
            'invoice' => $invoice?->uuid,
            'checkout_url' => $url,
            'service' => BillingPresenter::subscription($subscription->refresh(), true),
        ]);
    }

    public function cancelPlanChange(Request $request, string $service): JsonResponse
    {
        $this->throttle($request, 'service', 10);
        $subscription = $this->findService($request, $service);
        $this->subscriptions->cancelScheduledChange($subscription);

        return new JsonResponse(BillingPresenter::subscription($subscription->refresh(), true));
    }

    public function invoices(Request $request): JsonResponse
    {
        $this->ensureEnabled();
        $invoices = Invoice::query()->with('subscription')->where('user_id', $request->user()->id)
            ->where('status', '!=', Invoice::STATUS_VOID)
            ->orderByDesc('id')
            ->paginate(25);

        return new JsonResponse([
            'data' => collect($invoices->items())->map(fn ($i) => BillingPresenter::invoice($i))->values(),
            'pagination' => ['current_page' => $invoices->currentPage(), 'total_pages' => $invoices->lastPage(), 'total' => $invoices->total()],
        ]);
    }

    public function invoice(Request $request, string $invoice): JsonResponse
    {
        return new JsonResponse(BillingPresenter::invoice($this->findInvoice($request, $invoice)->load(['items', 'payments', 'subscription']), true));
    }

    public function pay(Request $request, string $invoice): JsonResponse
    {
        $data = $request->validate(['use_credit' => 'boolean']);
        $this->throttle($request, 'pay', 10);

        $model = $this->findInvoice($request, $invoice);
        $url = $this->checkout->payInvoice($model, (bool) ($data['use_credit'] ?? true));

        return new JsonResponse(['checkout_url' => $url, 'paid' => is_null($url)]);
    }

    public function updateCard(Request $request): JsonResponse
    {
        $this->ensureEnabled();
        $this->throttle($request, 'card', 5);

        return new JsonResponse(['url' => $this->checkout->updateCard($request->user())]);
    }

    public function removeCard(Request $request): JsonResponse
    {
        $this->ensureEnabled();
        $this->throttle($request, 'card', 5);
        $this->checkout->removeCard($request->user());
        Activity::event('billing:card.remove')->log();

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }

    public function creditLog(Request $request): JsonResponse
    {
        $this->ensureEnabled();
        $logs = CreditLog::query()->where('user_id', $request->user()->id)->orderByDesc('id')->limit(50)->get();

        return new JsonResponse(['data' => $logs->map(fn (CreditLog $l) => [
            'amount_formatted' => Money::format($l->amount),
            'positive' => $l->amount > 0,
            'balance_formatted' => Money::format($l->balance_after),
            'reason' => $l->reason,
            'created_at' => $l->created_at->toAtomString(),
        ])]);
    }

    protected function findService(Request $request, string $uuid): Subscription
    {
        $this->ensureEnabled();

        /** @var Subscription|null $subscription */
        $subscription = Subscription::query()->with(['product', 'scheduledProduct', 'server'])
            ->where('uuid', $uuid)->where('user_id', $request->user()->id)->first();

        return $subscription ?? throw new NotFoundHttpException('That service could not be found.');
    }

    protected function findInvoice(Request $request, string $uuid): Invoice
    {
        $this->ensureEnabled();

        /** @var Invoice|null $invoice */
        $invoice = Invoice::query()->where('uuid', $uuid)->where('user_id', $request->user()->id)->first();

        return $invoice ?? throw new NotFoundHttpException('That invoice could not be found.');
    }

    protected function ensureEnabled(): void
    {
        if (!config('billing.enabled')) {
            throw new NotFoundHttpException('Billing is not enabled.');
        }
    }

    protected function throttle(Request $request, string $action, int $perMinute): void
    {
        $key = "billing:$action:" . $request->user()->id;
        if (RateLimiter::tooManyAttempts($key, $perMinute)) {
            throw new TooManyRequestsHttpException(RateLimiter::availableIn($key), 'Please slow down and try again in a moment.');
        }
        RateLimiter::hit($key, 60);
    }
}
