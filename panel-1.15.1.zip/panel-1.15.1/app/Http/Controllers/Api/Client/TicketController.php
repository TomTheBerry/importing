<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Server;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\Support\Ticket;
use Pterodactyl\Models\Support\TicketCategory;
use Pterodactyl\Services\Support\TicketService;
use Pterodactyl\Services\Support\TicketPresenter;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * The customer's Support pages.
 */
class TicketController extends ClientApiController
{
    public function __construct(private TicketService $service)
    {
        parent::__construct();
    }

    /**
     * The Support pages don't exist when tickets are turned off (TICKETS_ENABLED=false).
     */
    public function callAction($method, $parameters)
    {
        if (!config('tickets.enabled', true)) {
            throw new NotFoundHttpException();
        }

        return parent::callAction($method, $parameters);
    }

    public function index(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $tickets = Ticket::query()->with(['category', 'server', 'assignee'])
            ->where('user_id', $user->id)
            ->orderByRaw("CASE status WHEN 'answered' THEN 0 WHEN 'open' THEN 1 ELSE 2 END")
            ->orderByDesc('last_message_at')
            ->limit(200)
            ->get();

        $servers = Server::query()
            ->where(fn ($q) => $q->where('owner_id', $user->id)->orWhereHas('subusers', fn ($s) => $s->where('user_id', $user->id)))
            ->orderBy('name')->limit(100)->get(['id', 'uuid', 'uuidShort', 'name']);

        return new JsonResponse([
            'data' => $tickets->map(fn (Ticket $t) => TicketPresenter::summary($t))->values(),
            'categories' => TicketCategory::query()->where('is_active', true)->orderBy('sort')->orderBy('id')->get()
                ->map(fn (TicketCategory $c) => TicketPresenter::category($c))->values(),
            'servers' => $servers->map(fn (Server $s) => ['id' => $s->id, 'uuid' => $s->uuidShort, 'name' => $s->name])->values(),
            'limits' => [
                'max_open' => $this->service->maxOpen(),
                'max_files' => (int) config('tickets.attachments.max_files', 5),
                'max_file_mb' => round((int) config('tickets.attachments.max_kb', 8192) / 1024),
                'extensions' => array_values(config('tickets.attachments.extensions', [])),
                'auto_close_days' => $this->service->autoCloseDays(),
            ],
            'discord_linked' => \Pterodactyl\Services\Support\DiscordBridge::discordIdFor($user) !== null,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'category_id' => 'nullable|integer',
            'server_id' => 'nullable|integer',
            'subject' => 'required|string|min:3|max:120',
            'message' => 'required|string|min:5|max:10000',
            'files' => 'nullable|array',
            'files.*' => 'file',
        ]);

        $ticket = $this->service->openFromPanel($request->user(), [
            'category_id' => $data['category_id'] ?? null,
            'server_id' => $data['server_id'] ?? null,
            'subject' => trim($data['subject']),
            'message' => trim($data['message']),
        ], $request->file('files', []));

        return new JsonResponse(['data' => TicketPresenter::summary($ticket)], 201);
    }

    public function show(Request $request, string $ticket): JsonResponse
    {
        $model = $this->find($request, $ticket);
        $messages = $model->messages()->with(['user.adminRole', 'attachments'])->where('internal', false)->get();

        return new JsonResponse([
            'data' => TicketPresenter::summary($model),
            'messages' => $messages->map(fn ($m) => TicketPresenter::message($m))->values(),
        ]);
    }

    public function reply(Request $request, string $ticket): JsonResponse
    {
        $model = $this->find($request, $ticket);
        $data = $request->validate([
            'message' => 'required_without:files|nullable|string|max:10000',
            'files' => 'nullable|array',
            'files.*' => 'file',
        ]);

        $message = $this->service->replyFromPanel($model, $request->user(), false, trim((string) ($data['message'] ?? '')), $request->file('files', []));

        return new JsonResponse(['data' => TicketPresenter::message($message)], 201);
    }

    public function close(Request $request, string $ticket): JsonResponse
    {
        $model = $this->find($request, $ticket);
        $this->service->close($model, $request->user());

        return new JsonResponse(['data' => TicketPresenter::summary($model->refresh())]);
    }

    public function reopen(Request $request, string $ticket): JsonResponse
    {
        $model = $this->find($request, $ticket);
        $this->service->reopen($model, $request->user(), false);

        return new JsonResponse(['data' => TicketPresenter::summary($model->refresh())]);
    }

    private function find(Request $request, string $uuid): Ticket
    {
        /** @var Ticket|null $ticket */
        $ticket = Ticket::query()->with(['category', 'server', 'assignee', 'user'])
            ->where('uuid', $uuid)
            ->where('user_id', $request->user()->id)
            ->first();

        if (!$ticket) {
            throw new NotFoundHttpException();
        }

        return $ticket;
    }
}
