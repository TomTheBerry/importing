<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Services\Legal\LegalService;

/**
 * Accepting the latest Terms of Service, Privacy Policy and Acceptable Use Policy.
 */
class LegalController extends ClientApiController
{
    public function __construct(private LegalService $legal)
    {
        parent::__construct();
    }

    public function index(Request $request): JsonResponse
    {
        $current = $this->legal->current();
        $user = $request->user();

        return new JsonResponse(['data' => [
            'version' => $current?->version,
            'summary' => $current?->summary,
            'published_at' => $current?->published_at->toAtomString(),
            'accepted_version' => $user->legal_version,
            'accepted_at' => $user->legal_accepted_at?->toAtomString(),
            'needs_acceptance' => $this->legal->needsAcceptance($user),
            'links' => LegalService::LINKS,
        ]]);
    }

    public function accept(Request $request): JsonResponse
    {
        $data = $request->validate([
            'version' => 'required|string|max:32',
            'agree' => 'accepted',
        ], ['agree.accepted' => 'Please tick the box to confirm you agree.']);

        $this->legal->accept($request->user(), $data['version'], $request);

        return $this->index($request);
    }
}
