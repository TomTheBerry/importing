<?php

namespace Pterodactyl\Http\Controllers\Api\Discord;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use Pterodactyl\Models\Support\Ticket;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Support\TicketCategory;
use Pterodactyl\Services\Support\DiscordBridge;
use Pterodactyl\Services\Support\TicketService;
use Pterodactyl\Models\Support\TicketAttachment;
use Pterodactyl\Models\Support\DiscordOutboxItem;
use Pterodactyl\Services\Support\DiscordRoleService;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Pterodactyl\Services\Support\TicketAttachmentService;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * The API the BerryHost Discord bot uses. Every request is checked by
 * AuthenticateDiscordBot first.
 */
class BotController extends Controller
{
    public const LAST_POLL_KEY = 'discord-bot:last-poll';

    public function __construct(
        private TicketService $tickets,
        private DiscordBridge $bridge,
        private TicketAttachmentService $attachments,
    ) {
    }

    public function config(): JsonResponse
    {
        return new JsonResponse([
            'app_name' => config('app.name'),
            'panel_url' => rtrim((string) config('app.url'), '/'),
            'categories' => TicketCategory::query()->where('is_active', true)->orderBy('sort')->orderBy('id')->limit(25)->get()
                ->map(fn (TicketCategory $c) => ['id' => $c->id, 'name' => $c->name, 'description' => $c->description, 'emoji' => $c->emoji])
                ->values(),
            // The bot asks Discord for member join events only when it has roles to give.
            'role_sync' => DiscordRoleService::enabled(),
            'limits' => [
                'max_files' => (int) config('tickets.attachments.max_files', 5),
                'max_kb' => (int) config('tickets.attachments.max_kb', 8192),
                'extensions' => array_values(config('tickets.attachments.extensions', [])),
            ],
        ]);
    }

    /**
     * Jobs waiting for the bot. The ticket details are always sent as they are now (not
     * as they were when the job was queued), so the bot knows the latest channel.
     */
    public function outbox(Request $request): JsonResponse
    {
        Cache::put(self::LAST_POLL_KEY, now()->toAtomString(), now()->addDay());

        $items = DiscordOutboxItem::query()
            ->with(['ticket.user', 'ticket.category', 'ticket.assignee', 'ticket.server'])
            ->whereNull('delivered_at')
            ->where(fn ($q) => $q->whereNull('available_at')->orWhere('available_at', '<=', now()))
            ->orderBy('id')
            ->limit(min(50, max(1, (int) $request->query('limit', 20))))
            ->get();

        return new JsonResponse([
            'data' => $items->map(fn (DiscordOutboxItem $item) => [
                'id' => $item->id,
                'type' => $item->type,
                'attempts' => $item->attempts,
                'payload' => $this->payloadFor($item),
            ])->values(),
        ]);
    }

    public function ack(Request $request, int $item): JsonResponse
    {
        $data = $request->validate(['ok' => 'required|boolean', 'error' => 'nullable|string|max:500', 'retry' => 'nullable|boolean']);

        /** @var DiscordOutboxItem|null $row */
        $row = DiscordOutboxItem::query()->whereNull('delivered_at')->find($item);
        if (!$row) {
            return new JsonResponse([], 204);
        }

        if ($data['ok']) {
            $row->forceFill(['delivered_at' => now(), 'last_error' => null])->save();
        } else {
            $attempts = $row->attempts + 1;
            $giveUp = $attempts >= DiscordOutboxItem::MAX_ATTEMPTS || ($data['retry'] ?? true) === false;
            $row->forceFill([
                'attempts' => $attempts,
                'last_error' => mb_substr((string) ($data['error'] ?? 'Failed'), 0, 191),
                // Wait longer after each failure: 10s, 20s, 40s... up to 30 minutes.
                'available_at' => now()->addSeconds(min(1800, 10 * (2 ** ($attempts - 1)))),
                'delivered_at' => $giveUp ? now() : null,
            ])->save();
        }

        return new JsonResponse([], 204);
    }

    /**
     * Someone filled in the "open a ticket" form in Discord.
     */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'author' => 'required|array',
            'author.id' => 'required|string|regex:/^\d{5,25}$/',
            'author.name' => 'required|string|max:100',
            'author.avatar' => 'nullable|string|max:255',
            'category_id' => 'nullable|integer',
            'subject' => 'required|string|min:3|max:120',
            'message' => 'required|string|min:5|max:4000',
        ]);

        try {
            $ticket = $this->tickets->openFromDiscord($this->author($data['author']), [
                'category_id' => $data['category_id'] ?? null,
                'subject' => trim($data['subject']),
                'message' => trim($data['message']),
            ]);
        } catch (DisplayException $exception) {
            return $this->refuse($exception);
        }

        return new JsonResponse(['data' => $this->bridge->ticketPayload($ticket)], 201);
    }

    public function setChannel(Request $request, string $ticket): JsonResponse
    {
        $data = $request->validate(['channel_id' => 'required|string|regex:/^\d{5,25}$/']);
        $model = $this->find($ticket);

        $model->forceFill(['discord_channel_id' => $data['channel_id']])->save();

        return new JsonResponse(['data' => $this->bridge->ticketPayload($model)]);
    }

    public function byChannel(string $channel): JsonResponse
    {
        /** @var Ticket|null $ticket */
        $ticket = Ticket::query()->with(['user', 'category', 'assignee', 'server'])
            ->where('discord_channel_id', $channel)
            ->where('status', '!=', Ticket::STATUS_CLOSED)
            ->first();
        if (!$ticket) {
            throw new NotFoundHttpException();
        }

        return new JsonResponse(['data' => $this->bridge->ticketPayload($ticket)]);
    }

    /**
     * A message sent in a ticket channel. Sent as multipart so files can come with it.
     */
    public function message(Request $request, string $ticket): JsonResponse
    {
        $data = $request->validate([
            'author' => 'required|array',
            'author.id' => 'required|string|regex:/^\d{5,25}$/',
            'author.name' => 'required|string|max:100',
            'author.avatar' => 'nullable|string|max:255',
            'author.staff' => 'nullable|boolean',
            'message_id' => 'required|string|regex:/^\d{5,25}$/',
            'body' => 'nullable|string|max:4000',
            'files' => 'nullable|array',
            'files.*' => 'file',
        ]);
        $model = $this->find($ticket);

        try {
            $message = $this->tickets->replyFromDiscord($model, $this->author($data['author']), trim((string) ($data['body'] ?? '')), $request->file('files', []), $data['message_id']);
        } catch (DisplayException $exception) {
            return $this->refuse($exception);
        }

        return new JsonResponse(['data' => ['id' => $message->id, 'type' => $message->author_type, 'status' => $model->refresh()->status]], 201);
    }

    public function close(Request $request, string $ticket): JsonResponse
    {
        $data = $request->validate([
            'author' => 'required|array',
            'author.id' => 'required|string|regex:/^\d{5,25}$/',
            'author.name' => 'required|string|max:100',
            'author.staff' => 'nullable|boolean',
            'reason' => 'nullable|string|max:191',
        ]);
        $model = $this->find($ticket);

        try {
            [, $user] = $this->tickets->discordAuthor($model, $this->author($data['author']));
            $this->tickets->close($model, $user, $data['reason'] ?? null, $user ? null : $data['author']['name']);
        } catch (DisplayException $exception) {
            return $this->refuse($exception);
        }

        return new JsonResponse(['data' => $this->bridge->ticketPayload($model->refresh())]);
    }

    /**
     * A staff member in Discord taking the ticket. They need a linked Panel account so
     * the ticket can be assigned to them.
     */
    public function claim(Request $request, string $ticket): JsonResponse
    {
        $data = $request->validate(['author' => 'required|array', 'author.id' => 'required|string|regex:/^\d{5,25}$/']);
        $model = $this->find($ticket);

        $user = DiscordBridge::userForDiscordId($data['author']['id']);
        if (!$user || !DiscordBridge::isStaff($user)) {
            return new JsonResponse(['error' => 'Link your Discord account to your staff account on the Panel (Account → Connections) to claim tickets.'], 422);
        }

        try {
            $this->tickets->assign($model, $user, $user);
        } catch (DisplayException $exception) {
            return $this->refuse($exception);
        }

        return new JsonResponse(['data' => $this->bridge->ticketPayload($model->refresh())]);
    }

    public function attachment(string $attachment): StreamedResponse
    {
        /** @var TicketAttachment|null $file */
        $file = TicketAttachment::query()->with('message')->where('uuid', $attachment)->first();
        // Files on internal notes never go to Discord.
        if (!$file || !$file->message || $file->message->internal) {
            throw new NotFoundHttpException();
        }

        return $this->attachments->download($file);
    }

    /**
     * Health check shown on the bot's console when it starts.
     */
    private function payloadFor(DiscordOutboxItem $item): array
    {
        if ($item->type === DiscordRoleService::OUTBOX_SYNC_ROLES) {
            return DiscordRoleService::payloadFor((string) ($item->payload['discord_id'] ?? ''));
        }

        return array_merge($item->payload ?? [], $item->ticket ? ['ticket' => $this->bridge->ticketPayload($item->ticket)] : []);
    }

    /**
     * The roles someone should have, for when they join the Discord server.
     */
    public function roles(string $member): JsonResponse
    {
        return new JsonResponse(['data' => DiscordRoleService::payloadFor($member)]);
    }

    public function ping(): JsonResponse
    {
        return new JsonResponse(['ok' => true, 'pending' => DiscordOutboxItem::query()->whereNull('delivered_at')->count(), 'time' => now()->toAtomString()]);
    }

    private function author(array $author): array
    {
        $avatar = $author['avatar'] ?? null;
        // Only keep Discord's own picture links.
        if (!is_string($avatar) || !str_starts_with($avatar, 'https://cdn.discordapp.com/')) {
            $avatar = null;
        }

        return [
            'id' => (string) $author['id'],
            'name' => trim((string) $author['name']) !== '' ? trim((string) $author['name']) : 'Discord user',
            'avatar' => $avatar,
            'staff' => (bool) ($author['staff'] ?? false),
        ];
    }

    private function find(string $uuid): Ticket
    {
        /** @var Ticket|null $ticket */
        $ticket = Ticket::query()->with(['user', 'category', 'assignee', 'server'])->where('uuid', $uuid)->first();
        if (!$ticket) {
            throw new NotFoundHttpException();
        }

        return $ticket;
    }

    private function refuse(DisplayException $exception): JsonResponse
    {
        return new JsonResponse(['error' => $exception->getMessage()], 422);
    }

    /**
     * Admin overview: when the bot last checked in and how many jobs are waiting.
     *
     * @return array{online: bool, last_poll: string|null, pending: int, failed: int}
     */
    public static function status(): array
    {
        $last = Cache::get(self::LAST_POLL_KEY);
        $failed = DB::table('discord_outbox')->whereNotNull('delivered_at')->whereNotNull('last_error')
            ->where('created_at', '>', now()->subDay())->count();

        return [
            'online' => $last !== null && now()->diffInSeconds(\Carbon\CarbonImmutable::parse($last), true) < 60,
            'last_poll' => $last,
            'pending' => DiscordOutboxItem::query()->whereNull('delivered_at')->count(),
            'failed' => $failed,
        ];
    }
}
