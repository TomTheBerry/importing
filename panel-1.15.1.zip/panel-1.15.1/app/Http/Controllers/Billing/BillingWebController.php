<?php

namespace Pterodactyl\Http\Controllers\Billing;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Models\Billing\Invoice;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Billing\InvoicePdf;
use Pterodactyl\Services\Billing\CheckoutService;
use Pterodactyl\Exceptions\Billing\BillingException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class BillingWebController extends Controller
{
    public function __construct(private CheckoutService $checkout)
    {
    }

    /**
     * Stripe sends the customer here after paying. The payment is confirmed directly
     * with Stripe (the webhook does the same, whichever arrives first wins).
     */
    public function return(Request $request): RedirectResponse
    {
        $sessionId = (string) $request->query('session_id', '');

        try {
            $invoice = $this->checkout->completeSession($sessionId, $request->user());
        } catch (BillingException) {
            return redirect()->to('/billing?payment=pending');
        }

        if ($invoice) {
            return redirect()->to('/billing/invoices/' . $invoice->uuid . '?payment=success');
        }

        return redirect()->to('/billing/payment-methods?card=updated');
    }

    /**
     * Downloads an invoice or receipt as a PDF. Customers can only download their own;
     * staff with billing.read can download any.
     */
    public function pdf(Request $request, string $uuid): Response
    {
        /** @var Invoice|null $invoice */
        $invoice = Invoice::query()->where('uuid', $uuid)->first();
        $user = $request->user();

        if (!$invoice || ($invoice->user_id !== $user->id && !$user->hasAdminPermission('billing.read'))) {
            throw new NotFoundHttpException();
        }

        $name = ($invoice->status === Invoice::STATUS_PAID ? 'receipt-' : 'invoice-') . preg_replace('/[^A-Za-z0-9-]/', '', $invoice->displayNumber()) . '.pdf';

        return response((new InvoicePdf())->render($invoice), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="' . $name . '"',
            'X-Content-Type-Options' => 'nosniff',
            'Cache-Control' => 'private, no-store',
        ]);
    }
}
