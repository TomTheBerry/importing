<?php

namespace Pterodactyl\Http\Controllers\Billing;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Billing\StripeClient;
use Pterodactyl\Services\Billing\RefundService;
use Pterodactyl\Services\Billing\CheckoutService;
use Pterodactyl\Exceptions\Billing\BillingException;

/**
 * Receives events from Stripe. Every request must carry a valid signature made with
 * STRIPE_WEBHOOK_SECRET, otherwise it is rejected before anything is read.
 */
class StripeWebhookController extends Controller
{
    public function __construct(private CheckoutService $checkout, private RefundService $refunds)
    {
    }

    public function __invoke(Request $request): JsonResponse
    {
        try {
            $event = StripeClient::verifyWebhook($request->getContent(), $request->header('Stripe-Signature'));
        } catch (BillingException $exception) {
            Log::warning('Billing: rejected Stripe webhook: ' . $exception->getMessage(), ['ip' => $request->ip()]);

            return new JsonResponse(['error' => 'invalid signature'], 400);
        }

        $object = $event['data']['object'];

        try {
            switch ($event['type']) {
                case 'checkout.session.completed':
                case 'checkout.session.async_payment_succeeded':
                    // Re-fetch from Stripe rather than trusting the event body.
                    $this->checkout->completeSession((string) ($object['id'] ?? ''));
                    break;
                case 'payment_intent.succeeded':
                    // Re-fetched from Stripe. Catches card charges whose reply never arrived.
                    if (!empty($object['metadata']['invoice_uuid'])) {
                        $this->checkout->completePaymentIntent((string) ($object['id'] ?? ''));
                    }
                    break;
                case 'charge.refunded':
                    $this->recordRefund($object);
                    break;
            }
        } catch (BillingException $exception) {
            Log::warning('Billing: could not process Stripe event', ['type' => $event['type'], 'error' => $exception->getMessage()]);
        }

        return new JsonResponse(['received' => true]);
    }

    /**
     * Keeps refunds made directly in the Stripe dashboard in sync.
     */
    protected function recordRefund(array $charge): void
    {
        $intent = $charge['payment_intent'] ?? null;
        if (is_string($intent) && preg_match('/^pi_[A-Za-z0-9_]+$/', $intent)) {
            $this->refunds->syncRefundedTotal($intent, (int) ($charge['amount_refunded'] ?? 0));
        }
    }
}
