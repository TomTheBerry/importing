<?php

namespace Pterodactyl\Http\Middleware\Account;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Services\Sessions\SessionService;
use Pterodactyl\Services\Sessions\ImpersonationService;

/**
 * Keeps the list of where each account is logged in up to date, and ends staff
 * "view as user" sessions once their time limit has passed.
 */
class TrackUserSession
{
    public function __construct(private SessionService $sessions, private ImpersonationService $impersonation)
    {
    }

    public function handle(Request $request, \Closure $next): mixed
    {
        if (ImpersonationService::expired($request)) {
            $this->impersonation->stop($request, true);

            return $request->expectsJson() || $request->is('api/*')
                ? response()->json(['errors' => [['code' => 'ImpersonationEnded', 'status' => '409', 'detail' => 'Your support session has ended.']]], 409)
                : redirect()->to('/admin/users');
        }

        // Tracked before the request is handled so "where you're logged in" always
        // includes the browser asking, and again afterwards if logging in changed the
        // session or the person.
        $before = $this->current($request);
        if ($before) {
            $this->sessions->track($request, $before[0]);
        }

        $response = $next($request);

        $after = $this->current($request);
        if ($after && $after !== $before) {
            $this->sessions->track($request, $after[0]);
        }

        return $response;
    }

    /**
     * @return array{0: User, 1: string}|null
     */
    private function current(Request $request): ?array
    {
        if (!$request->hasSession() || !$request->session()->isStarted()) {
            return null;
        }

        $user = $request->user();

        return $user instanceof User ? [$user, $request->session()->getId()] : null;
    }
}
