<?php

namespace Pterodactyl\Http\Middleware\Account;

use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Services\Sessions\ImpersonationService;

/**
 * Pauses accounts that didn't verify their email in time. Until they do, the only
 * things that work are the "verify your email" page, resending the email, changing
 * the email address, the terms page and logging out.
 */
class RequireVerifiedEmail
{
    /**
     * Routes that keep working while the account is paused.
     */
    public const ALLOWED_ROUTES = [
        'verify.required',
        'avatar',
        'avatar.staff',
        'impersonate.stop',
        'api:client.account',
        'api:client.account.update-email',
        'api:client.account.verify-email',
        'api:client.account.legal',
        'api:client.account.legal.accept',
    ];

    public function handle(Request $request, \Closure $next): mixed
    {
        $user = $request->user();
        $route = $request->route();

        if (!$user instanceof User || !$route || !$user->mustVerifyEmailNow()
            || ImpersonationService::active($request) || $request->is('api/application/*')) {
            return $next($request);
        }

        $name = (string) $route->getName();
        if (str_starts_with($name, 'auth.') || str_starts_with($name, 'legal.') || in_array($name, self::ALLOWED_ROUTES, true)) {
            return $next($request);
        }

        if ($request->expectsJson() || $request->is('api/*')) {
            return new JsonResponse(['errors' => [[
                'code' => 'EmailVerificationRequired',
                'status' => '403',
                'detail' => 'Please verify your email address to keep using your account.',
            ]]], 403);
        }

        return redirect()->route('verify.required');
    }
}
