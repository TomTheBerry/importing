<?php

namespace Pterodactyl\Http\Middleware\Account;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Services\Legal\LegalService;
use Pterodactyl\Services\Sessions\ImpersonationService;
use Pterodactyl\Http\Middleware\RequireTwoFactorAuthentication;

/**
 * Sends anyone who hasn't accepted the latest Terms, Privacy Policy and Acceptable Use
 * Policy to accept them before they can use the Panel.
 */
class RequireLegalAcceptance
{
    public function __construct(private LegalService $legal)
    {
    }

    public function handle(Request $request, \Closure $next): mixed
    {
        $user = $request->user();
        $route = $request->route();

        // Server-to-server integrations using Application API keys aren't people agreeing to terms.
        if (!$user || !$route || ImpersonationService::active($request) || $request->is('api/application/*')) {
            return $next($request);
        }

        // Pages needed to log out, set up two-step verification or accept the terms.
        $name = (string) $route->getName();
        if (str_starts_with($name, 'auth.') || str_starts_with($name, 'legal.')
            || in_array(RequireTwoFactorAuthentication::class, $route->excludedMiddleware(), true)) {
            return $next($request);
        }

        if (!$this->legal->needsAcceptance($user)) {
            return $next($request);
        }

        if ($request->expectsJson() || $request->is('api/*')) {
            return new JsonResponse(['errors' => [[
                'code' => 'LegalAcceptanceRequired',
                'status' => '403',
                'detail' => 'Please read and accept the latest Terms of Service, Privacy Policy and Acceptable Use Policy to continue.',
            ]]], 403);
        }

        return redirect()->to('/legal/accept');
    }
}
