<?php

namespace Pterodactyl\Http\Middleware\Account;

use Illuminate\Http\Request;
use Pterodactyl\Services\Sessions\ImpersonationService;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * Sensitive account changes (password, email, two-step, payments, data requests and so
 * on) can only be made by the account owner, never by staff viewing as them.
 */
class BlockDuringImpersonation
{
    public function handle(Request $request, \Closure $next): mixed
    {
        if (ImpersonationService::active($request)) {
            throw new AccessDeniedHttpException('This can\'t be done while viewing the Panel as another user.');
        }

        return $next($request);
    }
}
