<?php

namespace Pterodactyl\Http\Middleware;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class AdminAuthenticate
{
    /**
     * Admin routes that any member of staff with admin access may view, regardless
     * of which permissions their role holds.
     */
    protected array $openRoutes = [
        'admin.index',
    ];

    /**
     * Handle an incoming request.
     *
     * Root administrators always pass. Staff members must have a role granting at
     * least one admin panel permission, and the route they are requesting must
     * explicitly declare which permission it requires using the "admin.can"
     * middleware. Any admin route that does not declare a permission is treated
     * as root-admin only, so newly added routes are locked down by default.
     *
     * @throws AccessDeniedHttpException
     */
    public function handle(Request $request, \Closure $next): mixed
    {
        /** @var \Pterodactyl\Models\User|null $user */
        $user = $request->user();
        if (!$user || !$user->hasAdminAccess()) {
            throw new AccessDeniedHttpException();
        }

        if ($user->root_admin) {
            return $next($request);
        }

        $route = $request->route();
        if ($route && in_array($route->getName(), $this->openRoutes, true)) {
            return $next($request);
        }

        $declared = $route ? collect($route->gatherMiddleware())->contains(function ($middleware) {
            return is_string($middleware) && Str::startsWith($middleware, RequireAdminPermission::ALIAS . ':');
        }) : false;

        if (!$declared) {
            throw new AccessDeniedHttpException('This page is only available to root administrators.');
        }

        return $next($request);
    }
}
