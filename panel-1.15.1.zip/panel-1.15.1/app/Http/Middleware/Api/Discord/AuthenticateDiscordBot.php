<?php

namespace Pterodactyl\Http\Middleware\Api\Discord;

use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\IpUtils;
use Pterodactyl\Services\Support\DiscordBridge;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Only lets the BerryHost Discord bot in. The bot sends DISCORD_BOT_SECRET as a bearer
 * token; if DISCORD_BOT_ALLOWED_IPS is set it must also connect from one of those.
 */
class AuthenticateDiscordBot
{
    public function handle(Request $request, \Closure $next): mixed
    {
        // With no secret set the bot API doesn't exist at all.
        if (!DiscordBridge::enabled()) {
            throw new NotFoundHttpException();
        }

        $secret = (string) config('tickets.bot_secret');
        $given = (string) $request->bearerToken();
        if (strlen($secret) < 32) {
            throw new HttpException(503, 'DISCORD_BOT_SECRET must be at least 32 characters long.');
        }
        if ($given === '' || !hash_equals(hash('sha256', $secret), hash('sha256', $given))) {
            throw new HttpException(401, 'Invalid bot secret.');
        }

        $allowed = config('tickets.bot_allowed_ips', []);
        if (!empty($allowed) && !IpUtils::checkIp((string) $request->ip(), $allowed)) {
            throw new HttpException(403, 'This IP address is not allowed to use the bot API.');
        }

        return $next($request);
    }
}
