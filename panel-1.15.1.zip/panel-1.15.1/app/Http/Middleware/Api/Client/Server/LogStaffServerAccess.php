<?php

namespace Pterodactyl\Http\Middleware\Api\Client\Server;

use Illuminate\Http\Request;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\Cache;
use Pterodactyl\Services\Activity\AuditLogger;

/**
 * Records staff opening a server that isn't theirs (and that they aren't a subuser
 * of). Only shown in the admin logs, never to the customer.
 */
class LogStaffServerAccess
{
    public function __construct(private AuditLogger $logger)
    {
    }

    public function handle(Request $request, \Closure $next): mixed
    {
        $response = $next($request);

        /** @var \Pterodactyl\Models\User|null $user */
        $user = $request->user();
        $server = $request->route()?->parameter('server');

        if (
            $user && $server instanceof Server && AuditLogger::enabled()
            && ($user->root_admin || !is_null($user->admin_role_id))
            && $server->owner_id !== $user->id
            && !$server->subusers->contains('user_id', $user->id)
        ) {
            $minutes = max(1, (int) config('activity.audit.staff_access_minutes', 15));
            if (Cache::add("audit:staff-access:{$user->id}:{$server->id}", true, $minutes * 60)) {
                $this->logger->log('admin:staff.server-access', [$server, $server->user], [
                    'server' => $server->name,
                    'owner' => $server->user->username,
                    'path' => '/' . ltrim($request->path(), '/'),
                ]);
            }
        }

        return $response;
    }
}
