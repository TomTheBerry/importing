<?php

namespace Pterodactyl\Http\Middleware\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Database\Eloquent\Model;
use Pterodactyl\Services\Activity\AuditLogger;
use Symfony\Component\HttpFoundation\Response;
use Pterodactyl\Services\Activity\ActivityLogBatchService;

/**
 * Records everything done in the admin area: every change (with the fields that were
 * sent, secrets removed), refused attempts, and pages staff look at.
 */
class LogAdminActivity
{
    /**
     * Form fields that are never worth storing.
     */
    protected const SKIP_FIELDS = ['_token', '_method'];

    /**
     * Admin routes that take a numeric "id" and the record it refers to.
     */
    protected const ID_ROUTES = [
        'admin.billing.products' => \Pterodactyl\Models\Billing\Product::class,
        'admin.billing.services' => \Pterodactyl\Models\Billing\Subscription::class,
        'admin.billing.invoices' => \Pterodactyl\Models\Billing\Invoice::class,
        'admin.billing.payments' => \Pterodactyl\Models\Billing\Payment::class,
        'admin.billing.coupons' => \Pterodactyl\Models\Billing\Coupon::class,
        'admin.billing.credit' => \Pterodactyl\Models\User::class,
    ];

    public function __construct(private AuditLogger $logger, private ActivityLogBatchService $batch)
    {
    }

    public function handle(Request $request, \Closure $next): mixed
    {
        // Everything that happens during this request is grouped together in the logs.
        $this->batch->start();

        try {
            $response = $next($request);

            if ($request->user() && AuditLogger::enabled()) {
                $this->record($request, $response);
            }
        } finally {
            $this->batch->end();
        }

        return $response;
    }

    protected function record(Request $request, mixed $response): void
    {
        $status = $response instanceof Response ? $response->getStatusCode() : 200;
        $route = $request->route();
        $name = $route?->getName() ?? '';
        $short = $this->actionKey($request);
        $subjects = $this->subjects($request);
        $params = collect($route?->parameters() ?? [])
            ->map(fn ($value) => $value instanceof Model ? $value->getKey() : (is_scalar($value) ? $value : null))
            ->filter(fn ($value) => !is_null($value))
            ->all();

        $base = ['route' => $name ?: null, 'method' => $request->method(), 'path' => '/' . ltrim($request->path(), '/'), 'status' => $status];
        if (!empty($params)) {
            $base['parameters'] = $params;
        }

        // Refused: the person isn't allowed to do this. Recorded at most once a minute per page.
        if ($status === 403) {
            if (Cache::add('audit:denied:' . $request->user()->id . ':' . sha1($request->method() . $request->path()), true, 60)) {
                $this->logger->log('admin:denied', $subjects, $base);
            }

            return;
        }

        if ($request->isMethod('GET') || $request->isMethod('HEAD')) {
            $this->recordView($request, $short, $subjects, $base, $status);

            return;
        }

        $input = [];
        foreach ($request->except(self::SKIP_FIELDS) as $key => $value) {
            $input[$key] = AuditLogger::clean((string) $key, $value);
        }
        foreach ($request->allFiles() as $key => $file) {
            $input[$key] = AuditLogger::clean((string) $key, $file);
        }

        $failed = $status >= 400 || ($request->hasSession() && $request->session()->has('errors'));

        $this->logger->log('admin:' . $short, $subjects, array_merge($base, [
            'result' => $failed ? 'failed' : 'success',
            'input' => $input,
        ]));
    }

    /**
     * Pages staff open, at most once every 10 minutes per page. Plain list pages (no
     * specific record) and background requests are not recorded.
     */
    protected function recordView(Request $request, string $short, array $subjects, array $base, int $status): void
    {
        if (!config('activity.audit.log_admin_views', true) || $status !== 200 || empty($base['parameters'] ?? null) || $request->expectsJson() || str_ends_with($short, '.json')) {
            return;
        }

        $key = 'audit:view:' . $request->user()->id . ':' . sha1($request->path());
        if (Cache::add($key, true, 600)) {
            $this->logger->log('admin:view', $subjects, $base);
        }
    }

    /**
     * A stable name for the action, built from the URL without its IDs, e.g. a PATCH to
     * /admin/servers/view/5/build becomes "servers.view.build.update".
     */
    protected function actionKey(Request $request): string
    {
        $uri = (string) ($request->route()?->uri() ?? $request->path());
        $parts = array_filter(explode('/', $uri), fn ($part) => $part !== '' && $part !== 'admin' && !str_starts_with($part, '{'));
        $key = implode('.', $parts) ?: 'index';

        return match ($request->method()) {
            'GET', 'HEAD' => $key,
            'POST' => $key . '.post',
            'PUT', 'PATCH' => $key . '.update',
            'DELETE' => $key . '.delete',
            default => $key . '.' . strtolower($request->method()),
        };
    }

    /**
     * Records referenced by the URL (e.g. the server being edited).
     *
     * @return Model[]
     */
    protected function subjects(Request $request): array
    {
        $subjects = [];
        $route = $request->route();
        foreach ($route?->parameters() ?? [] as $value) {
            if ($value instanceof Model) {
                $subjects[] = $value;
            }
        }

        // Billing pages use plain numeric IDs, so look the record up for filtering.
        $id = $route?->parameter('id');
        if (is_numeric($id)) {
            foreach (self::ID_ROUTES as $prefix => $class) {
                if (str_starts_with((string) $route->getName(), $prefix) && ($model = $class::query()->find((int) $id))) {
                    $subjects[] = $model;
                    break;
                }
            }
        }

        return $subjects;
    }
}
