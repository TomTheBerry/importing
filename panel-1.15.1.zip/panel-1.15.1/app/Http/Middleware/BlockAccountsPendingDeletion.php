<?php

namespace Pterodactyl\Http\Middleware;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;

/**
 * Once someone asks for their account to be deleted, every existing session and API
 * key stops working. Only logging in again (which cancels the deletion) gets them back
 * in, so an old browser tab can't quietly keep the account alive.
 */
class BlockAccountsPendingDeletion
{
    public function handle(Request $request, \Closure $next): mixed
    {
        $user = $request->user();
        if (!$user || !$user->deletion_scheduled_at || $request->routeIs('auth.logout')) {
            return $next($request);
        }

        if ($request->hasSession()) {
            Auth::guard('web')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
        }

        if ($request->expectsJson() || $request->is('api/*')) {
            return new JsonResponse([
                'errors' => [[
                    'code' => 'AccountPendingDeletion',
                    'status' => '403',
                    'detail' => 'This account is scheduled for deletion. Log in to the Panel to cancel it.',
                ]],
            ], 403);
        }

        return redirect()->to('/auth/login?deletion=scheduled');
    }
}
