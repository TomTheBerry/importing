<?php

namespace Pterodactyl\Http\Middleware;

use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class RequireAdminPermission
{
    public const ALIAS = 'admin.can';

    /**
     * Ensures that the user making the request holds at least ONE of the staff
     * permissions passed to the middleware, for example:
     *
     *   ->middleware('admin.can:servers.read')
     *   ->middleware('admin.can:users.read,servers.create')
     *
     * @throws AccessDeniedHttpException
     */
    public function handle(Request $request, \Closure $next, string ...$permissions): mixed
    {
        /** @var \Pterodactyl\Models\User|null $user */
        $user = $request->user();

        if (!$user || empty($permissions) || !$user->hasAdminPermission(...$permissions)) {
            throw new AccessDeniedHttpException('Your staff role does not grant access to this action.');
        }

        return $next($request);
    }
}
