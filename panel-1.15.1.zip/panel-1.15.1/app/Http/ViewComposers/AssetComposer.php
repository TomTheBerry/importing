<?php

namespace Pterodactyl\Http\ViewComposers;

use Illuminate\View\View;
use Pterodactyl\Services\Legal\LegalService;
use Pterodactyl\Services\Legal\CompanyDetails;
use Pterodactyl\Services\Helpers\AssetHashService;
use Pterodactyl\Services\Auth\OAuth\OAuthProviders;
use Pterodactyl\Services\Users\RegistrationService;
use Pterodactyl\Services\Sessions\ImpersonationService;

class AssetComposer
{
    /**
     * AssetComposer constructor.
     */
    public function __construct(private AssetHashService $assetHashService)
    {
    }

    /**
     * Provide access to the asset service in the views.
     */
    public function compose(View $view): void
    {
        $view->with('asset', $this->assetHashService);
        $view->with('siteConfiguration', [
            'name' => config('app.name') ?? 'Pterodactyl',
            'locale' => config('app.locale') ?? 'en',
            'registration' => [
                'enabled' => RegistrationService::enabled(),
                'requiresCode' => RegistrationService::requiresAccessCode(),
            ],
            'billing' => [
                'enabled' => (bool) config('billing.enabled'),
            ],
            'support' => [
                'enabled' => (bool) config('tickets.enabled', true),
                'discord' => \Pterodactyl\Services\Support\DiscordBridge::enabled(),
            ],
            // Providers people can log in with (only those set up in .env).
            'oauth' => array_values(OAuthProviders::available()),
            'recaptcha' => [
                'enabled' => config('recaptcha.enabled', false),
                'siteKey' => config('recaptcha.website_key') ?? '',
            ],
            'legal' => LegalService::LINKS,
            // Shown in the footer of every page (public information).
            'company' => CompanyDetails::forFrontend(),
            // Set while a root administrator is viewing the Panel as this user.
            'impersonation' => $this->impersonation(),
        ]);
    }

    /**
     * @return array{admin: string, user: string, endsAt: int}|null
     */
    private function impersonation(): ?array
    {
        $request = request();
        $details = $request->hasSession() ? ImpersonationService::details($request) : null;
        if (!$details) {
            return null;
        }

        return [
            'admin' => $details['admin'],
            'user' => $details['user'],
            'endsAt' => $details['started_at'] + ImpersonationService::MAX_MINUTES * 60,
        ];
    }
}
