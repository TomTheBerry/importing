<?php

namespace Pterodactyl\Models\Billing;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $invoice_id
 * @property string $description
 * @property int $quantity
 * @property int $unit_amount
 * @property int $amount
 */
class InvoiceItem extends Model
{
    protected $table = 'billing_invoice_items';

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = ['quantity' => 'integer', 'unit_amount' => 'integer', 'amount' => 'integer'];
}
