<?php

namespace Pterodactyl\Models\Billing;

use Pterodactyl\Models\User;
use Pterodactyl\Models\Model;
use Pterodactyl\Services\Billing\Money;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property int $id
 * @property string $uuid
 * @property string|null $number
 * @property int|null $user_id
 * @property string|null $customer_name
 * @property int|null $subscription_id
 * @property int|null $coupon_id
 * @property int|null $upgrade_product_id
 * @property string $type
 * @property string $status
 * @property string $currency
 * @property int $subtotal
 * @property int $discount
 * @property int $credit_applied
 * @property int $total
 * @property \Carbon\CarbonImmutable|null $period_start
 * @property \Carbon\CarbonImmutable|null $period_end
 * @property \Carbon\CarbonImmutable|null $due_at
 * @property \Carbon\CarbonImmutable|null $paid_at
 * @property \Carbon\CarbonImmutable|null $last_reminder_at
 * @property int $payment_attempts
 * @property \Carbon\CarbonImmutable|null $last_payment_attempt_at
 * @property string|null $last_payment_error
 * @property string|null $notes
 * @property \Carbon\CarbonImmutable $created_at
 * @property User|null $user
 * @property Subscription|null $subscription
 * @property Coupon|null $coupon
 * @property Product|null $upgradeProduct
 * @property \Illuminate\Database\Eloquent\Collection<int, InvoiceItem> $items
 * @property \Illuminate\Database\Eloquent\Collection<int, Payment> $payments
 */
class Invoice extends Model
{
    public const TYPE_NEW = 'new';
    public const TYPE_RENEWAL = 'renewal';
    public const TYPE_UPGRADE = 'upgrade';
    public const TYPE_MANUAL = 'manual';

    public const STATUS_UNPAID = 'unpaid';
    public const STATUS_PAID = 'paid';
    public const STATUS_VOID = 'void';
    public const STATUS_REFUNDED = 'refunded';

    protected $table = 'billing_invoices';

    protected $guarded = ['id', 'uuid', 'created_at', 'updated_at'];

    protected $casts = [
        'period_start' => 'datetime',
        'period_end' => 'datetime',
        'due_at' => 'datetime',
        'paid_at' => 'datetime',
        'last_reminder_at' => 'datetime',
        'last_payment_attempt_at' => 'datetime',
        'subtotal' => 'integer',
        'discount' => 'integer',
        'credit_applied' => 'integer',
        'total' => 'integer',
        'payment_attempts' => 'integer',
    ];

    public function getRouteKeyName(): string
    {
        return 'id';
    }

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /** @return BelongsTo<Subscription, $this> */
    public function subscription(): BelongsTo
    {
        return $this->belongsTo(Subscription::class);
    }

    /** @return BelongsTo<Coupon, $this> */
    public function coupon(): BelongsTo
    {
        return $this->belongsTo(Coupon::class);
    }

    /** @return BelongsTo<Product, $this> */
    public function upgradeProduct(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'upgrade_product_id');
    }

    /** @return HasMany<InvoiceItem, $this> */
    public function items(): HasMany
    {
        return $this->hasMany(InvoiceItem::class);
    }

    /** @return HasMany<Payment, $this> */
    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function isUnpaid(): bool
    {
        return $this->status === self::STATUS_UNPAID;
    }

    /**
     * An upgrade invoice only applies to the billing period it was made for. Once the
     * service renews (or changes) it must not be paid any more.
     */
    public function isStaleUpgrade(): bool
    {
        if ($this->type !== self::TYPE_UPGRADE) {
            return false;
        }

        // Only an active service can be upgraded (not a suspended or ended one).
        if ($this->subscription?->status !== Subscription::STATUS_ACTIVE) {
            return true;
        }

        $due = $this->subscription->next_due_at;

        return !$due || !$this->period_end || !$this->period_end->eq($due);
    }

    public function isOverdue(): bool
    {
        return $this->isUnpaid() && $this->due_at && $this->due_at->isPast();
    }

    public function displayNumber(): string
    {
        return $this->number ?? ('#' . $this->id);
    }

    public function money(int $amount): string
    {
        return Money::format($amount, $this->currency);
    }

    /**
     * Total amount refunded across all payments for this invoice.
     */
    public function refundedAmount(): int
    {
        return (int) $this->payments()->sum('refunded_amount');
    }
}
