<?php

namespace Pterodactyl\Models\Billing;

use Pterodactyl\Models\User;
use Pterodactyl\Models\Model;
use Pterodactyl\Models\Server;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A paid service: one billed game server.
 *
 * @property int $id
 * @property string $uuid
 * @property int $user_id
 * @property int|null $product_id
 * @property int|null $scheduled_product_id
 * @property int|null $server_id
 * @property int|null $coupon_id
 * @property int|null $location_id
 * @property string $name
 * @property string $status
 * @property int $price
 * @property \Carbon\CarbonImmutable|null $next_due_at
 * @property bool $cancel_at_period_end
 * @property \Carbon\CarbonImmutable|null $cancelled_at
 * @property \Carbon\CarbonImmutable|null $suspended_at
 * @property bool $server_suspended_by_billing
 * @property \Carbon\CarbonImmutable|null $terminated_at
 * @property \Carbon\CarbonImmutable|null $start_now_consent_at
 * @property string|null $provision_error
 * @property \Carbon\CarbonImmutable $created_at
 * @property User $user
 * @property Product|null $product
 * @property Product|null $scheduledProduct
 * @property Server|null $server
 * @property Coupon|null $coupon
 */
class Subscription extends Model
{
    public const STATUS_PENDING = 'pending';           // waiting for the first payment
    public const STATUS_PROVISIONING = 'provisioning'; // paid, server being created
    public const STATUS_ACTIVE = 'active';
    public const STATUS_SUSPENDED = 'suspended';       // unpaid, server suspended
    public const STATUS_FAILED = 'failed';             // paid but the server could not be created
    public const STATUS_CANCELLED = 'cancelled';       // order abandoned before payment
    public const STATUS_TERMINATED = 'terminated';     // server deleted

    /** Statuses that count as a live service. */
    public const LIVE_STATUSES = [self::STATUS_PROVISIONING, self::STATUS_ACTIVE, self::STATUS_SUSPENDED, self::STATUS_FAILED];

    protected $table = 'billing_subscriptions';

    protected $guarded = ['id', 'uuid', 'created_at', 'updated_at'];

    protected $casts = [
        'next_due_at' => 'datetime',
        'cancelled_at' => 'datetime',
        'suspended_at' => 'datetime',
        'terminated_at' => 'datetime',
        'start_now_consent_at' => 'datetime',
        'cancel_at_period_end' => 'boolean',
        'server_suspended_by_billing' => 'boolean',
        'price' => 'integer',
    ];

    public function getRouteKeyName(): string
    {
        return 'id';
    }

    /**
     * Keeps people's plan roles in Discord up to date.
     */
    protected static function booted(): void
    {
        static::saved(function (Subscription $subscription) {
            if ($subscription->wasRecentlyCreated || $subscription->wasChanged(['status', 'product_id', 'user_id'])) {
                self::syncDiscordRoles($subscription->user_id);
                if ($subscription->wasChanged('user_id') && $subscription->getOriginal('user_id')) {
                    self::syncDiscordRoles((int) $subscription->getOriginal('user_id'));
                }
            }
        });
        static::deleted(fn (Subscription $subscription) => self::syncDiscordRoles($subscription->user_id));
    }

    private static function syncDiscordRoles(?int $userId): void
    {
        $user = $userId ? User::query()->find($userId) : null;
        if ($user) {
            \Pterodactyl\Services\Support\DiscordRoleService::queueUser($user);
        }
    }

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /** @return BelongsTo<Product, $this> */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /** @return BelongsTo<Product, $this> */
    public function scheduledProduct(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'scheduled_product_id');
    }

    /** @return BelongsTo<Server, $this> */
    public function server(): BelongsTo
    {
        return $this->belongsTo(Server::class);
    }

    /** @return BelongsTo<Coupon, $this> */
    public function coupon(): BelongsTo
    {
        return $this->belongsTo(Coupon::class);
    }

    /** @return HasMany<Invoice, $this> */
    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    public function isLive(): bool
    {
        return in_array($this->status, self::LIVE_STATUSES, true);
    }

    /**
     * Whole days until the next renewal (negative when overdue).
     */
    public function daysUntilDue(): ?int
    {
        if (!$this->next_due_at) {
            return null;
        }

        return (int) floor(now()->startOfDay()->diffInDays($this->next_due_at->startOfDay(), false));
    }

    /**
     * The open (unpaid) invoice for this service, if any.
     */
    public function openInvoice(): ?Invoice
    {
        /** @var Invoice|null $invoice */
        $invoice = $this->invoices()->where('status', Invoice::STATUS_UNPAID)->latest('id')->first();

        return $invoice;
    }
}
