<?php

namespace Pterodactyl\Models\Billing;

use Pterodactyl\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property int $id
 * @property string $uuid
 * @property int|null $invoice_id
 * @property int|null $user_id
 * @property string $gateway
 * @property string|null $reference
 * @property int $amount
 * @property int $refunded_amount
 * @property string $status
 * @property string|null $note
 * @property int|null $created_by
 * @property \Carbon\Carbon $created_at
 * @property Invoice|null $invoice
 * @property User|null $user
 */
class Payment extends Model
{
    public const GATEWAY_STRIPE = 'stripe';
    public const GATEWAY_CREDIT = 'credit';
    public const GATEWAY_MANUAL = 'manual';

    public const STATUS_SUCCEEDED = 'succeeded';
    public const STATUS_REFUNDED = 'refunded';
    public const STATUS_PARTIALLY_REFUNDED = 'partial_refund';

    protected $table = 'billing_payments';

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = ['amount' => 'integer', 'refunded_amount' => 'integer'];

    /** @return BelongsTo<Invoice, $this> */
    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function refundable(): int
    {
        return max(0, $this->amount - $this->refunded_amount);
    }
}
