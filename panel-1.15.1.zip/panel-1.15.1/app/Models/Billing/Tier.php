<?php

namespace Pterodactyl\Models\Billing;

use Pterodactyl\Models\Egg;
use Pterodactyl\Models\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A plan tier with a RAM slider, e.g. "Standard" or "Premium". Customers pick how much
 * RAM they want; CPU, disk and price are worked out from it. Every RAM size is stored
 * as an ordinary plan (Product) linked back to this tier.
 *
 * @property int $id
 * @property string $uuid
 * @property string $name
 * @property string $category
 * @property string|null $tagline
 * @property string|null $description
 * @property array|null $features
 * @property bool $highlight
 * @property int|null $egg_id
 * @property array $location_ids
 * @property array|null $environment
 * @property string|null $docker_image
 * @property string|null $startup
 * @property int $min_gb
 * @property int $max_gb
 * @property int $step_gb
 * @property int $base_price
 * @property int $price_per_gb
 * @property int|null $discount_from_gb
 * @property int $discount_percent
 * @property int $setup_fee
 * @property int $cpu_per_gb
 * @property int $cpu_min
 * @property int|null $cpu_max
 * @property int $disk_per_gb
 * @property int $disk_min
 * @property int|null $disk_max
 * @property int $swap
 * @property int $io
 * @property int $database_limit
 * @property int $allocation_limit
 * @property int $backup_limit
 * @property int|null $stock
 * @property string|null $discord_role_id
 * @property bool $is_active
 * @property int $sort
 * @property Egg|null $egg
 * @property \Illuminate\Database\Eloquent\Collection<int, Product> $variants
 */
class Tier extends Model
{
    public const RESOURCE_NAME = 'billing_tier';

    /** Most RAM sizes one tier can offer, to keep the store and admin pages quick. */
    public const MAX_SIZES = 128;

    protected $table = 'billing_tiers';

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = [
        'features' => 'array',
        'location_ids' => 'array',
        'environment' => 'array',
        'highlight' => 'boolean',
        'is_active' => 'boolean',
        'egg_id' => 'integer',
        'min_gb' => 'integer',
        'max_gb' => 'integer',
        'step_gb' => 'integer',
        'base_price' => 'integer',
        'price_per_gb' => 'integer',
        'discount_from_gb' => 'integer',
        'discount_percent' => 'integer',
        'setup_fee' => 'integer',
        'cpu_per_gb' => 'integer',
        'cpu_min' => 'integer',
        'cpu_max' => 'integer',
        'disk_per_gb' => 'integer',
        'disk_min' => 'integer',
        'disk_max' => 'integer',
        'swap' => 'integer',
        'io' => 'integer',
        'database_limit' => 'integer',
        'allocation_limit' => 'integer',
        'backup_limit' => 'integer',
        'stock' => 'integer',
        'sort' => 'integer',
    ];

    public static array $validationRules = [
        'name' => 'required|string|between:1,64',
        'category' => 'required|string|between:1,191',
        'tagline' => 'nullable|string|max:191',
        'description' => 'nullable|string|max:5000',
        'features' => 'nullable|array',
        'highlight' => 'boolean',
        'egg_id' => 'required|integer|exists:eggs,id',
        'location_ids' => 'required|array|min:1',
        'environment' => 'nullable|array',
        'docker_image' => 'nullable|string|max:191',
        'startup' => 'nullable|string|max:5000',
        'min_gb' => 'required|integer|between:1,1024',
        'max_gb' => 'required|integer|between:1,1024',
        'step_gb' => 'required|integer|between:1,64',
        'base_price' => 'required|integer|min:0|max:10000000',
        'price_per_gb' => 'required|integer|min:0|max:10000000',
        'discount_from_gb' => 'nullable|integer|between:1,1024',
        'discount_percent' => 'required|integer|between:0,90',
        'setup_fee' => 'required|integer|min:0|max:10000000',
        'cpu_per_gb' => 'required|integer|min:0|max:10000',
        'cpu_min' => 'required|integer|min:0|max:100000',
        'cpu_max' => 'nullable|integer|min:0|max:100000',
        'disk_per_gb' => 'required|integer|min:0|max:10485760',
        'disk_min' => 'required|integer|min:0|max:104857600',
        'disk_max' => 'nullable|integer|min:0|max:104857600',
        'swap' => 'required|integer|min:-1',
        'io' => 'required|integer|between:10,1000',
        'database_limit' => 'required|integer|min:0',
        'allocation_limit' => 'required|integer|min:0',
        'backup_limit' => 'required|integer|min:0',
        'stock' => 'nullable|integer|min:0',
        'discord_role_id' => 'nullable|string|max:25',
        'is_active' => 'boolean',
        'sort' => 'integer|min:0',
    ];

    public function getRouteKeyName(): string
    {
        return 'id';
    }

    /**
     * The RAM sizes (in GB) offered, smallest first.
     *
     * @return int[]
     */
    public function sizes(): array
    {
        $step = max(1, $this->step_gb);
        $sizes = [];
        for ($gb = max(1, $this->min_gb); $gb <= $this->max_gb && count($sizes) < self::MAX_SIZES; $gb += $step) {
            $sizes[] = $gb;
        }

        return $sizes;
    }

    /**
     * Monthly price in pence for a RAM size. Each GB above "discount_from_gb" is
     * cheaper by "discount_percent", so the price never drops as RAM goes up.
     */
    public function priceFor(int $gb): int
    {
        $from = $this->discount_from_gb && $this->discount_percent > 0 ? $this->discount_from_gb : null;
        $full = $from === null ? $gb : min($gb, $from);
        $discounted = $from === null ? 0 : max(0, $gb - $from);

        return (int) round(
            $this->base_price
            + $this->price_per_gb * $full
            + $this->price_per_gb * $discounted * (100 - $this->discount_percent) / 100
        );
    }

    /**
     * CPU limit (% of one core) for a RAM size. 0 means no limit.
     */
    public function cpuFor(int $gb): int
    {
        return $this->clamp($this->cpu_per_gb * $gb, $this->cpu_min, $this->cpu_max);
    }

    /**
     * Disk space in MB for a RAM size (at least 256 MB).
     */
    public function diskFor(int $gb): int
    {
        return max(256, $this->clamp($this->disk_per_gb * $gb, $this->disk_min, $this->disk_max));
    }

    private function clamp(int $value, int $min, ?int $max): int
    {
        $value = max($value, $min);

        return $max ? min($value, $max) : $value;
    }

    /**
     * Services across every size of this tier, for the tier's stock limit.
     */
    public function activeCount(): int
    {
        return Subscription::query()
            ->whereIn('product_id', $this->variants()->select('id'))
            ->whereIn('status', array_merge(Subscription::LIVE_STATUSES, [Subscription::STATUS_PENDING]))
            ->count();
    }

    public function inStock(): bool
    {
        return is_null($this->stock) || $this->activeCount() < $this->stock;
    }

    /**
     * @return BelongsTo<Egg, $this>
     */
    public function egg(): BelongsTo
    {
        return $this->belongsTo(Egg::class);
    }

    /**
     * The plan for each RAM size.
     *
     * @return HasMany<Product, $this>
     */
    public function variants(): HasMany
    {
        return $this->hasMany(Product::class, 'tier_id')->orderBy('tier_gb');
    }
}
