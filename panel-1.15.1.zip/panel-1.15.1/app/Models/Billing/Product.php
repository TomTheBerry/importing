<?php

namespace Pterodactyl\Models\Billing;

use Pterodactyl\Models\Egg;
use Pterodactyl\Models\Model;
use Pterodactyl\Models\Location;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A plan that customers can buy, e.g. "Minecraft 4GB".
 *
 * @property int $id
 * @property string $uuid
 * @property string $name
 * @property string $category
 * @property string|null $description
 * @property int|null $egg_id
 * @property int $memory
 * @property int $swap
 * @property int $disk
 * @property int $io
 * @property int $cpu
 * @property string|null $threads
 * @property int $database_limit
 * @property int $allocation_limit
 * @property int $backup_limit
 * @property array $location_ids
 * @property array|null $environment
 * @property string|null $docker_image
 * @property string|null $startup
 * @property int $price
 * @property int $setup_fee
 * @property int|null $stock
 * @property string|null $discord_role_id
 * @property bool $is_active
 * @property int $sort
 * @property int|null $tier_id
 * @property int|null $tier_gb
 * @property Tier|null $tier
 * @property Egg|null $egg
 */
class Product extends Model
{
    protected $table = 'billing_products';

    protected $guarded = ['id', 'uuid', 'created_at', 'updated_at'];

    protected $casts = [
        'location_ids' => 'array',
        'environment' => 'array',
        'is_active' => 'boolean',
        'memory' => 'integer',
        'swap' => 'integer',
        'disk' => 'integer',
        'io' => 'integer',
        'cpu' => 'integer',
        'database_limit' => 'integer',
        'allocation_limit' => 'integer',
        'backup_limit' => 'integer',
        'price' => 'integer',
        'setup_fee' => 'integer',
        'stock' => 'integer',
        'sort' => 'integer',
        'tier_id' => 'integer',
        'tier_gb' => 'integer',
    ];

    public static array $validationRules = [
        'name' => 'required|string|between:1,191',
        'category' => 'required|string|between:1,191',
        'description' => 'nullable|string|max:5000',
        'egg_id' => 'required|integer|exists:eggs,id',
        'memory' => 'required|integer|min:128',
        'swap' => 'required|integer|min:-1',
        'disk' => 'required|integer|min:256',
        'io' => 'required|integer|between:10,1000',
        'cpu' => 'required|integer|min:0',
        'threads' => 'nullable|regex:/^[0-9-,]+$/',
        'database_limit' => 'required|integer|min:0',
        'allocation_limit' => 'required|integer|min:0',
        'backup_limit' => 'required|integer|min:0',
        'location_ids' => 'required|array|min:1',
        'environment' => 'nullable|array',
        'docker_image' => 'nullable|string|max:191',
        'startup' => 'nullable|string|max:5000',
        'price' => 'required|integer|min:0|max:100000000',
        'setup_fee' => 'required|integer|min:0|max:100000000',
        'stock' => 'nullable|integer|min:0',
        'discord_role_id' => 'nullable|string|max:25',
        'is_active' => 'boolean',
        'sort' => 'integer|min:0',
        'tier_id' => 'nullable|integer',
        'tier_gb' => 'nullable|integer|min:1',
    ];

    public function getRouteKeyName(): string
    {
        return 'id';
    }

    /**
     * @return BelongsTo<Egg, $this>
     */
    public function egg(): BelongsTo
    {
        return $this->belongsTo(Egg::class);
    }

    /**
     * @return HasMany<Subscription, $this>
     */
    public function subscriptions(): HasMany
    {
        return $this->hasMany(Subscription::class);
    }

    /**
     * The locations this plan can be deployed to.
     */
    public function locations()
    {
        return Location::query()->whereIn('id', $this->location_ids ?? [])->orderBy('short')->get();
    }

    /**
     * Number of services using this plan, used for stock limits. Unpaid orders hold
     * their slot until they are paid or abandoned.
     */
    public function activeCount(): int
    {
        return $this->subscriptions()->whereIn('status', array_merge(Subscription::LIVE_STATUSES, [Subscription::STATUS_PENDING]))->count();
    }

    public function inStock(): bool
    {
        // A RAM size of a tier shares the tier's stock limit.
        if ($this->tier_id) {
            return $this->tier === null || $this->tier->inStock();
        }

        return is_null($this->stock) || $this->activeCount() < $this->stock;
    }

    /**
     * The slider tier this plan is one RAM size of, if any.
     *
     * @return BelongsTo<Tier, $this>
     */
    public function tier(): BelongsTo
    {
        return $this->belongsTo(Tier::class, 'tier_id');
    }
}
