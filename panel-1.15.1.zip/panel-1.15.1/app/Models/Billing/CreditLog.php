<?php

namespace Pterodactyl\Models\Billing;

use Pterodactyl\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * An audit record of every change to a user's account credit.
 *
 * @property int $id
 * @property int $user_id
 * @property int $amount
 * @property int $balance_after
 * @property string $reason
 * @property int|null $invoice_id
 * @property int|null $actor_id
 * @property \Carbon\Carbon $created_at
 */
class CreditLog extends Model
{
    protected $table = 'billing_credit_logs';

    protected $guarded = ['id', 'created_at', 'updated_at'];

    /** @return BelongsTo<User, $this> */
    public function actor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'actor_id');
    }
}
