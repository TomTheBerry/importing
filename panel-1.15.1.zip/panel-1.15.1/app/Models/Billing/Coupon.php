<?php

namespace Pterodactyl\Models\Billing;

use Pterodactyl\Models\Model;

/**
 * @property int $id
 * @property string $code
 * @property string $type
 * @property int $value
 * @property string $duration
 * @property int|null $max_uses
 * @property int $uses
 * @property array|null $product_ids
 * @property \Carbon\CarbonImmutable|null $expires_at
 * @property bool $is_active
 */
class Coupon extends Model
{
    public const TYPE_PERCENT = 'percent';
    public const TYPE_FIXED = 'fixed';

    public const DURATION_ONCE = 'once';
    public const DURATION_FOREVER = 'forever';

    protected $table = 'billing_coupons';

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = [
        'product_ids' => 'array',
        'expires_at' => 'datetime',
        'is_active' => 'boolean',
        'value' => 'integer',
        'uses' => 'integer',
        'max_uses' => 'integer',
    ];

    public static array $validationRules = [
        'code' => 'required|string|between:3,64|regex:/^[A-Za-z0-9_-]+$/|unique:billing_coupons,code',
        'type' => 'required|in:percent,fixed',
        'value' => 'required|integer|min:1',
        'duration' => 'required|in:once,forever',
        'max_uses' => 'nullable|integer|min:1',
        'product_ids' => 'nullable|array',
        'expires_at' => 'nullable|date',
        'is_active' => 'boolean',
    ];

    public function getRouteKeyName(): string
    {
        return 'id';
    }

    public function setCodeAttribute(string $value): void
    {
        $this->attributes['code'] = mb_strtoupper(trim($value));
    }

    /**
     * Returns null if the coupon can be used for the product, otherwise the reason it can't.
     */
    public function problemFor(?Product $product): ?string
    {
        if (!$this->is_active) {
            return 'That coupon is not active.';
        }
        if ($this->expires_at && $this->expires_at->isPast()) {
            return 'That coupon has expired.';
        }
        // Unpaid orders hold their use, so a limited coupon can't be over-used by
        // placing lots of orders before paying for any of them.
        if (!is_null($this->max_uses) && $this->uses + $this->reservedUses() >= $this->max_uses) {
            return 'That coupon has been fully used.';
        }
        if ($product && !$this->allowsProduct($product)) {
            return 'That coupon cannot be used with this plan.';
        }

        return null;
    }

    public function allowsProduct(Product $product): bool
    {
        return empty($this->product_ids) || in_array($product->id, array_map('intval', $this->product_ids), true);
    }

    /**
     * Whether a "forever" discount still applies when a service renews on this plan.
     * Switching it off or moving to a plan it isn't for ends the discount.
     */
    public function appliesToRenewal(Product $product): bool
    {
        return $this->duration === self::DURATION_FOREVER && $this->is_active && $this->allowsProduct($product);
    }

    /**
     * Orders placed with this coupon that are still waiting for payment.
     */
    public function reservedUses(): int
    {
        return Invoice::query()
            ->where('coupon_id', $this->id)
            ->where('type', Invoice::TYPE_NEW)
            ->where('status', Invoice::STATUS_UNPAID)
            ->count();
    }

    /**
     * Each customer can use a coupon on one order.
     */
    public function usedBy(\Pterodactyl\Models\User $user): bool
    {
        return Invoice::query()
            ->where('coupon_id', $this->id)
            ->where('user_id', $user->id)
            ->where('type', Invoice::TYPE_NEW)
            ->whereIn('status', [Invoice::STATUS_UNPAID, Invoice::STATUS_PAID, Invoice::STATUS_REFUNDED])
            ->exists();
    }

    /**
     * Works out the discount (in minor units) for an amount.
     */
    public function discountFor(int $amount): int
    {
        $discount = $this->type === self::TYPE_PERCENT
            ? intdiv($amount * min(100, $this->value), 100)
            : $this->value;

        return max(0, min($amount, $discount));
    }

    public function label(): string
    {
        $value = $this->type === self::TYPE_PERCENT ? $this->value . '%' : \Pterodactyl\Services\Billing\Money::format($this->value);

        return $value . ' off' . ($this->duration === self::DURATION_FOREVER ? ' every month' : ' first payment');
    }
}
