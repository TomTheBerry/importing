<?php

namespace Pterodactyl\Models;

use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A request for a copy of someone's data, or to delete their account.
 *
 * @property int $id
 * @property string $uuid
 * @property int|null $user_id
 * @property string $label
 * @property string $type
 * @property string $status
 * @property \Carbon\CarbonImmutable|null $due_at
 * @property bool $extended
 * @property string|null $reason
 * @property int|null $handled_by
 * @property \Carbon\CarbonImmutable|null $handled_at
 * @property string|null $file_path
 * @property \Carbon\CarbonImmutable|null $file_expires_at
 * @property \Carbon\CarbonImmutable|null $downloaded_at
 * @property \Carbon\CarbonImmutable $created_at
 * @property \Carbon\CarbonImmutable $updated_at
 * @property User|null $user
 * @property User|null $handler
 */
class PrivacyRequest extends Model
{
    public const RESOURCE_NAME = 'privacy_request';

    public const TYPE_EXPORT = 'export';
    public const TYPE_DELETION = 'deletion';

    // Exports
    public const STATUS_PENDING = 'pending';
    public const STATUS_SENT = 'sent';
    public const STATUS_DECLINED = 'declined';
    // Deletions
    public const STATUS_SCHEDULED = 'scheduled';
    public const STATUS_DELETED = 'deleted';
    public const STATUS_FAILED = 'failed';
    // Both
    public const STATUS_CANCELLED = 'cancelled';

    protected bool $immutableDates = true;

    protected $guarded = ['id', 'uuid', 'created_at', 'updated_at'];

    protected $casts = [
        'user_id' => 'integer',
        'handled_by' => 'integer',
        'extended' => 'boolean',
        'due_at' => 'datetime',
        'handled_at' => 'datetime',
        'file_expires_at' => 'datetime',
        'downloaded_at' => 'datetime',
    ];

    public static array $validationRules = [
        'user_id' => 'nullable|integer',
        'label' => 'required|string|max:191',
        'type' => 'required|string|in:export,deletion',
        'status' => 'required|string|max:16',
        'due_at' => 'nullable|date',
        'extended' => 'boolean',
        'reason' => 'nullable|string|max:2000',
        'handled_by' => 'nullable|integer',
        'handled_at' => 'nullable|date',
        'file_path' => 'nullable|string|max:191',
        'file_expires_at' => 'nullable|date',
        'downloaded_at' => 'nullable|date',
    ];

    protected static function booted(): void
    {
        static::creating(function (PrivacyRequest $request) {
            $request->uuid = $request->uuid ?: Str::uuid()->toString();
        });
    }

    /**
     * Requests that still need something to happen.
     *
     * @param Builder<PrivacyRequest> $query
     *
     * @return Builder<PrivacyRequest>
     */
    public function scopeOpen(Builder $query): Builder
    {
        return $query->whereIn('status', [self::STATUS_PENDING, self::STATUS_SCHEDULED, self::STATUS_FAILED]);
    }

    public function isOpen(): bool
    {
        return in_array($this->status, [self::STATUS_PENDING, self::STATUS_SCHEDULED, self::STATUS_FAILED], true);
    }

    public function isOverdue(): bool
    {
        return $this->type === self::TYPE_EXPORT && $this->status === self::STATUS_PENDING && $this->due_at?->isPast();
    }

    /**
     * True when the user can download their export right now.
     */
    public function downloadable(): bool
    {
        return $this->type === self::TYPE_EXPORT
            && $this->status === self::STATUS_SENT
            && $this->file_path !== null
            && $this->file_expires_at?->isFuture();
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function handler(): BelongsTo
    {
        return $this->belongsTo(User::class, 'handled_by');
    }
}
