<?php

namespace Pterodactyl\Models;

use Pterodactyl\Services\Acl\AdminPermissions;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * A staff role that grants a set of admin panel and global server permissions.
 *
 * @property int $id
 * @property string $name
 * @property string|null $description
 * @property string|null $color
 * @property array $permissions
 * @property bool $require_totp
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property \Illuminate\Database\Eloquent\Collection|\Pterodactyl\Models\User[] $users
 * @property int|null $users_count
 */
class AdminRole extends Model
{
    /** @use HasFactory<\Database\Factories\AdminRoleFactory> */
    use HasFactory;

    public const RESOURCE_NAME = 'admin_role';

    protected $table = 'admin_roles';

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = [
        'permissions' => 'array',
        'require_totp' => 'boolean',
    ];

    protected $attributes = [
        'permissions' => '[]',
    ];

    public static array $validationRules = [
        'name' => 'required|string|between:1,191|unique:admin_roles,name',
        'description' => 'nullable|string|max:1000',
        'color' => ['nullable', 'string', 'regex:/^#[0-9a-fA-F]{6}$/'],
        'permissions' => 'present|array',
        'require_totp' => 'boolean',
    ];

    public function getRouteKeyName(): string
    {
        return $this->getKeyName();
    }

    /**
     * Always store a clean, de-duplicated list of real permissions.
     */
    public function setPermissionsAttribute(mixed $value): void
    {
        $this->attributes['permissions'] = json_encode(AdminPermissions::sanitize(is_array($value) ? $value : []));
    }

    /**
     * Returns the role's permissions, ignoring any that no longer exist.
     *
     * @return string[]
     */
    public function getPermissionList(): array
    {
        return AdminPermissions::sanitize($this->permissions ?? []);
    }

    public function hasPermission(string $permission): bool
    {
        return in_array($permission, $this->getPermissionList(), true);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<\Pterodactyl\Models\User, $this>
     */
    public function users(): HasMany
    {
        return $this->hasMany(User::class, 'admin_role_id');
    }
}
