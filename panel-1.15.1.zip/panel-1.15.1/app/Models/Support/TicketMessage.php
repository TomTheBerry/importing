<?php

namespace Pterodactyl\Models\Support;

use Pterodactyl\Models\User;
use Pterodactyl\Models\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * One message in a ticket.
 *
 * @property int $id
 * @property int $ticket_id
 * @property string $author_type
 * @property int|null $user_id
 * @property string|null $discord_user_id
 * @property string|null $discord_name
 * @property string|null $discord_avatar
 * @property string $body
 * @property bool $internal
 * @property string $source
 * @property string|null $discord_message_id
 * @property \Carbon\CarbonImmutable $created_at
 * @property \Carbon\CarbonImmutable $updated_at
 * @property Ticket $ticket
 * @property User|null $user
 * @property \Illuminate\Database\Eloquent\Collection<int, TicketAttachment> $attachments
 */
class TicketMessage extends Model
{
    public const RESOURCE_NAME = 'ticket_message';

    public const AUTHOR_CUSTOMER = 'customer';
    public const AUTHOR_STAFF = 'staff';
    public const AUTHOR_GUEST = 'guest';
    public const AUTHOR_SYSTEM = 'system';

    protected bool $immutableDates = true;

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = ['ticket_id' => 'integer', 'user_id' => 'integer', 'internal' => 'boolean'];

    public static array $validationRules = [
        'ticket_id' => 'required|integer',
        'author_type' => 'required|string|in:customer,staff,guest,system',
        'user_id' => 'nullable|integer',
        'discord_user_id' => 'nullable|string|max:32',
        'discord_name' => 'nullable|string|max:100',
        'discord_avatar' => 'nullable|string|max:255',
        'body' => 'present|string|max:20000',
        'internal' => 'boolean',
        'source' => 'required|string|in:panel,discord',
        'discord_message_id' => 'nullable|string|max:32',
    ];

    public function isStaff(): bool
    {
        return $this->author_type === self::AUTHOR_STAFF;
    }

    /**
     * Name shown next to the message. Staff without a linked Panel account who reply in
     * Discord show as "Name (Staff)".
     */
    public function authorName(): string
    {
        if ($this->author_type === self::AUTHOR_SYSTEM) {
            return config('app.name');
        }
        if ($this->user) {
            return $this->user->username;
        }
        if ($this->discord_name) {
            return $this->discord_name . ($this->isStaff() ? ' (Staff)' : ' (Discord)');
        }

        return 'Deleted account';
    }

    /**
     * Staff role shown next to staff names, e.g. "Support".
     */
    public function staffLabel(): ?string
    {
        if (!$this->isStaff()) {
            return null;
        }

        return $this->user->adminRole->name ?? ($this->user?->root_admin ? 'Management' : 'Staff');
    }

    public function avatarUrl(): ?string
    {
        if ($this->user) {
            return $this->user->avatarUrl();
        }

        return $this->discord_avatar;
    }

    /**
     * @return BelongsTo<Ticket, $this>
     */
    public function ticket(): BelongsTo
    {
        return $this->belongsTo(Ticket::class);
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * @return HasMany<TicketAttachment, $this>
     */
    public function attachments(): HasMany
    {
        return $this->hasMany(TicketAttachment::class, 'message_id');
    }
}
