<?php

namespace Pterodactyl\Models\Support;

use Pterodactyl\Models\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Something the Discord bot has to do. The bot collects these from the Panel.
 *
 * @property int $id
 * @property string $type
 * @property int|null $ticket_id
 * @property array $payload
 * @property int $attempts
 * @property string|null $last_error
 * @property \Carbon\CarbonImmutable|null $available_at
 * @property \Carbon\CarbonImmutable|null $delivered_at
 * @property Ticket|null $ticket
 */
class DiscordOutboxItem extends Model
{
    public const RESOURCE_NAME = 'discord_outbox';

    public const MAX_ATTEMPTS = 8;

    protected bool $immutableDates = true;

    protected $table = 'discord_outbox';

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = [
        'payload' => 'array',
        'ticket_id' => 'integer',
        'attempts' => 'integer',
        'available_at' => 'datetime',
        'delivered_at' => 'datetime',
    ];

    public static array $validationRules = [
        'type' => 'required|string|max:32',
        'ticket_id' => 'nullable|integer',
    ];

    /**
     * @return BelongsTo<Ticket, $this>
     */
    public function ticket(): BelongsTo
    {
        return $this->belongsTo(Ticket::class);
    }
}
