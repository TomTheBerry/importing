<?php

namespace Pterodactyl\Models\Support;

use Pterodactyl\Models\User;
use Pterodactyl\Models\Model;
use Pterodactyl\Models\Server;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A support ticket, opened on the Panel or in Discord.
 *
 * @property int $id
 * @property string $uuid
 * @property int|null $user_id
 * @property string|null $guest_discord_id
 * @property string|null $guest_name
 * @property int|null $category_id
 * @property int|null $server_id
 * @property string $subject
 * @property string $status
 * @property string $priority
 * @property int|null $assigned_to
 * @property string $source
 * @property string|null $discord_channel_id
 * @property \Carbon\CarbonImmutable|null $last_customer_reply_at
 * @property \Carbon\CarbonImmutable|null $last_staff_reply_at
 * @property \Carbon\CarbonImmutable|null $last_message_at
 * @property \Carbon\CarbonImmutable|null $first_staff_reply_at
 * @property int|null $first_staff_reply_by
 * @property \Carbon\CarbonImmutable|null $closed_at
 * @property int|null $closed_by
 * @property string|null $close_reason
 * @property \Carbon\CarbonImmutable $created_at
 * @property \Carbon\CarbonImmutable $updated_at
 * @property User|null $user
 * @property User|null $assignee
 * @property TicketCategory|null $category
 * @property Server|null $server
 */
class Ticket extends Model
{
    public const RESOURCE_NAME = 'ticket';

    // Waiting for staff.
    public const STATUS_OPEN = 'open';
    // Staff replied, waiting for the customer.
    public const STATUS_ANSWERED = 'answered';
    public const STATUS_CLOSED = 'closed';

    public const STATUSES = [
        self::STATUS_OPEN => 'Waiting for staff',
        self::STATUS_ANSWERED => 'Waiting for customer',
        self::STATUS_CLOSED => 'Closed',
    ];

    public const PRIORITIES = [
        'low' => 'Low',
        'normal' => 'Normal',
        'high' => 'High',
        'urgent' => 'Urgent',
    ];

    public const SOURCE_PANEL = 'panel';
    public const SOURCE_DISCORD = 'discord';

    protected bool $immutableDates = true;

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = [
        'user_id' => 'integer',
        'category_id' => 'integer',
        'server_id' => 'integer',
        'assigned_to' => 'integer',
        'closed_by' => 'integer',
        'last_customer_reply_at' => 'datetime',
        'last_staff_reply_at' => 'datetime',
        'last_message_at' => 'datetime',
        'first_staff_reply_at' => 'datetime',
        'first_staff_reply_by' => 'integer',
        'closed_at' => 'datetime',
    ];

    public static array $validationRules = [
        'uuid' => 'required|string|size:36',
        'user_id' => 'nullable|integer',
        'guest_discord_id' => 'nullable|string|max:32',
        'guest_name' => 'nullable|string|max:100',
        'category_id' => 'nullable|integer',
        'server_id' => 'nullable|integer',
        'subject' => 'required|string|between:1,120',
        'status' => 'required|string|in:open,answered,closed',
        'priority' => 'required|string|in:low,normal,high,urgent',
        'assigned_to' => 'nullable|integer',
        'source' => 'required|string|in:panel,discord',
        'discord_channel_id' => 'nullable|string|max:32',
        'close_reason' => 'nullable|string|max:191',
    ];

    public function getRouteKeyName(): string
    {
        return 'id';
    }

    /**
     * "#0042".
     */
    public function number(): string
    {
        return '#' . str_pad((string) $this->id, 4, '0', STR_PAD_LEFT);
    }

    public function isClosed(): bool
    {
        return $this->status === self::STATUS_CLOSED;
    }

    public function isGuest(): bool
    {
        return is_null($this->user_id);
    }

    /**
     * Name to show for the person who opened the ticket.
     */
    public function customerName(): string
    {
        return $this->user->username ?? ($this->guest_name ? $this->guest_name . ' (Discord)' : 'Deleted account');
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function closer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'closed_by');
    }

    /**
     * @return BelongsTo<TicketCategory, $this>
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(TicketCategory::class);
    }

    /**
     * @return BelongsTo<Server, $this>
     */
    public function server(): BelongsTo
    {
        return $this->belongsTo(Server::class);
    }

    /**
     * @return HasMany<TicketMessage, $this>
     */
    public function messages(): HasMany
    {
        return $this->hasMany(TicketMessage::class)->orderBy('id');
    }

    /**
     * @return HasMany<TicketAttachment, $this>
     */
    public function attachments(): HasMany
    {
        return $this->hasMany(TicketAttachment::class);
    }
}
