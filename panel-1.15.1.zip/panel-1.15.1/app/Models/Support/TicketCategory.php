<?php

namespace Pterodactyl\Models\Support;

use Pterodactyl\Models\Model;

/**
 * A topic people pick when opening a ticket ("Billing", "Server problem"...).
 *
 * @property int $id
 * @property string $name
 * @property string|null $description
 * @property string|null $emoji
 * @property bool $is_active
 * @property int $sort
 */
class TicketCategory extends Model
{
    public const RESOURCE_NAME = 'ticket_category';

    protected $table = 'ticket_categories';

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = ['is_active' => 'boolean', 'sort' => 'integer'];

    public static array $validationRules = [
        'name' => 'required|string|between:1,64',
        'description' => 'nullable|string|max:191',
        'emoji' => 'nullable|string|max:16',
        'is_active' => 'boolean',
        'sort' => 'integer|min:0',
    ];

    public function getRouteKeyName(): string
    {
        return 'id';
    }

    public function label(): string
    {
        return trim(($this->emoji ? $this->emoji . ' ' : '') . $this->name);
    }
}
