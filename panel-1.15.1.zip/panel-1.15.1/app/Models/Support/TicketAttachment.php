<?php

namespace Pterodactyl\Models\Support;

use Pterodactyl\Models\Model;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A file attached to a ticket message, stored on the Panel's local disk.
 *
 * @property int $id
 * @property string $uuid
 * @property int $ticket_id
 * @property int $message_id
 * @property string $filename
 * @property string $mime
 * @property int $size
 * @property string $path
 * @property Ticket|null $ticket
 * @property TicketMessage|null $message
 */
class TicketAttachment extends Model
{
    public const RESOURCE_NAME = 'ticket_attachment';

    public const DIRECTORY = 'tickets';

    protected bool $immutableDates = true;

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = ['ticket_id' => 'integer', 'message_id' => 'integer', 'size' => 'integer'];

    public static array $validationRules = [
        'uuid' => 'required|string|size:36',
        'ticket_id' => 'required|integer',
        'message_id' => 'required|integer',
        'filename' => 'required|string|max:191',
        'mime' => 'required|string|max:100',
        'size' => 'required|integer|min:0',
        'path' => 'required|string|max:191',
    ];

    public function isImage(): bool
    {
        return in_array($this->mime, ['image/png', 'image/jpeg', 'image/gif', 'image/webp'], true);
    }

    protected static function booted(): void
    {
        // Remove the file from disk along with the record.
        static::deleted(function (TicketAttachment $attachment) {
            if (str_starts_with($attachment->path, self::DIRECTORY . '/')) {
                Storage::disk('local')->delete($attachment->path);
            }
        });
    }

    /**
     * @return BelongsTo<Ticket, $this>
     */
    public function ticket(): BelongsTo
    {
        return $this->belongsTo(Ticket::class);
    }

    /**
     * @return BelongsTo<TicketMessage, $this>
     */
    public function message(): BelongsTo
    {
        return $this->belongsTo(TicketMessage::class, 'message_id');
    }
}
