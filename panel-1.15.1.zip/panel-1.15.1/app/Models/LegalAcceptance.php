<?php

namespace Pterodactyl\Models;

/**
 * A record that someone accepted a version of the legal documents.
 *
 * @property int $id
 * @property int $user_id
 * @property string $version
 * @property string|null $ip
 * @property string|null $user_agent
 * @property \Carbon\CarbonImmutable $accepted_at
 */
class LegalAcceptance extends Model
{
    public const RESOURCE_NAME = 'legal_acceptance';

    public $timestamps = false;

    protected bool $immutableDates = true;

    protected $guarded = ['id'];

    protected $casts = ['user_id' => 'integer', 'accepted_at' => 'datetime'];

    public static array $validationRules = [
        'user_id' => 'required|integer',
        'version' => 'required|string|max:32',
        'ip' => 'nullable|string|max:45',
        'user_agent' => 'nullable|string|max:255',
        'accepted_at' => 'required|date',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<User, $this>
     */
    public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
