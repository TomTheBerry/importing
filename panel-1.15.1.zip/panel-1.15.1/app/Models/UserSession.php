<?php

namespace Pterodactyl\Models;

/**
 * A browser session where someone is logged in. The real session ID is stored
 * encrypted so the session can be ended; it is looked up by a one-way hash.
 *
 * @property int $id
 * @property int $user_id
 * @property string $session_hash
 * @property string $session_id
 * @property string|null $ip
 * @property string|null $user_agent
 * @property string|null $device
 * @property \Carbon\CarbonImmutable $last_active_at
 * @property \Carbon\CarbonImmutable $created_at
 */
class UserSession extends Model
{
    public const RESOURCE_NAME = 'user_session';

    protected bool $immutableDates = true;

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $hidden = ['session_id', 'session_hash'];

    protected $casts = ['user_id' => 'integer', 'session_id' => 'encrypted', 'last_active_at' => 'datetime'];

    public static array $validationRules = [
        'user_id' => 'required|integer',
        'session_hash' => 'required|string|size:64',
        'session_id' => 'required|string',
        'ip' => 'nullable|string|max:45',
        'user_agent' => 'nullable|string|max:255',
        'device' => 'nullable|string|max:100',
        'last_active_at' => 'required|date',
    ];
}
