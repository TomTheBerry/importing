<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A banner shown across the top of the Panel.
 *
 * @property int $id
 * @property string $message
 * @property string|null $link_url
 * @property string|null $link_text
 * @property string $style
 * @property string $audience
 * @property bool $dismissible
 * @property bool $is_active
 * @property \Carbon\CarbonImmutable|null $starts_at
 * @property \Carbon\CarbonImmutable|null $ends_at
 * @property int|null $created_by
 * @property \Carbon\CarbonImmutable $created_at
 * @property \Carbon\CarbonImmutable $updated_at
 * @property User|null $creator
 */
class Announcement extends Model
{
    public const RESOURCE_NAME = 'announcement';

    public const STYLES = [
        'info' => 'Information',
        'success' => 'Good news',
        'warning' => 'Warning',
        'issue' => 'Issue / outage',
        'maintenance' => 'Maintenance',
    ];

    /** Short label shown at the start of each banner. */
    public const TAGS = [
        'info' => 'Info',
        'success' => 'Update',
        'warning' => 'Warning',
        'issue' => 'Issue',
        'maintenance' => 'Maintenance',
    ];

    /** Font Awesome icon used for the banner preview in the admin area. */
    public const ICONS = [
        'info' => 'fa-info',
        'success' => 'fa-check',
        'warning' => 'fa-exclamation',
        'issue' => 'fa-bolt',
        'maintenance' => 'fa-wrench',
    ];

    public const AUDIENCES = [
        'everyone' => 'Everyone',
        'customers' => 'Customers only (not staff)',
        'staff' => 'Staff only',
    ];

    protected bool $immutableDates = true;

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = [
        'dismissible' => 'boolean',
        'is_active' => 'boolean',
        'starts_at' => 'datetime',
        'ends_at' => 'datetime',
        'created_by' => 'integer',
    ];

    public static array $validationRules = [
        'message' => 'required|string|max:500',
        'link_url' => 'nullable|url:https,http|max:255',
        'link_text' => 'nullable|string|max:64',
        'style' => 'required|string|in:info,success,warning,issue,maintenance',
        'audience' => 'required|string|in:everyone,customers,staff',
        'dismissible' => 'boolean',
        'is_active' => 'boolean',
        'starts_at' => 'nullable|date',
        'ends_at' => 'nullable|date',
        'created_by' => 'nullable|integer',
    ];

    /**
     * Announcements showing right now.
     *
     * @param Builder<Announcement> $query
     *
     * @return Builder<Announcement>
     */
    public function scopeLive(Builder $query): Builder
    {
        return $query->where('is_active', true)
            ->where(fn ($q) => $q->whereNull('starts_at')->orWhere('starts_at', '<=', now()))
            ->where(fn ($q) => $q->whereNull('ends_at')->orWhere('ends_at', '>', now()));
    }

    public function isLive(): bool
    {
        return $this->is_active
            && (!$this->starts_at || $this->starts_at->lte(now()))
            && (!$this->ends_at || $this->ends_at->gt(now()));
    }

    public function status(): string
    {
        if (!$this->is_active) {
            return 'off';
        }
        if ($this->starts_at && $this->starts_at->gt(now())) {
            return 'scheduled';
        }
        if ($this->ends_at && $this->ends_at->lte(now())) {
            return 'ended';
        }

        return 'live';
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
