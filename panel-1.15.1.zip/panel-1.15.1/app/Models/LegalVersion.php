<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A published version of the Terms of Service, Privacy Policy and Acceptable Use Policy.
 *
 * @property int $id
 * @property string $version
 * @property string|null $summary
 * @property int|null $published_by
 * @property \Carbon\CarbonImmutable $published_at
 * @property User|null $publisher
 */
class LegalVersion extends Model
{
    public const RESOURCE_NAME = 'legal_version';

    protected bool $immutableDates = true;

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = ['published_by' => 'integer', 'published_at' => 'datetime'];

    public static array $validationRules = [
        'version' => 'required|string|max:32',
        'summary' => 'nullable|string|max:2000',
        'published_by' => 'nullable|integer',
        'published_at' => 'required|date',
    ];

    /**
     * @return BelongsTo<User, $this>
     */
    public function publisher(): BelongsTo
    {
        return $this->belongsTo(User::class, 'published_by');
    }
}
