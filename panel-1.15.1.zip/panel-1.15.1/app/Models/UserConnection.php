<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A Google, GitHub or Discord account someone has connected so they can log in with it.
 *
 * @property int $id
 * @property int $user_id
 * @property string $provider
 * @property string $provider_user_id
 * @property string|null $username
 * @property string|null $email
 * @property \Carbon\CarbonImmutable|null $last_used_at
 * @property \Carbon\CarbonImmutable $created_at
 * @property \Carbon\CarbonImmutable $updated_at
 * @property User $user
 */
class UserConnection extends Model
{
    public const RESOURCE_NAME = 'user_connection';

    protected bool $immutableDates = true;

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = [
        'user_id' => 'integer',
        'last_used_at' => 'datetime',
    ];

    public static array $validationRules = [
        'user_id' => 'required|integer|exists:users,id',
        'provider' => 'required|string|max:32',
        'provider_user_id' => 'required|string|max:191',
        'username' => 'nullable|string|max:191',
        'email' => 'nullable|string|max:191',
        'last_used_at' => 'nullable|date',
    ];

    /**
     * Linking or unlinking Discord updates the person's roles in our Discord server.
     */
    protected static function booted(): void
    {
        $sync = function (UserConnection $connection) {
            if ($connection->provider === 'discord') {
                \Pterodactyl\Services\Support\DiscordRoleService::queue($connection->provider_user_id);
            }
        };
        static::created($sync);
        static::deleted($sync);
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
