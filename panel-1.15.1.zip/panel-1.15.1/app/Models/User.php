<?php

namespace Pterodactyl\Models;

use Pterodactyl\Rules\Username;
use Pterodactyl\Facades\Activity;
use Illuminate\Support\Collection;
use Illuminate\Validation\Rules\In;
use Illuminate\Auth\Authenticatable;
use Illuminate\Support\Facades\Storage;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Builder;
use Pterodactyl\Services\Users\AvatarService;
use Pterodactyl\Contracts\Models\Identifiable;
use Pterodactyl\Models\Traits\HasAccessTokens;
use Pterodactyl\Services\Acl\AdminPermissions;
use Illuminate\Auth\Passwords\CanResetPassword;
use Pterodactyl\Traits\Helpers\AvailableLanguages;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\Access\Authorizable;
use Pterodactyl\Models\Traits\HasRealtimeIdentifier;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\MorphToMany;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;
use Pterodactyl\Notifications\SendPasswordReset as ResetPasswordNotification;

/**
 * Pterodactyl\Models\User.
 *
 * @property int $id
 * @property string|null $external_id
 * @property string $uuid
 * @property string $username
 * @property string $email
 * @property \Illuminate\Support\Carbon|null $email_verified_at
 * @property bool $registration_pending
 * @property \Carbon\Carbon|null $deletion_scheduled_at
 * @property \Carbon\Carbon|null $date_of_birth
 * @property string|null $legal_version
 * @property \Carbon\Carbon|null $legal_accepted_at
 * @property bool $email_2fa
 * @property string|null $totp_app_name
 * @property int $billing_credit
 * @property string|null $stripe_customer_id
 * @property string|null $stripe_payment_method
 * @property string|null $card_brand
 * @property string|null $card_last4
 * @property string|null $card_expiry
 * @property string|null $name_first
 * @property string|null $name_last
 * @property string $password
 * @property string|null $remember_token
 * @property string $language
 * @property bool $root_admin
 * @property \Illuminate\Support\Carbon|null $email_verify_by
 * @property int|null $admin_role_id
 * @property AdminRole|null $adminRole
 * @property bool $use_totp
 * @property string|null $totp_secret
 * @property \Illuminate\Support\Carbon|null $totp_authenticated_at
 * @property bool $gravatar
 * @property string|null $avatar
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Illuminate\Database\Eloquent\Collection|\Pterodactyl\Models\ApiKey[] $apiKeys
 * @property int|null $api_keys_count
 * @property string $name
 * @property \Illuminate\Notifications\DatabaseNotificationCollection|\Illuminate\Notifications\DatabaseNotification[] $notifications
 * @property int|null $notifications_count
 * @property \Illuminate\Database\Eloquent\Collection|\Pterodactyl\Models\RecoveryToken[] $recoveryTokens
 * @property int|null $recovery_tokens_count
 * @property \Illuminate\Database\Eloquent\Collection|\Pterodactyl\Models\Server[] $servers
 * @property int|null $servers_count
 * @property \Illuminate\Database\Eloquent\Collection|\Pterodactyl\Models\UserSSHKey[] $sshKeys
 * @property int|null $ssh_keys_count
 * @property \Illuminate\Database\Eloquent\Collection|\Pterodactyl\Models\ApiKey[] $tokens
 * @property int|null $tokens_count
 *
 * @method static \Database\Factories\UserFactory factory(...$parameters)
 * @method static Builder|User newModelQuery()
 * @method static Builder|User newQuery()
 * @method static Builder|User query()
 * @method static Builder|User whereCreatedAt($value)
 * @method static Builder|User whereEmail($value)
 * @method static Builder|User whereExternalId($value)
 * @method static Builder|User whereGravatar($value)
 * @method static Builder|User whereId($value)
 * @method static Builder|User whereLanguage($value)
 * @method static Builder|User whereNameFirst($value)
 * @method static Builder|User whereNameLast($value)
 * @method static Builder|User wherePassword($value)
 * @method static Builder|User whereRememberToken($value)
 * @method static Builder|User whereRootAdmin($value)
 * @method static Builder|User whereTotpAuthenticatedAt($value)
 * @method static Builder|User whereTotpSecret($value)
 * @method static Builder|User whereUpdatedAt($value)
 * @method static Builder|User whereUseTotp($value)
 * @method static Builder|User whereUsername($value)
 * @method static Builder|User whereUuid($value)
 *
 * @mixin \Eloquent
 */
#[Attributes\Identifiable('user')]
class User extends Model implements
    AuthenticatableContract,
    AuthorizableContract,
    CanResetPasswordContract,
    Identifiable
{
    use Authenticatable;
    use Authorizable;
    use AvailableLanguages;
    use CanResetPassword;
    /** @use \Pterodactyl\Models\Traits\HasAccessTokens<\Pterodactyl\Models\ApiKey> */
    use HasAccessTokens;
    use Notifiable;
    /** @use \Illuminate\Database\Eloquent\Factories\HasFactory<\Database\Factories\UserFactory> */
    use HasFactory;
    use HasRealtimeIdentifier;

    public const USER_LEVEL_USER = 0;
    public const USER_LEVEL_ADMIN = 1;

    /**
     * The resource name for this model when it is transformed into an
     * API representation using fractal.
     */
    public const RESOURCE_NAME = 'user';

    /**
     * The panel owner's account. It always keeps root administrator access, can never
     * be deleted, and only the owner can change it.
     */
    public const OWNER_ID = 1;

    /**
     * Level of servers to display when using access() on a user.
     */
    protected string $accessLevel = 'all';

    /**
     * The table associated with the model.
     */
    protected $table = 'users';

    /**
     * A list of mass-assignable variables.
     */
    protected $fillable = [
        'external_id',
        'username',
        'email',
        'name_first',
        'name_last',
        'password',
        'language',
        'use_totp',
        'totp_secret',
        'totp_authenticated_at',
        'gravatar',
        'root_admin',
    ];

    /**
     * Cast values to correct type.
     */
    protected $casts = [
        'root_admin' => 'boolean',
        'admin_role_id' => 'integer',
        'use_totp' => 'boolean',
        'email_2fa' => 'boolean',
        'gravatar' => 'boolean',
        'totp_authenticated_at' => 'datetime',
        'email_verified_at' => 'datetime',
        'email_verify_by' => 'datetime',
        'registration_pending' => 'boolean',
        'deletion_scheduled_at' => 'datetime',
        'date_of_birth' => 'date:Y-m-d',
        'legal_accepted_at' => 'datetime',
        'billing_credit' => 'integer',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     */
    protected $hidden = ['password', 'remember_token', 'totp_secret', 'totp_authenticated_at', 'avatar', 'stripe_customer_id', 'stripe_payment_method'];

    /**
     * Default values for specific fields in the database.
     */
    protected $attributes = [
        'external_id' => null,
        'root_admin' => false,
        'language' => 'en',
        'use_totp' => false,
        'email_2fa' => false,
        'totp_secret' => null,
    ];

    /**
     * Rules verifying that the data being stored matches the expectations of the database.
     */
    public static array $validationRules = [
        'uuid' => 'required|string|size:36|unique:users,uuid',
        'email' => 'required|email:strict|between:1,191|unique:users,email',
        'external_id' => 'sometimes|nullable|string|max:191|unique:users,external_id',
        'username' => 'required|between:1,191|unique:users,username',
        'name_first' => 'required|string|between:1,191',
        'name_last' => 'required|string|between:1,191',
        'password' => 'sometimes|nullable|string',
        'root_admin' => 'boolean',
        'admin_role_id' => 'nullable|integer|exists:admin_roles,id',
        'language' => 'string',
        'use_totp' => 'boolean',
        'totp_secret' => 'nullable|string',
        'email_2fa' => 'boolean',
        'totp_app_name' => 'nullable|string|max:64',
    ];

    /**
     * Implement language verification by overriding Eloquence's gather
     * rules function.
     */
    public static function getRules(): array
    {
        $rules = parent::getRules();

        $rules['language'][] = new In(array_keys((new self())->getAvailableLanguages()));
        $rules['username'][] = new Username();

        return $rules;
    }

    /**
     * Return the user model in a format that can be passed over to Vue templates.
     */
    public function toVueObject(): array
    {
        return Collection::make($this->toArray())->except(['id', 'external_id', 'admin_role', 'adminRole'])
            ->merge([
                'identifier' => $this->identifier,
                'avatar_url' => $this->avatarUrl(),
                'has_avatar' => !is_null($this->avatar),
                'email_verified' => $this->hasVerifiedEmail(),
                'admin_access' => $this->hasAdminAccess(),
                'view_all_servers' => $this->hasAdminPermission(AdminPermissions::VIEW_ALL_SERVERS),
                'admin_permissions' => $this->root_admin ? ['*'] : $this->getAdminPermissions(),
                'two_factor' => \Pterodactyl\Services\Users\TwoFactorPolicy::status($this),
            ])
            ->toArray();
    }

    /**
     * Ticket folders to delete once an account has been deleted.
     *
     * @var array<int, string[]>
     */
    private static array $ticketCleanup = [];

    /**
     * Removes the stored profile picture file when the account is deleted.
     */
    protected static function booted(): void
    {
        // Last line of defence for the owner account, whatever tries to change it
        // (admin area, Application API, console commands or code).
        // ("updating" rather than "saving": the base model's validation listener on
        // "saving" returns true, which stops any later "saving" listeners running.)
        static::updating(function (User $user) {
            // Verifying the email (from any route) removes the deadline to do so.
            if ($user->isDirty('email_verified_at') && $user->email_verified_at) {
                $user->email_verify_by = null;
            }

            if ($user->isOwner() && $user->isDirty('root_admin') && $user->getOriginal('root_admin') && !$user->root_admin) {
                throw new \Pterodactyl\Exceptions\DisplayException('The panel owner (user #' . self::OWNER_ID . ') always keeps root administrator access.');
            }
        });
        static::deleting(function (User $user) {
            if ($user->isOwner()) {
                throw new \Pterodactyl\Exceptions\DisplayException('The panel owner (user #' . self::OWNER_ID . ') can never be deleted.');
            }

            // Take their roles away in our Discord server.
            \Pterodactyl\Services\Support\DiscordRoleService::queue(\Pterodactyl\Services\Support\DiscordBridge::discordIdFor($user));

            // Their tickets are removed by the database; remember which, so their files go too.
            self::$ticketCleanup[$user->id] = Support\Ticket::query()->where('user_id', $user->id)->pluck('uuid')->all();
        });

        static::deleted(function (User $user) {
            if ($user->avatar && AvatarService::isValidName($user->avatar)) {
                Storage::disk('local')->delete(AvatarService::DIRECTORY . '/' . $user->avatar);
            }

            foreach (self::$ticketCleanup[$user->id] ?? [] as $uuid) {
                Storage::disk('local')->deleteDirectory(Support\TicketAttachment::DIRECTORY . '/' . $uuid);
            }
            unset(self::$ticketCleanup[$user->id]);
        });
    }

    /**
     * Paid services (billed servers) belonging to this user.
     *
     * @return HasMany<\Pterodactyl\Models\Billing\Subscription, $this>
     */
    public function subscriptions(): HasMany
    {
        return $this->hasMany(Billing\Subscription::class);
    }

    /**
     * @return HasMany<\Pterodactyl\Models\Billing\Invoice, $this>
     */
    public function invoices(): HasMany
    {
        return $this->hasMany(Billing\Invoice::class);
    }

    /**
     * Determines if the user has confirmed that they own their email address.
     */
    /**
     * True once the deadline to verify the email has passed without it being verified.
     * The account is then paused (only the "verify your email" page works) until they do.
     */
    public function mustVerifyEmailNow(): bool
    {
        return !$this->hasVerifiedEmail() && $this->email_verify_by !== null && $this->email_verify_by->isPast();
    }

    public function hasVerifiedEmail(): bool
    {
        return !is_null($this->email_verified_at);
    }

    /**
     * Returns the URL of the user's profile picture. This is always served by the
     * Panel itself: either their uploaded picture or a generated default, never an
     * external service. The version parameter changes whenever the picture changes.
     */
    public function avatarUrl(): string
    {
        return route('avatar', ['uuid' => $this->uuid], false) . '?v=' . substr($this->avatar ?? 'default', 0, 8);
    }

    /**
     * Send the password reset notification.
     *
     * @param string $token
     */
    public function sendPasswordResetNotification($token)
    {
        Activity::event('auth:reset-password')
            ->withRequestMetadata()
            ->subject($this)
            ->log('sending password reset email');

        $this->notify(new ResetPasswordNotification($token));
    }

    /**
     * Store the username as a lowercase string.
     */
    public function setUsernameAttribute(string $value)
    {
        $this->attributes['username'] = mb_strtolower($value);
    }

    /**
     * Return a concatenated result for the accounts full name.
     */
    public function getNameAttribute(): string
    {
        return trim($this->name_first . ' ' . $this->name_last);
    }

    /**
     * Returns all servers that a user owns.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<\Pterodactyl\Models\Server, $this>
     */
    public function servers(): HasMany
    {
        return $this->hasMany(Server::class, 'owner_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<\Pterodactyl\Models\ApiKey, $this>
     */
    public function apiKeys(): HasMany
    {
        return $this->hasMany(ApiKey::class)
            ->where('key_type', ApiKey::TYPE_ACCOUNT);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<\Pterodactyl\Models\RecoveryToken, $this>
     */
    public function recoveryTokens(): HasMany
    {
        return $this->hasMany(RecoveryToken::class);
    }

    /**
     * Google, GitHub and Discord accounts connected for logging in.
     *
     * @return HasMany<UserConnection, $this>
     */
    public function connections(): HasMany
    {
        return $this->hasMany(UserConnection::class);
    }

    /**
     * Notes staff have written about this account.
     *
     * @return HasMany<UserNote, $this>
     */
    public function notes(): HasMany
    {
        return $this->hasMany(UserNote::class);
    }

    /**
     * Browser sessions where this account is logged in.
     *
     * @return HasMany<UserSession, $this>
     */
    public function sessions(): HasMany
    {
        return $this->hasMany(UserSession::class);
    }

    /**
     * Data export and account deletion requests.
     *
     * @return HasMany<PrivacyRequest, $this>
     */
    public function privacyRequests(): HasMany
    {
        return $this->hasMany(PrivacyRequest::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany<\Pterodactyl\Models\UserSSHKey, $this>
     */
    public function sshKeys(): HasMany
    {
        return $this->hasMany(UserSSHKey::class);
    }

    /**
     * Returns all the activity logs where this user is the subject — not to
     * be confused by activity logs where this user is the _actor_.
     *
     * @return \Illuminate\Database\Eloquent\Relations\MorphToMany<\Pterodactyl\Models\ActivityLog, $this>
     */
    public function activity(): MorphToMany
    {
        return $this->morphToMany(ActivityLog::class, 'subject', 'activity_log_subjects');
    }

    /**
     * Returns all the servers that a user can access by way of being the owner of the
     * server, or because they are assigned as a subuser for that server.
     *
     * @return \Illuminate\Database\Eloquent\Builder<\Pterodactyl\Models\Server>
     */
    public function accessibleServers(): Builder
    {
        return Server::query()
            ->select('servers.*')
            ->leftJoin('subusers', 'subusers.server_id', '=', 'servers.id')
            ->where(function (Builder $builder) {
                $builder->where('servers.owner_id', $this->id)->orWhere('subusers.user_id', $this->id);
            })
            ->groupBy('servers.id');
    }

    /**
     * Returns the staff role assigned to this user, if any.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo<\Pterodactyl\Models\AdminRole, $this>
     */
    public function adminRole(): BelongsTo
    {
        return $this->belongsTo(AdminRole::class, 'admin_role_id');
    }

    /**
     * Returns every permission granted to this user by their staff role. Root
     * administrators implicitly have every permission, use hasAdminPermission()
     * for permission checks rather than inspecting this list directly.
     *
     * @return string[]
     */
    public function getAdminPermissions(): array
    {
        if (is_null($this->admin_role_id)) {
            return [];
        }

        return $this->adminRole?->getPermissionList() ?? [];
    }

    /**
     * Determines if the user has at least one of the given staff permissions.
     */
    public function hasAdminPermission(string ...$permissions): bool
    {
        if ($this->root_admin) {
            return true;
        }

        return count(array_intersect($permissions, $this->getAdminPermissions())) > 0;
    }

    /**
     * Determines if the user is allowed to enter the admin area at all.
     */
    public function hasAdminAccess(): bool
    {
        if ($this->root_admin) {
            return true;
        }

        foreach ($this->getAdminPermissions() as $permission) {
            if (AdminPermissions::isPanelPermission($permission)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Returns the subuser-style permissions this user holds on EVERY server
     * because of their staff role (e.g. "control.start").
     *
     * @return string[]
     */
    public function getGlobalServerPermissions(): array
    {
        $permissions = [];
        foreach ($this->getAdminPermissions() as $permission) {
            if (str_starts_with($permission, AdminPermissions::SERVER_PREFIX)) {
                $permissions[] = substr($permission, strlen(AdminPermissions::SERVER_PREFIX));
            }
        }

        // Like subusers, any server access always includes connecting to the console
        // websocket, otherwise the console and live stats can never load.
        if (!empty($permissions)) {
            $permissions[] = Permission::ACTION_WEBSOCKET_CONNECT;
        }

        return array_values(array_unique($permissions));
    }

    /**
     * Determines if this user's staff role grants them access to servers that
     * they do not own and are not a subuser of.
     */
    public function hasGlobalServerAccess(): bool
    {
        return count($this->getGlobalServerPermissions()) > 0;
    }

    /**
     * Determines if the user is a member of staff in any form.
     */
    public function isStaff(): bool
    {
        return $this->root_admin || count($this->getAdminPermissions()) > 0;
    }

    /**
     * Determines if this user holds every one of the given permissions, used to
     * stop staff from granting access they do not have themselves.
     */
    public function holdsAllAdminPermissions(array $permissions): bool
    {
        if ($this->root_admin) {
            return true;
        }

        return count(array_diff(AdminPermissions::sanitize($permissions), $this->getAdminPermissions())) === 0;
    }

    /**
     * Determines if this user is allowed to modify the given user account from
     * the admin area. Staff can never modify root administrators, or users whose
     * role grants permissions that the staff member does not hold.
     */
    public function canManageUser(User $user): bool
    {
        // Only the owner can change the owner's account.
        if ($user->isOwner() && !$this->isOwner()) {
            return false;
        }

        if ($this->root_admin) {
            return true;
        }

        if ($user->root_admin) {
            return false;
        }

        return $this->holdsAllAdminPermissions($user->getAdminPermissions());
    }

    /**
     * True for the panel owner's account (user #1).
     */
    public function isOwner(): bool
    {
        return $this->exists && (int) $this->getKey() === self::OWNER_ID;
    }
}
