<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * A note staff keep about a customer's account.
 *
 * @property int $id
 * @property int $user_id
 * @property int|null $author_id
 * @property int|null $updated_by
 * @property string $body
 * @property bool $pinned
 * @property \Carbon\CarbonImmutable $created_at
 * @property \Carbon\CarbonImmutable $updated_at
 * @property User|null $author
 * @property User|null $editor
 */
class UserNote extends Model
{
    public const RESOURCE_NAME = 'user_note';

    protected bool $immutableDates = true;

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = ['user_id' => 'integer', 'author_id' => 'integer', 'updated_by' => 'integer', 'pinned' => 'boolean'];

    public static array $validationRules = [
        'user_id' => 'required|integer',
        'author_id' => 'nullable|integer',
        'updated_by' => 'nullable|integer',
        'body' => 'required|string|max:5000',
        'pinned' => 'boolean',
    ];

    /**
     * @return BelongsTo<User, $this>
     */
    public function author(): BelongsTo
    {
        return $this->belongsTo(User::class, 'author_id');
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function editor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}
