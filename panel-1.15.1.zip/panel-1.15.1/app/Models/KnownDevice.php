<?php

namespace Pterodactyl\Models;

/**
 * A browser, device and network an account has logged in from.
 *
 * @property int $id
 * @property int $user_id
 * @property string $fingerprint
 * @property string|null $device
 * @property string|null $last_ip
 * @property \Carbon\CarbonImmutable $first_seen_at
 * @property \Carbon\CarbonImmutable $last_seen_at
 */
class KnownDevice extends Model
{
    public const RESOURCE_NAME = 'known_device';

    public $timestamps = false;

    protected bool $immutableDates = true;

    protected $guarded = ['id'];

    protected $casts = ['user_id' => 'integer', 'first_seen_at' => 'datetime', 'last_seen_at' => 'datetime'];

    public static array $validationRules = [
        'user_id' => 'required|integer',
        'fingerprint' => 'required|string|size:64',
        'device' => 'nullable|string|max:100',
        'last_ip' => 'nullable|string|max:45',
        'first_seen_at' => 'required|date',
        'last_seen_at' => 'required|date',
    ];
}
