<?php

namespace Pterodactyl\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

/**
 * Tells someone a Google, GitHub or Discord account was connected to or removed from
 * their account, so they notice if it wasn't them.
 */
class AccountConnectionChanged extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public string $providerLabel, public ?string $accountName, public bool $connected, public bool $byStaff = false)
    {
    }

    /**
     * Escapes Markdown so text shows exactly as written (the mail template escapes HTML).
     */
    public static function plain(string $text): string
    {
        $text = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $text) ?? '';

        return preg_replace('/([\\\\`*_\[\]()~])/', '\\\\$1', $text) ?? '';
    }

    public function via(): array
    {
        return ['mail'];
    }

    public function toMail(): MailMessage
    {
        // The account name comes from the provider, so make sure it can't add links or formatting.
        $name = $this->accountName ? ' (' . self::plain($this->accountName) . ')' : '';
        $message = (new MailMessage())
            ->subject(($this->connected ? 'A ' . $this->providerLabel . ' account was connected' : 'A ' . $this->providerLabel . ' account was removed') . ' — ' . config('app.name'))
            ->greeting($this->connected ? 'New login method added' : 'Login method removed');

        if ($this->connected) {
            $message->line("The {$this->providerLabel} account{$name} was connected to your " . config('app.name') . ' account. It can now be used to log in.');
        } else {
            $message->line("The {$this->providerLabel} account{$name} was " . ($this->byStaff ? 'removed from your account by our staff' : 'disconnected from your account') . '. It can no longer be used to log in.');
        }

        return $message
            ->action('Review your connections', url('/account/connections'))
            ->line($this->connected
                ? 'If this was not you, remove it straight away from Account → Connections, change your password, and contact us.'
                : 'If this was not you, change your password straight away and contact us.');
    }
}
