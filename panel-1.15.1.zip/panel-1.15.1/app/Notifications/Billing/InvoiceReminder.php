<?php

namespace Pterodactyl\Notifications\Billing;

use Illuminate\Bus\Queueable;
use Pterodactyl\Models\Billing\Invoice;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class InvoiceReminder extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public Invoice $invoice, public int $daysLeft)
    {
    }

    public function via(): array
    {
        return ['mail'];
    }

    public function toMail(): MailMessage
    {
        $i = $this->invoice;
        $when = $this->daysLeft <= 0 ? 'today' : ($this->daysLeft === 1 ? 'tomorrow' : 'in ' . $this->daysLeft . ' days');

        return (new MailMessage())
            ->subject('Reminder: invoice ' . $i->displayNumber() . ' is due ' . $when)
            ->greeting('Hello ' . ($i->user->name_first ?? '') . '!')
            ->line('Invoice ' . $i->displayNumber() . ' for ' . $i->money($i->total) . ' is due ' . $when . '.')
            ->line('Unpaid services are suspended ' . config('billing.timings.suspend_after_days') . ' days after the due date.')
            ->action('Pay Now', url('/billing/invoices/' . $i->uuid));
    }
}
