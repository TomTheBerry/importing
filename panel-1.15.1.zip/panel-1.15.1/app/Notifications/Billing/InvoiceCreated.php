<?php

namespace Pterodactyl\Notifications\Billing;

use Illuminate\Bus\Queueable;
use Pterodactyl\Models\Billing\Invoice;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class InvoiceCreated extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public Invoice $invoice)
    {
    }

    public function via(): array
    {
        return ['mail'];
    }

    public function toMail(): MailMessage
    {
        $i = $this->invoice;

        return (new MailMessage())
            ->subject('New invoice ' . $i->displayNumber() . ' — ' . $i->money($i->total))
            ->greeting('Hello ' . ($i->user->name_first ?? '') . '!')
            ->line('A new invoice has been created for your service.')
            ->line('Amount due: ' . $i->money($i->total))
            ->line('Due date: ' . $i->due_at?->format('j F Y'))
            ->line($i->user?->stripe_payment_method ? 'Your saved card will be charged automatically on the due date.' : 'Please pay it before the due date to keep your server running.')
            ->action('View Invoice', url('/billing/invoices/' . $i->uuid));
    }
}
