<?php

namespace Pterodactyl\Notifications;

use Pterodactyl\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

/**
 * Sent when someone tries to register with an email address that already has an
 * account. The registration page shows the same message either way, so it cannot
 * be used to discover which email addresses are registered.
 */
class AlreadyRegistered extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public User $user)
    {
    }

    public function via(): array
    {
        return ['mail'];
    }

    public function toMail(): MailMessage
    {
        return (new MailMessage())
            ->subject('You already have an account on ' . config('app.name'))
            ->greeting('Hello ' . $this->user->name_first . '!')
            ->line('Someone tried to register a new account on ' . config('app.name') . ' using this email address, but you already have an account.')
            ->action('Log In', url('/auth/login'))
            ->line('If you have forgotten your password, you can reset it from the login page. If this was not you, you can safely ignore this email.');
    }
}
