<?php

namespace Pterodactyl\Exceptions\Billing;

use Pterodactyl\Exceptions\DisplayException;

/**
 * A billing error whose message is safe to show to the user.
 */
class BillingException extends DisplayException
{
    /** The raw error returned by a payment gateway, if any. Never shown to users. */
    public array $stripeError = [];
}
