<?php

namespace Pterodactyl\Jobs\Billing;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Pterodactyl\Models\Billing\Subscription;
use Pterodactyl\Services\Billing\ProvisioningService;

/**
 * Creates the game server for a newly paid service.
 */
class ProvisionServer implements ShouldQueue
{
    use Dispatchable;
    use InteractsWithQueue;
    use Queueable;
    use SerializesModels;

    public int $tries = 1;

    public function __construct(public int $subscriptionId)
    {
    }

    public function handle(ProvisioningService $service): void
    {
        $subscription = Subscription::query()->find($this->subscriptionId);
        if ($subscription) {
            $service->provision($subscription);
        }
    }
}
